import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { AccessToken } from 'livekit-server-sdk';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const LIVEKIT_ROOM = 'pirate-battle';

async function startServer() {
  const app = express();
  app.use(express.json());

  // Mint read-only observer LiveKit token without exposing API secrets to the browser
  app.get('/api/livekit-token', async (_req, res) => {
    const livekitUrl = process.env.LIVEKIT_URL?.trim();
    const apiKey = process.env.LIVEKIT_API_KEY?.trim();
    const apiSecret = process.env.LIVEKIT_API_SECRET?.trim();

    if (!livekitUrl || !apiKey || !apiSecret) {
      res.json({
        configured: false,
        room: LIVEKIT_ROOM,
      });
      return;
    }

    try {
      const identity = `pirate-hud-${Math.random().toString(36).slice(2, 10)}`;
      const at = new AccessToken(apiKey, apiSecret, {
        identity,
        ttl: '4h',
      });
      at.addGrant({
        roomJoin: true,
        room: LIVEKIT_ROOM,
        canPublish: false,
        canPublishData: false,
        canSubscribe: true,
      });

      const token = await at.toJwt();
      res.json({
        configured: true,
        url: livekitUrl,
        token,
        room: LIVEKIT_ROOM,
      });
    } catch (err) {
      console.error('Failed to mint LiveKit observer token:', err);
      res.status(500).json({
        configured: false,
        error: 'Failed to create LiveKit token',
      });
    }
  });

  const distDir = path.resolve(__dirname, 'dist');
  const isProd = process.env.NODE_ENV === 'production' && fs.existsSync(distDir);

  if (isProd) {
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pirate Battle server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server startup failed:', err);
  process.exit(1);
});
