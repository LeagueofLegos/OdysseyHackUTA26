/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { ChevronDown, ChevronUp, Crosshair, Radio, RotateCcw, Volume2, VolumeX } from 'lucide-react';
import {
  type BroadsideSide,
  type HudSnapshot,
  PirateBattleScene,
} from './components/PirateBattleScene';
import { type AiLinkStatus, useLiveKitListener } from './hooks/useLiveKitListener';

const INITIAL_HUD: HudSnapshot = {
  playerHp: 100,
  playerMaxHp: 100,
  enemyHp: 100,
  enemyMaxHp: 100,
  reloadProgress: 1,
  activeSide: 'bow',
  speedKnots: 0,
  headingDeg: 0,
  shotsFired: 0,
  hitsLanded: 0,
  elapsedSec: 0,
  outcome: 'playing',
  targetLocked: false,
  lastHitNotice: '',
  tacticalNotice: '',
};

function formatBatteryLabel(side: BroadsideSide): string {
  if (side === 'port') return 'Port Broadside';
  if (side === 'starboard') return 'Starboard Broadside';
  return 'Bow Chasers';
}

function formatDuration(sec: number): string {
  const whole = Math.max(0, Math.floor(sec));
  const m = Math.floor(whole / 60);
  const s = whole % 60;
  return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatAthenaStatusLabel(status: AiLinkStatus): string {
  switch (status) {
    case 'connected':
      return 'Athena Link Connected';
    case 'connecting':
      return 'Athena Link Connecting';
    case 'unconfigured':
      return 'Athena Link Standby';
    case 'disconnected':
      return 'Athena Link Offline';
  }
}

export default function App() {
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [resetSignal, setResetSignal] = useState(0);
  const aiLink = useLiveKitListener();

  const handleHudUpdate = useCallback((snapshot: HudSnapshot) => {
    setHud(snapshot);
  }, []);

  const handleReplay = useCallback(() => {
    setHud(INITIAL_HUD);
    setResetSignal((n) => n + 1);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'KeyH') {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const playerPct = Math.max(0, Math.min(100, (hud.playerHp / hud.playerMaxHp) * 100));
  const enemyPct = Math.max(0, Math.min(100, (hud.enemyHp / hud.enemyMaxHp) * 100));
  const reloadPct = Math.round(Math.max(0, Math.min(1, hud.reloadProgress)) * 100);
  const isReady = hud.reloadProgress >= 0.99;
  const accuracy = hud.shotsFired > 0 ? Math.round((hud.hitsLanded / hud.shotsFired) * 100) : 0;

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#07111a]">
      {/* Full-viewport 3D WebGL Ocean & Galleon Scene */}
      <PirateBattleScene
        audioEnabled={audioEnabled}
        resetSignal={resetSignal}
        onHudUpdate={handleHudUpdate}
      />

      {/* Top Hull Health HUD (Leaves center viewport 100% unobstructed) */}
      <header className="pointer-events-none fixed top-0 left-0 right-0 z-10 flex items-start justify-between gap-4 px-5 pt-4">
        {/* Player Ship Hull Integrity */}
        <div className="pointer-events-auto w-72 max-w-[44vw] rounded-lg border border-white/12 bg-[#0a1520]/88 px-4 py-3 shadow-lg">
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-display text-sm font-bold tracking-wide text-amber-200 truncate">
              Odysseus&apos;s Ship
            </span>
            <span className="font-mono-tabular text-xs font-semibold text-slate-200 shrink-0">
              {hud.playerHp} / {hud.playerMaxHp} HP
            </span>
          </div>
          <div className="mt-2 h-2.5 w-full overflow-hidden rounded-sm bg-slate-800">
            <div
              className={`h-full transition-transform duration-150 origin-left ${
                playerPct > 50 ? 'bg-emerald-500' : playerPct > 25 ? 'bg-amber-500' : 'bg-red-500'
              }`}
              style={{ transform: `scaleX(${playerPct / 100})` }}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-xs text-slate-400">
            <span>Voyage to Ithaca</span>
            <span className="font-mono-tabular">{Math.round(playerPct)}% Hull</span>
          </div>
        </div>

        {/* Center Athena Link Status & Transient Callouts */}
        <div className="hidden sm:flex flex-col items-center gap-1.5">
          <div className="inline-flex items-center gap-2 rounded-md border border-white/12 bg-[#0a1520]/88 px-3 py-1 text-xs shadow-md whitespace-nowrap">
            <Radio
              className={`w-3.5 h-3.5 shrink-0 ${
                aiLink.status === 'connected'
                  ? 'text-emerald-400'
                  : aiLink.status === 'connecting'
                    ? 'text-amber-300'
                    : aiLink.status === 'disconnected'
                      ? 'text-rose-400'
                      : 'text-slate-400'
              }`}
            />
            <span
              className={`font-medium ${
                aiLink.status === 'connected'
                  ? 'text-emerald-300'
                  : aiLink.status === 'connecting'
                    ? 'text-amber-200'
                    : aiLink.status === 'disconnected'
                      ? 'text-rose-300'
                      : 'text-slate-300'
              }`}
            >
              {formatAthenaStatusLabel(aiLink.status)}
            </span>
            {aiLink.lastCommand && (
              <>
                <span className="text-slate-500" aria-hidden="true">
                  ·
                </span>
                <span className="font-mono-tabular text-amber-200">
                  {aiLink.lastCommand}
                </span>
              </>
            )}
          </div>

          {hud.tacticalNotice && hud.outcome === 'playing' && (
            <div className="rounded-md border border-sky-300/20 bg-[#0a1520]/85 px-3 py-1 text-xs font-medium tracking-wide text-sky-200 shadow-md">
              {hud.tacticalNotice}
            </div>
          )}

          {hud.lastHitNotice && hud.outcome === 'playing' && (
            <div className="rounded-md border border-amber-400/25 bg-[#0a1520]/88 px-3.5 py-1.5 text-xs font-semibold tracking-wide text-amber-200 shadow-md">
              {hud.lastHitNotice}
            </div>
          )}
        </div>

        {/* Enemy AI Ship Hull Integrity */}
        <div className="pointer-events-auto w-72 max-w-[44vw] rounded-lg border border-white/12 bg-[#0a1520]/88 px-4 py-3 shadow-lg">
          <div className="flex items-baseline justify-between gap-2">
            <span className="font-display text-sm font-bold tracking-wide text-rose-300 truncate">
              Scylla&apos;s Corsair
            </span>
            <span className="font-mono-tabular text-xs font-semibold text-slate-200 shrink-0">
              {hud.enemyHp} / {hud.enemyMaxHp} HP
            </span>
          </div>
          <div className="mt-2 h-2.5 w-full overflow-hidden rounded-sm bg-slate-800">
            <div
              className="h-full bg-rose-500 transition-transform duration-150 origin-left"
              style={{ transform: `scaleX(${enemyPct / 100})` }}
            />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-xs text-slate-400">
            <span>Perilous Sea Raider</span>
            <span className="font-mono-tabular">{Math.round(enemyPct)}% Hull</span>
          </div>
        </div>
      </header>

      {/* Collapsible Bottom Control & Tactical Dock */}
      <div className="pointer-events-none fixed bottom-4 left-1/2 z-10 -translate-x-1/2 flex flex-col items-center max-w-[94vw]">
        <button
          type="button"
          onClick={() => setDockCollapsed((v) => !v)}
          className="pointer-events-auto mb-1.5 inline-flex items-center gap-1.5 rounded-t-md border border-b-0 border-white/12 bg-[#0a1520]/90 px-3 py-1 text-xs font-medium text-slate-300 hover:text-white transition-colors whitespace-nowrap"
          aria-label={dockCollapsed ? 'Show Controls' : 'Hide Controls'}
        >
          {dockCollapsed ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          <span>{dockCollapsed ? 'Show HUD' : 'Hide HUD (H)'}</span>
        </button>

        {!dockCollapsed && (
          <div className="pointer-events-auto flex flex-wrap items-center justify-between gap-4 rounded-xl border border-white/12 bg-[#0a1520]/90 px-4 py-3 shadow-2xl min-w-[min(860px,92vw)]">
            {/* Cannon Status & Reload Bar */}
            <div className="flex items-center gap-3 min-w-[220px]">
              <div className="flex-1">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-semibold text-slate-100 whitespace-nowrap">
                    {formatBatteryLabel(hud.activeSide)}
                  </span>
                  <span
                    className={`font-mono-tabular font-semibold whitespace-nowrap ${
                      isReady ? 'text-amber-300' : 'text-slate-400'
                    }`}
                  >
                    {isReady ? 'Cannons Ready' : `Reloading ${reloadPct}%`}
                  </span>
                </div>
                <div className="mt-1.5 h-2 w-48 overflow-hidden rounded-sm bg-slate-800">
                  <div
                    className={`h-full transition-transform duration-75 origin-left ${
                      isReady ? 'bg-amber-400' : 'bg-sky-400'
                    }`}
                    style={{ transform: `scaleX(${reloadPct / 100})` }}
                  />
                </div>
              </div>

              {hud.targetLocked && (
                <div className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400 whitespace-nowrap">
                  <Crosshair className="w-3.5 h-3.5" />
                  <span>Target Locked</span>
                </div>
              )}
            </div>

            {/* Ship Telemetry */}
            <div className="flex items-center gap-4 text-xs text-slate-300 border-x border-white/10 px-4">
              <div className="whitespace-nowrap">
                <span className="text-slate-400 mr-1.5">Speed</span>
                <span className="font-mono-tabular font-semibold text-white">{hud.speedKnots} kn</span>
              </div>
              <div className="whitespace-nowrap">
                <span className="text-slate-400 mr-1.5">Heading</span>
                <span className="font-mono-tabular font-semibold text-white">
                  {hud.headingDeg.toString().padStart(3, '0')}°
                </span>
              </div>
              <div className="hidden md:block whitespace-nowrap">
                <span className="text-slate-400 mr-1.5">Hits</span>
                <span className="font-mono-tabular font-semibold text-white">
                  {hud.hitsLanded}/{hud.shotsFired}
                </span>
              </div>
            </div>

            {/* Controls Hint + Audio & Reset */}
            <div className="flex items-center gap-3">
              <span className="hidden lg:inline text-xs text-slate-400 whitespace-nowrap">
                W/S Thrust · A/D Steer · Mouse Aim · Left Click Fire
              </span>
              <button
                type="button"
                onClick={() => setAudioEnabled((v) => !v)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                {audioEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{audioEnabled ? 'Sound On' : 'Muted'}</span>
              </button>
              <button
                type="button"
                onClick={handleReplay}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-200 hover:bg-slate-700 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restart</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Victory / Defeat Replay Overlay */}
      {hud.outcome !== 'playing' && (
        <div className="fixed inset-0 z-20 flex items-center justify-center bg-slate-950/70 p-4">
          <div className="w-full max-w-md rounded-2xl border border-white/15 bg-[#0c1824] p-7 text-center shadow-2xl">
            <p className="text-xs font-semibold tracking-widest uppercase text-slate-400">
              {hud.outcome === 'victory' ? 'Passage to Ithaca Cleared' : 'Lost in Perilous Seas'}
            </p>
            <h1
              className={`mt-2 font-display text-4xl font-bold tracking-wide ${
                hud.outcome === 'victory' ? 'text-amber-300' : 'text-rose-400'
              }`}
            >
              {hud.outcome === 'victory' ? 'Victory' : 'Defeat'}
            </h1>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              {hud.outcome === 'victory'
                ? "Scylla's Corsair sinks beneath the wine-dark waves. Odysseus's Ship sails onward toward Ithaca."
                : 'The perilous straits claimed your hull before reaching Ithaca. Launch another vessel and chart the sea again.'}
            </p>

            {/* Battle Summary */}
            <div className="mt-6 grid grid-cols-3 gap-3 border-y border-white/10 py-4">
              <div>
                <div className="text-xs text-slate-400">Voyage Time</div>
                <div className="mt-1 font-mono-tabular text-lg font-semibold text-white">
                  {formatDuration(hud.elapsedSec)}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Hits Landed</div>
                <div className="mt-1 font-mono-tabular text-lg font-semibold text-white">
                  {hud.hitsLanded} / {hud.shotsFired}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Accuracy</div>
                <div className="mt-1 font-mono-tabular text-lg font-semibold text-white">
                  {accuracy}%
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleReplay}
              className="mt-6 w-full rounded-lg bg-amber-500 px-5 py-3 text-sm font-semibold text-slate-950 hover:bg-amber-400 transition-colors cursor-pointer"
            >
              Sail Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
