import { useEffect, useState } from 'react';
import { Room, RoomEvent } from 'livekit-client';

export type AiLinkStatus = 'connecting' | 'connected' | 'disconnected' | 'unconfigured';

export interface LiveKitListenerState {
  status: AiLinkStatus;
  lastCommand: string | null;
}

type ShipCommandName =
  | 'steer_left'
  | 'steer_right'
  | 'accelerate'
  | 'slow_down'
  | 'fire'
  | 'combat_burst'
  | 'restart';

interface ShipCommandMessage {
  type?: unknown;
  command?: unknown;
}

const VALID_COMMANDS = new Set<ShipCommandName>([
  'steer_left',
  'steer_right',
  'accelerate',
  'slow_down',
  'fire',
  'combat_burst',
  'restart',
]);

function executeShipCommand(command: ShipCommandName) {
  const agent = window.pirateAgent;
  if (!agent) return;

  switch (command) {
    case 'steer_left':
      agent.steerLeft();
      break;
    case 'steer_right':
      agent.steerRight();
      break;
    case 'accelerate':
      agent.accelerate();
      break;
    case 'slow_down':
      agent.slowDown();
      break;
    case 'fire':
      agent.fireBroadside();
      break;
    case 'combat_burst':
      agent.combatBurst();
      break;
    case 'restart':
      agent.restartGame();
      break;
  }
}

export function useLiveKitListener(): LiveKitListenerState {
  const [status, setStatus] = useState<AiLinkStatus>('connecting');
  const [lastCommand, setLastCommand] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    let room: Room | null = null;
    const decoder = new TextDecoder();

    async function connectObserver() {
      try {
        const res = await fetch('/api/livekit-token');
        if (!res.ok) {
          if (!cancelled) setStatus('disconnected');
          return;
        }
        const data = (await res.json()) as {
          configured?: boolean;
          url?: string;
          token?: string;
        };

        if (cancelled) return;
        if (!data.configured || !data.url || !data.token) {
          setStatus('unconfigured');
          return;
        }

        room = new Room({
          adaptiveStream: false,
          dynacast: false,
        });

        room.on(RoomEvent.Connected, () => {
          if (!cancelled) setStatus('connected');
        });
        room.on(RoomEvent.Reconnecting, () => {
          if (!cancelled) setStatus('connecting');
        });
        room.on(RoomEvent.Reconnected, () => {
          if (!cancelled) setStatus('connected');
        });
        room.on(RoomEvent.Disconnected, () => {
          if (!cancelled) setStatus('disconnected');
        });
        room.on(RoomEvent.DataReceived, (payload: Uint8Array) => {
          if (cancelled) return;
          try {
            const text = decoder.decode(payload);
            const msg = JSON.parse(text) as ShipCommandMessage;
            if (
              msg &&
              msg.type === 'ship_command' &&
              typeof msg.command === 'string' &&
              VALID_COMMANDS.has(msg.command as ShipCommandName)
            ) {
              const cmd = msg.command as ShipCommandName;
              executeShipCommand(cmd);
              setLastCommand(cmd);
            }
          } catch {
            // Ignore malformed or non-JSON data packets
          }
        });

        await room.connect(data.url, data.token, {
          autoSubscribe: false,
        });
        if (!cancelled) {
          setStatus('connected');
        }
      } catch {
        if (!cancelled) {
          setStatus('disconnected');
        }
      }
    }

    void connectObserver();

    return () => {
      cancelled = true;
      if (room) {
        void room.disconnect();
      }
    };
  }, []);

  return { status, lastCommand };
}
