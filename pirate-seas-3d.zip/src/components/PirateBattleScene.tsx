import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

export type BattleOutcome = 'playing' | 'victory' | 'defeat';
export type BroadsideSide = 'port' | 'starboard' | 'bow';

export interface HudSnapshot {
  playerHp: number;
  playerMaxHp: number;
  enemyHp: number;
  enemyMaxHp: number;
  reloadProgress: number; // 0..1 (1 = ready)
  activeSide: BroadsideSide;
  speedKnots: number;
  headingDeg: number;
  shotsFired: number;
  hitsLanded: number;
  elapsedSec: number;
  outcome: BattleOutcome;
  targetLocked: boolean;
  lastHitNotice: string;
  tacticalNotice: string;
}

export interface PirateGameAPI {
  steerLeft: (active?: boolean) => void;
  steerRight: (active?: boolean) => void;
  throttleUp: (active?: boolean) => void;
  throttleDown: (active?: boolean) => void;
  fire: () => boolean;
}

export interface PirateBattleState {
  playerHp: number;
  enemyHp: number;
  cannonsReady: boolean;
  heading: number;
  speed: number;
  status: BattleOutcome;
}

export interface PirateAgentAPI {
  steerLeft: (durationMs?: number) => void;
  steerRight: (durationMs?: number) => void;
  accelerate: () => void;
  slowDown: () => void;
  fireBroadside: () => boolean;
  combatBurst: () => boolean;
  restartGame: () => boolean;
  getBattleState: () => PirateBattleState;
}

declare global {
  interface Window {
    pirateGame?: PirateGameAPI;
    pirateAgent?: PirateAgentAPI;
  }
}

interface PirateBattleSceneProps {
  audioEnabled: boolean;
  resetSignal: number;
  onHudUpdate: (snapshot: HudSnapshot) => void;
}

// ============================================================================
// Pre-allocated math scratchpads (Zero GC in the render loop)
// ============================================================================
const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _v4 = new THREE.Vector3();
const _q1 = new THREE.Quaternion();
const _e1 = new THREE.Euler(0, 0, 0, 'YXZ');
const _m1 = new THREE.Matrix4();
const _raycaster = new THREE.Raycaster();
const _ndc = new THREE.Vector2();
const _oceanPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

// ============================================================================
// Shared Ocean Wave Function (Exact match between CPU physics & GPU shader)
// ============================================================================
const WAVE_1 = { dx: 0.86, dz: 0.51, freq: 0.055, speed: 1.35, amp: 0.92 };
const WAVE_2 = { dx: -0.45, dz: 0.89, freq: 0.088, speed: 1.78, amp: 0.52 };
const WAVE_3 = { dx: 0.94, dz: -0.34, freq: 0.155, speed: 2.3, amp: 0.26 };
const WAVE_4 = { dx: -0.78, dz: -0.62, freq: 0.245, speed: 2.85, amp: 0.13 };

function getWaveHeight(x: number, z: number, t: number): number {
  const p1 = (x * WAVE_1.dx + z * WAVE_1.dz) * WAVE_1.freq + t * WAVE_1.speed;
  const p2 = (x * WAVE_2.dx + z * WAVE_2.dz) * WAVE_2.freq + t * WAVE_2.speed;
  const p3 = (x * WAVE_3.dx + z * WAVE_3.dz) * WAVE_3.freq + t * WAVE_3.speed;
  const p4 = (x * WAVE_4.dx + z * WAVE_4.dz) * WAVE_4.freq + t * WAVE_4.speed;
  return (
    Math.sin(p1) * WAVE_1.amp +
    Math.sin(p2) * WAVE_2.amp +
    Math.sin(p3) * WAVE_3.amp +
    Math.sin(p4) * WAVE_4.amp
  );
}

// ============================================================================
// Procedural Web Audio Synthesizer (Zero external audio files)
// ============================================================================
class NavalAudioEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  public enabled = true;

  public unlock() {
    if (!this.enabled) return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      const length = this.ctx.sampleRate * 1.5;
      const buf = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
      const data = buf.getChannelData(0);
      for (let i = 0; i < length; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      this.noiseBuffer = buf;
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
  }

  public playCannon(volume = 0.42) {
    if (!this.enabled || !this.ctx || !this.noiseBuffer || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;

    // Sub-bass thump
    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(115, now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.32);
    oscGain.gain.setValueAtTime(volume * 0.9, now);
    oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);
    osc.connect(oscGain).connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.38);

    // Filtered powder blast noise
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(920, now);
    filter.frequency.exponentialRampToValueAtTime(140, now + 0.55);
    const nGain = this.ctx.createGain();
    nGain.gain.setValueAtTime(volume * 0.75, now);
    nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
    src.connect(filter).connect(nGain).connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.62);
  }

  public playHit(isPlayerHit: boolean) {
    if (!this.enabled || !this.ctx || !this.noiseBuffer || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(isPlayerHit ? 480 : 680, now);
    filter.Q.setValueAtTime(1.8, now);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.45, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
    src.connect(filter).connect(gain).connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.3);
  }

  public playSplash() {
    if (!this.enabled || !this.ctx || !this.noiseBuffer || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1200, now);
    filter.frequency.exponentialRampToValueAtTime(340, now + 0.32);
    filter.Q.setValueAtTime(1.1, now);
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    src.connect(filter).connect(gain).connect(this.ctx.destination);
    src.start(now);
    src.stop(now + 0.36);
  }

  public playOutcome(victory: boolean) {
    if (!this.enabled || !this.ctx || this.ctx.state !== 'running') return;
    const now = this.ctx.currentTime;
    const notes = victory ? [261.63, 329.63, 392.0, 523.25] : [220, 196, 174.61, 146.83];
    notes.forEach((freq, idx) => {
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      const t0 = now + idx * 0.14;
      osc.frequency.setValueAtTime(freq, t0);
      gain.gain.setValueAtTime(0.001, t0);
      gain.gain.linearRampToValueAtTime(0.18, t0 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + 0.55);
      osc.connect(gain).connect(this.ctx.destination);
      osc.start(t0);
      osc.stop(t0 + 0.6);
    });
  }

  public dispose() {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}

// ============================================================================
// Procedural Canvas Textures (Zero external images)
// ============================================================================
function createWoodTexture(baseHex: string, grainHex: string, plankCount: number, maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 512, 512);

  const plankH = 512 / plankCount;
  for (let i = 0; i < plankCount; i++) {
    const y = i * plankH;
    // Slight per-plank shade variation
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.05)';
    ctx.fillRect(0, y, 512, plankH);

    // Wood grain streaks
    ctx.strokeStyle = grainHex;
    ctx.globalAlpha = 0.24;
    ctx.lineWidth = 1.5;
    for (let g = 0; g < 6; g++) {
      const gy = y + ((g + 0.5) / 6) * plankH;
      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.bezierCurveTo(170, gy + (g % 2 === 0 ? 3 : -3), 340, gy + (g % 2 === 0 ? -3 : 3), 512, gy);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // Caulking seam
    ctx.fillStyle = 'rgba(10, 8, 6, 0.55)';
    ctx.fillRect(0, y, 512, 2);

    // Butt joint
    const jointX = ((i * 193 + 90) % 420) + 40;
    ctx.fillRect(jointX, y, 2, plankH);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = maxAniso;
  return tex;
}

function createSailTexture(isEnemy: boolean, maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base cloth
  ctx.fillStyle = isEnemy ? '#281d21' : '#ede2cc';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle vertical cloth panel seams
  ctx.strokeStyle = isEnemy ? 'rgba(0,0,0,0.4)' : 'rgba(120, 96, 66, 0.24)';
  ctx.lineWidth = 2;
  for (let x = 64; x < 512; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let y = 128; y < 512; y += 128) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Border stripe
  ctx.strokeStyle = isEnemy ? '#a81c24' : '#1b3b5f';
  ctx.lineWidth = 18;
  ctx.strokeRect(18, 18, 476, 476);

  // Center emblem
  ctx.save();
  ctx.translate(256, 256);
  if (isEnemy) {
    // Crimson/bone skull & crossbones emblem
    ctx.strokeStyle = '#d9cbb8';
    ctx.lineWidth = 18;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-78, -58);
    ctx.lineTo(78, 58);
    ctx.moveTo(78, -58);
    ctx.lineTo(-78, 58);
    ctx.stroke();

    ctx.fillStyle = '#e6dac6';
    ctx.beginPath();
    ctx.arc(0, -14, 48, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillRect(-26, 18, 52, 34);

    ctx.fillStyle = '#281d21';
    ctx.beginPath();
    ctx.arc(-18, -14, 11, 0, Math.PI * 2);
    ctx.arc(18, -14, 11, 0, Math.PI * 2);
    ctx.fill();
  } else {
    // Gold & navy compass star emblem
    ctx.fillStyle = '#1b3b5f';
    ctx.beginPath();
    ctx.arc(0, 0, 86, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#d9a441';
    for (let i = 0; i < 8; i++) {
      ctx.save();
      ctx.rotate((i * Math.PI) / 4);
      ctx.beginPath();
      ctx.moveTo(0, i % 2 === 0 ? -74 : -48);
      ctx.lineTo(13, 0);
      ctx.lineTo(-13, 0);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    ctx.fillStyle = '#ede2cc';
    ctx.beginPath();
    ctx.arc(0, 0, 14, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAniso;
  return tex;
}

function createSkyTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0.0, '#133252'); // Deep zenith blue
  grad.addColorStop(0.38, '#2d688f'); // Mid sky
  grad.addColorStop(0.62, '#7db0c9'); // Horizon haze
  grad.addColorStop(0.75, '#d8b78e'); // Warm golden horizon glow
  grad.addColorStop(1.0, '#0a2033'); // Below horizon
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// ============================================================================
// Procedural 3D Geometries (Galleon Hull, Sails, Cannons, Pirates)
// ============================================================================
function createHullGeometry(): THREE.BufferGeometry {
  // Parametric lofted galleon hull: z from -8.2 (bow) to +7.6 (stern)
  const zStations = [-8.2, -6.8, -5.0, -2.5, 0.0, 2.5, 4.8, 6.6, 7.6];
  const halfWidths = [0.12, 1.15, 2.05, 2.52, 2.65, 2.56, 2.34, 2.02, 1.65];
  const deckHeights = [2.65, 2.35, 2.05, 1.92, 1.92, 1.96, 2.15, 2.52, 2.75];
  const keelDepths = [-0.45, -1.05, -1.3, -1.35, -1.35, -1.35, -1.25, -1.0, -0.7];

  // Cross-section profile points from starboard gunwale -> bottom keel -> port gunwale
  const ringPts = 9; // 0..8 across hull section
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  for (let zi = 0; zi < zStations.length; zi++) {
    const z = zStations[zi];
    const hw = halfWidths[zi];
    const topY = deckHeights[zi];
    const botY = keelDepths[zi];
    const v = zi / (zStations.length - 1);

    const profile: [number, number][] = [
      [hw * 0.96, topY + 0.55], // 0: Starboard bulwark top
      [hw * 1.04, topY * 0.65], // 1: Starboard tumblehome widest
      [hw * 0.88, 0.15], // 2: Starboard waterline
      [hw * 0.42, botY * 0.78], // 3: Starboard bilge
      [0, botY], // 4: Keel center
      [-hw * 0.42, botY * 0.78], // 5: Port bilge
      [-hw * 0.88, 0.15], // 6: Port waterline
      [-hw * 1.04, topY * 0.65], // 7: Port tumblehome widest
      [-hw * 0.96, topY + 0.55], // 8: Port bulwark top
    ];

    for (let pi = 0; pi < ringPts; pi++) {
      positions.push(profile[pi][0], profile[pi][1], z);
      uvs.push(pi / (ringPts - 1), v * 3.0);
    }
  }

  for (let zi = 0; zi < zStations.length - 1; zi++) {
    const rowA = zi * ringPts;
    const rowB = (zi + 1) * ringPts;
    for (let pi = 0; pi < ringPts - 1; pi++) {
      const a = rowA + pi;
      const b = rowA + pi + 1;
      const c = rowB + pi;
      const d = rowB + pi + 1;
      indices.push(a, c, b);
      indices.push(b, c, d);
    }
  }

  // Cap stern transom (last station)
  const sternBase = (zStations.length - 1) * ringPts;
  const sternCenterIdx = positions.length / 3;
  positions.push(0, 1.4, zStations[zStations.length - 1]);
  uvs.push(0.5, 1.0);
  for (let pi = 0; pi < ringPts - 1; pi++) {
    indices.push(sternBase + pi, sternCenterIdx, sternBase + pi + 1);
  }

  // Cap bow tip (first station)
  const bowCenterIdx = positions.length / 3;
  positions.push(0, 1.1, zStations[0] - 0.18);
  uvs.push(0.5, 0.0);
  for (let pi = 0; pi < ringPts - 1; pi++) {
    indices.push(pi, pi + 1, bowCenterIdx);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

function createBillowingSailGeometry(width: number, height: number): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(width, height, 10, 8);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const nx = x / (width * 0.5);
    const ny = y / (height * 0.5);
    // Billow forward (-Z) cleanly in the center of the canvas
    const belly = (1 - nx * nx * 0.55) * (1 - ny * ny * 0.85) * 0.72;
    pos.setZ(i, -belly);
  }
  geo.computeVertexNormals();
  return geo;
}

function createCannonBarrelGeometry(): THREE.LatheGeometry {
  const pts = [
    new THREE.Vector2(0.0, 0.0),
    new THREE.Vector2(0.11, 0.0), // cascabel knob
    new THREE.Vector2(0.07, 0.08),
    new THREE.Vector2(0.21, 0.14), // breech
    new THREE.Vector2(0.19, 0.45),
    new THREE.Vector2(0.15, 0.95), // chase taper
    new THREE.Vector2(0.135, 1.32),
    new THREE.Vector2(0.17, 1.4), // muzzle swell
    new THREE.Vector2(0.145, 1.46),
    new THREE.Vector2(0.085, 1.46), // bore rim
    new THREE.Vector2(0.085, 1.15), // hollow bore
    new THREE.Vector2(0.0, 1.15),
  ];
  const geo = new THREE.LatheGeometry(pts, 14);
  // Orient barrel so +Z is muzzle forward
  geo.rotateX(Math.PI / 2);
  return geo;
}

// ============================================================================
// Ship, Cannon, Crew & Particle Data Structures
// ============================================================================
interface CannonMount {
  side: BroadsideSide;
  root: THREE.Group;
  barrelGroup: THREE.Group;
  muzzleLocal: THREE.Vector3; // relative to barrelGroup
  baseLocalPos: THREE.Vector3;
  aimDirLocal: THREE.Vector3;
  recoil: number;
}

type CrewRole = 'helmsman' | 'gunner';

interface PirateCrewMember {
  root: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  head: THREE.Group;
  role: CrewRole;
  localPos: THREE.Vector3;
  targetLocalPos: THREE.Vector3;
  facingYaw: number;
  targetYaw: number;
  stationIdx: number;
  state: 'walk' | 'reload' | 'aim' | 'fire';
  stateTimer: number;
  walkPhase: number;
}

interface ShipEntity {
  id: 'player' | 'enemy';
  group: THREE.Group;
  hullMesh: THREE.Mesh;
  wheelMesh: THREE.Group;
  flagMesh: THREE.Mesh;
  sails: THREE.Mesh[];
  cannons: CannonMount[];
  crew: PirateCrewMember[];
  x: number;
  z: number;
  y: number;
  yaw: number;
  pitch: number;
  roll: number;
  speed: number;
  vx: number;
  vz: number;
  rudderAngle: number;
  hp: number;
  maxHp: number;
  reloadTimer: number;
  reloadDuration: number;
  hitFlashTimer: number;
  sinkProgress: number;
  wakeTimer: number;
  smokeTimer: number;
}

interface Cannonball {
  active: boolean;
  owner: 'player' | 'enemy';
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  age: number;
}

interface Particle {
  active: boolean;
  kind: 'smoke' | 'fire' | 'splash' | 'ring' | 'splinter' | 'wake';
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  rot: THREE.Euler;
  rotVel: THREE.Vector3;
  age: number;
  maxAge: number;
  startScale: number;
  endScale: number;
  color: THREE.Color;
}

interface PendingShot {
  delay: number;
  owner: 'player' | 'enemy';
  cannon: CannonMount;
  ship: ShipEntity;
  target: THREE.Vector3;
  spread: number;
}

interface RockObstacle {
  x: number;
  z: number;
  radius: number;
}

const SHIP_SCALE = 1.45;
const ARENA_RADIUS = 158;
const GRAVITY = 22.0;

export const PirateBattleScene: React.FC<PirateBattleSceneProps> = ({
  audioEnabled,
  resetSignal,
  onHudUpdate,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const audioRef = useRef<NavalAudioEngine | null>(null);
  const onHudUpdateRef = useRef(onHudUpdate);
  onHudUpdateRef.current = onHudUpdate;

  const resetFnRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.enabled = audioEnabled;
    }
  }, [audioEnabled]);

  useEffect(() => {
    if (resetSignal > 0 && resetFnRef.current) {
      resetFnRef.current();
    }
  }, [resetSignal]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const audio = new NavalAudioEngine();
    audio.enabled = audioEnabled;
    audioRef.current = audio;

    // ------------------------------------------------------------------------
    // 1. Software WebGL Guard & Renderer Setup
    // ------------------------------------------------------------------------
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    const handleContextLost = (e: Event) => {
      e.preventDefault();
    };
    renderer.domElement.addEventListener('webglcontextlost', handleContextLost);

    // ------------------------------------------------------------------------
    // 2. Scene, Environment Reflections, Lighting & Atmospheric Fog
    // ------------------------------------------------------------------------
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x6b9bb5);
    scene.fog = new THREE.FogExp2(0x7ca7bf, 0.0036);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTex = pmremGenerator.fromScene(roomEnv, 0.04).texture;
    scene.environment = envTex;
    roomEnv.dispose();
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(56, width / height, 0.5, 700);
    camera.position.set(0, 14, 34);

    // Sky Dome
    const skyTex = createSkyTexture();
    const skyGeo = new THREE.SphereGeometry(420, 24, 16);
    const skyMat = new THREE.MeshBasicMaterial({
      map: skyTex,
      side: THREE.BackSide,
      fog: false,
      depthWrite: false,
    });
    const skyDome = new THREE.Mesh(skyGeo, skyMat);
    scene.add(skyDome);

    // Warm golden sun disc in the distance
    const sunDiscGeo = new THREE.CircleGeometry(18, 24);
    const sunDiscMat = new THREE.MeshBasicMaterial({
      color: 0xffebc2,
      fog: false,
      depthWrite: false,
    });
    const sunDisc = new THREE.Mesh(sunDiscGeo, sunDiscMat);
    sunDisc.position.set(160, 86, -240);
    sunDisc.lookAt(0, 0, 0);
    scene.add(sunDisc);

    // 3-Point Warm/Cool Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x9bd2f2, 0x163246, 0.85);
    scene.add(hemiLight);

    const sunLight = new THREE.DirectionalLight(0xfff0d4, 2.35);
    sunLight.position.set(70, 58, -90);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.set(2048, 2048);
    sunLight.shadow.camera.near = 10;
    sunLight.shadow.camera.far = 260;
    const dShadow = 85;
    sunLight.shadow.camera.left = -dShadow;
    sunLight.shadow.camera.right = dShadow;
    sunLight.shadow.camera.top = dShadow;
    sunLight.shadow.camera.bottom = -dShadow;
    sunLight.shadow.bias = -0.0005;
    sunLight.shadow.normalBias = 0.03;
    scene.add(sunLight);
    scene.add(sunLight.target);

    const rimLight = new THREE.DirectionalLight(0x74b9e8, 0.75);
    rimLight.position.set(-60, 28, 70);
    scene.add(rimLight);

    // Reusable dynamic muzzle flash point lights (never added/removed mid-battle)
    const muzzleLights: { light: THREE.PointLight; life: number }[] = [
      { light: new THREE.PointLight(0xff9c33, 0, 26, 2), life: 0 },
      { light: new THREE.PointLight(0xff9c33, 0, 26, 2), life: 0 },
    ];
    muzzleLights.forEach((m) => scene.add(m.light));

    // ------------------------------------------------------------------------
    // 3. Shared Procedural Textures & Materials
    // ------------------------------------------------------------------------
    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const disposables: { dispose: () => void }[] = [
      envTex,
      skyTex,
      skyGeo,
      skyMat,
      sunDiscGeo,
      sunDiscMat,
    ];

    const playerHullTex = createWoodTexture('#6b4226', '#3d2210', 10, maxAniso);
    const enemyHullTex = createWoodTexture('#2e2524', '#161111', 10, maxAniso);
    const deckWoodTex = createWoodTexture('#9d7148', '#684527', 14, maxAniso);
    const playerSailTex = createSailTexture(false, maxAniso);
    const enemySailTex = createSailTexture(true, maxAniso);
    disposables.push(playerHullTex, enemyHullTex, deckWoodTex, playerSailTex, enemySailTex);

    const playerHullMat = new THREE.MeshStandardMaterial({
      map: playerHullTex,
      roughness: 0.72,
      metalness: 0.06,
    });
    const enemyHullMat = new THREE.MeshStandardMaterial({
      map: enemyHullTex,
      roughness: 0.76,
      metalness: 0.08,
    });
    const deckMat = new THREE.MeshStandardMaterial({
      map: deckWoodTex,
      roughness: 0.82,
      metalness: 0.04,
    });
    const playerTrimMat = new THREE.MeshStandardMaterial({
      color: 0xd4a23d,
      roughness: 0.3,
      metalness: 0.82,
    });
    const enemyTrimMat = new THREE.MeshStandardMaterial({
      color: 0x9e1b24,
      roughness: 0.42,
      metalness: 0.45,
    });
    const mastMat = new THREE.MeshStandardMaterial({
      color: 0x5c3a21,
      roughness: 0.84,
      metalness: 0.04,
    });
    const playerSailMat = new THREE.MeshStandardMaterial({
      map: playerSailTex,
      roughness: 0.88,
      metalness: 0.02,
      side: THREE.DoubleSide,
    });
    const enemySailMat = new THREE.MeshStandardMaterial({
      map: enemySailTex,
      roughness: 0.88,
      metalness: 0.02,
      side: THREE.DoubleSide,
    });
    const cannonMetalMat = new THREE.MeshStandardMaterial({
      color: 0x2a2f36,
      roughness: 0.28,
      metalness: 0.86,
    });
    const carriageWoodMat = new THREE.MeshStandardMaterial({
      color: 0x4d2d18,
      roughness: 0.82,
      metalness: 0.05,
    });
    const riggingMat = new THREE.LineBasicMaterial({
      color: 0x2b2017,
      transparent: true,
      opacity: 0.75,
    });
    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xffd275,
      emissive: 0xff9f2e,
      emissiveIntensity: 1.6,
      roughness: 0.25,
    });

    disposables.push(
      playerHullMat,
      enemyHullMat,
      deckMat,
      playerTrimMat,
      enemyTrimMat,
      mastMat,
      playerSailMat,
      enemySailMat,
      cannonMetalMat,
      carriageWoodMat,
      riggingMat,
      lanternMat,
    );

    // ------------------------------------------------------------------------
    // 4. 3D Animated Ocean Mesh (Realistic PBR + Multi-Octave Ripples & Foam)
    // ------------------------------------------------------------------------
    const oceanUniforms = {
      uTime: { value: 0 },
    };
    const oceanGeo = new THREE.PlaneGeometry(640, 640, 160, 160);
    oceanGeo.rotateX(-Math.PI / 2);

    const oceanMat = new THREE.MeshStandardMaterial({
      color: 0x0b4863,
      roughness: 0.1,
      metalness: 0.18,
      envMapIntensity: 1.55,
    });

    oceanMat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = oceanUniforms.uTime;

      shader.vertexShader = shader.vertexShader
        .replace(
          '#include <common>',
          `#include <common>
          uniform float uTime;
          varying float vWaveH;
          varying vec3 vWorldPos;
          float evalWave(vec2 xz, float t) {
            float p1 = dot(xz, vec2(${WAVE_1.dx}, ${WAVE_1.dz})) * ${WAVE_1.freq} + t * ${WAVE_1.speed};
            float p2 = dot(xz, vec2(${WAVE_2.dx}, ${WAVE_2.dz})) * ${WAVE_2.freq} + t * ${WAVE_2.speed};
            float p3 = dot(xz, vec2(${WAVE_3.dx}, ${WAVE_3.dz})) * ${WAVE_3.freq} + t * ${WAVE_3.speed};
            float p4 = dot(xz, vec2(${WAVE_4.dx}, ${WAVE_4.dz})) * ${WAVE_4.freq} + t * ${WAVE_4.speed};
            return sin(p1) * ${WAVE_1.amp} + sin(p2) * ${WAVE_2.amp} + sin(p3) * ${WAVE_3.amp} + sin(p4) * ${WAVE_4.amp};
          }`,
        )
        .replace(
          '#include <beginnormal_vertex>',
          `#include <beginnormal_vertex>
          vec4 worldBase = modelMatrix * vec4(position, 1.0);
          float eps = 0.55;
          float hC = evalWave(worldBase.xz, uTime);
          float hX = evalWave(worldBase.xz + vec2(eps, 0.0), uTime);
          float hZ = evalWave(worldBase.xz + vec2(0.0, eps), uTime);
          vec3 waveN = normalize(vec3(hC - hX, eps, hC - hZ));
          objectNormal = waveN;`,
        )
        .replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
          transformed.y += hC;
          vWaveH = hC;
          vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;`,
        );

      shader.fragmentShader = shader.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
          uniform float uTime;
          varying float vWaveH;
          varying vec3 vWorldPos;`,
        )
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
          vec2 wp = vWorldPos.xz;
          // Organic multi-layer foam breakup pattern
          float lacy = sin(wp.x * 0.85 + cos(wp.y * 0.72 + uTime * 1.4)) * cos(wp.y * 0.92 - sin(wp.x * 0.65 - uTime * 1.1));
          float foamCrest = smoothstep(1.08, 1.68, vWaveH + lacy * 0.24);
          float sssGlow = smoothstep(0.15, 1.35, vWaveH);

          vec3 troughCol = vec3(0.012, 0.085, 0.165);
          vec3 bodyCol = vec3(0.028, 0.23, 0.34);
          vec3 sssCol = vec3(0.075, 0.47, 0.52);
          vec3 foamCol = vec3(0.88, 0.95, 0.98);

          float tBody = smoothstep(-1.35, 0.55, vWaveH);
          diffuseColor.rgb = mix(troughCol, bodyCol, tBody);
          diffuseColor.rgb = mix(diffuseColor.rgb, sssCol, sssGlow * 0.72);
          diffuseColor.rgb = mix(diffuseColor.rgb, foamCol, foamCrest * 0.75);`,
        )
        .replace(
          '#include <normal_fragment_maps>',
          `#include <normal_fragment_maps>
          // Animated per-pixel capillary & chop ripples in world XZ transformed to view space
          vec2 rp = vWorldPos.xz;
          float r1 = sin(rp.x * 0.78 + rp.y * 0.42 + uTime * 2.4);
          float r2 = cos(rp.x * -0.62 + rp.y * 0.95 - uTime * 2.9);
          float r3 = sin(rp.x * 1.85 - rp.y * 1.35 + uTime * 3.8);
          float r4 = cos(rp.x * 2.4 + rp.y * 2.1 - uTime * 4.2);
          float dRx = 0.14 * r1 - 0.11 * r2 + 0.08 * r3 - 0.06 * r4;
          float dRz = 0.09 * r1 + 0.14 * r2 - 0.07 * r3 - 0.06 * r4;
          vec3 worldRipple = vec3(dRx, 0.0, dRz);
          vec3 viewRipple = (viewMatrix * vec4(worldRipple, 0.0)).xyz;
          normal = normalize(normal + viewRipple * 0.65);`,
        )
        .replace(
          '#include <roughnessmap_fragment>',
          `#include <roughnessmap_fragment>
          float fLacy = sin(vWorldPos.x * 0.85 + cos(vWorldPos.y * 0.72 + uTime * 1.4));
          float fMask = smoothstep(1.12, 1.65, vWaveH + fLacy * 0.2);
          roughnessFactor = mix(0.08, 0.48, fMask);`,
        );
    };

    const oceanMesh = new THREE.Mesh(oceanGeo, oceanMat);
    oceanMesh.receiveShadow = true;
    scene.add(oceanMesh);
    disposables.push(oceanGeo, oceanMat);

    // ------------------------------------------------------------------------
    // 5. Natural Sea-Stack Perimeter & Distant Islands (Avoid empty void)
    // ------------------------------------------------------------------------
    const rockObstacles: RockObstacle[] = [];
    const rockMat = new THREE.MeshStandardMaterial({
      color: 0x3b4248,
      roughness: 0.92,
      metalness: 0.04,
      flatShading: true,
    });
    const rockMossMat = new THREE.MeshStandardMaterial({
      color: 0x3f5e3b,
      roughness: 0.88,
      metalness: 0.02,
      flatShading: true,
    });
    const sandMat = new THREE.MeshStandardMaterial({
      color: 0xc2a878,
      roughness: 0.94,
      metalness: 0.01,
    });
    const baseRockGeo = new THREE.DodecahedronGeometry(1, 1);
    disposables.push(rockMat, rockMossMat, sandMat, baseRockGeo);

    const seaStackSeeds = [
      { angle: 0.25, dist: 162, scale: 9.5 },
      { angle: 0.95, dist: 170, scale: 12.0 },
      { angle: 1.62, dist: 164, scale: 8.2 },
      { angle: 2.35, dist: 174, scale: 13.5 },
      { angle: 3.1, dist: 163, scale: 9.0 },
      { angle: 3.85, dist: 172, scale: 11.5 },
      { angle: 4.55, dist: 165, scale: 10.2 },
      { angle: 5.35, dist: 168, scale: 12.4 },
      { angle: 0.6, dist: 102, scale: 5.0 },
      { angle: 3.7, dist: 106, scale: 5.4 },
    ];

    seaStackSeeds.forEach((seed, idx) => {
      const rx = Math.cos(seed.angle) * seed.dist;
      const rz = Math.sin(seed.angle) * seed.dist;
      const stackGroup = new THREE.Group();
      stackGroup.position.set(rx, -1.2, rz);

      // Composite 3-4 jagged rock tiers
      const mainSpire = new THREE.Mesh(baseRockGeo, rockMat);
      mainSpire.scale.set(seed.scale, seed.scale * 1.45, seed.scale * 0.88);
      mainSpire.rotation.set(0.1 * idx, idx * 0.9, 0.08);
      mainSpire.position.y = seed.scale * 0.65;
      mainSpire.castShadow = true;
      mainSpire.receiveShadow = true;
      stackGroup.add(mainSpire);

      const shoulder = new THREE.Mesh(baseRockGeo, rockMat);
      shoulder.scale.set(seed.scale * 0.65, seed.scale * 0.72, seed.scale * 0.7);
      shoulder.position.set(seed.scale * 0.62, seed.scale * 0.2, seed.scale * 0.25);
      shoulder.rotation.y = idx * 1.3;
      shoulder.castShadow = true;
      shoulder.receiveShadow = true;
      stackGroup.add(shoulder);

      if (seed.scale > 9) {
        const mossCap = new THREE.Mesh(baseRockGeo, rockMossMat);
        mossCap.scale.set(seed.scale * 0.56, seed.scale * 0.35, seed.scale * 0.54);
        mossCap.position.set(0, seed.scale * 1.55, 0);
        stackGroup.add(mossCap);

        const beachRing = new THREE.Mesh(new THREE.CylinderGeometry(seed.scale * 1.15, seed.scale * 1.4, 1.4, 10), sandMat);
        beachRing.position.y = 0.2;
        beachRing.receiveShadow = true;
        stackGroup.add(beachRing);
        disposables.push(beachRing.geometry);
      }

      scene.add(stackGroup);
      rockObstacles.push({ x: rx, z: rz, radius: seed.scale * 1.05 });
    });

    // ------------------------------------------------------------------------
    // 6. Procedural 3D Ship & 5-Pirate Crew Builders
    // ------------------------------------------------------------------------
    const sharedHullGeo = createHullGeometry();
    const sharedBarrelGeo = createCannonBarrelGeometry();
    const mainSailGeo = createBillowingSailGeometry(7.2, 4.4);
    const foreSailGeo = createBillowingSailGeometry(5.6, 3.6);
    const mizzenSailGeo = createBillowingSailGeometry(4.4, 2.9);
    const topSailGeo = createBillowingSailGeometry(5.0, 2.9);
    disposables.push(sharedHullGeo, sharedBarrelGeo, mainSailGeo, foreSailGeo, mizzenSailGeo, topSailGeo);

    // Pirate figure shared geometries
    const bootGeo = new THREE.BoxGeometry(0.14, 0.28, 0.2);
    const legGeo = new THREE.CylinderGeometry(0.065, 0.055, 0.38, 8);
    const torsoGeo = new THREE.CylinderGeometry(0.19, 0.16, 0.52, 8);
    const sashGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.12, 8);
    const headGeo = new THREE.SphereGeometry(0.145, 10, 10);
    const armGeo = new THREE.CylinderGeometry(0.054, 0.046, 0.42, 8);
    const hatBrimGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.04, 3);
    const hatCrownGeo = new THREE.CylinderGeometry(0.135, 0.165, 0.17, 8);
    const bandanaGeo = new THREE.SphereGeometry(0.152, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.58);
    const ramrodGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.98, 6);
    disposables.push(
      bootGeo,
      legGeo,
      torsoGeo,
      sashGeo,
      headGeo,
      armGeo,
      hatBrimGeo,
      hatCrownGeo,
      bandanaGeo,
      ramrodGeo,
    );

    const skinMat = new THREE.MeshStandardMaterial({ color: 0xe2af8c, roughness: 0.7 });
    const darkPantsMat = new THREE.MeshStandardMaterial({ color: 0x1e242e, roughness: 0.85 });
    const leatherMat = new THREE.MeshStandardMaterial({ color: 0x2c1911, roughness: 0.78 });
    const playerCoatMat = new THREE.MeshStandardMaterial({ color: 0x204b82, roughness: 0.72 });
    const enemyCoatMat = new THREE.MeshStandardMaterial({ color: 0xb5202c, roughness: 0.72 });
    const playerSashMat = new THREE.MeshStandardMaterial({ color: 0xf0b840, roughness: 0.58 });
    const enemySashMat = new THREE.MeshStandardMaterial({ color: 0xeee4d2, roughness: 0.65 });
    const beardMat = new THREE.MeshStandardMaterial({ color: 0x241811, roughness: 0.9 });
    disposables.push(
      skinMat,
      darkPantsMat,
      leatherMat,
      playerCoatMat,
      enemyCoatMat,
      playerSashMat,
      enemySashMat,
      beardMat,
    );

    function createPirateFigure(isEnemy: boolean, isCaptain: boolean): Omit<
      PirateCrewMember,
      'role' | 'localPos' | 'targetLocalPos' | 'facingYaw' | 'targetYaw' | 'stationIdx' | 'state' | 'stateTimer' | 'walkPhase'
    > {
      const root = new THREE.Group();
      root.scale.setScalar(1.32);
      const coatMat = isEnemy ? enemyCoatMat : playerCoatMat;
      const sashMat = isEnemy ? enemySashMat : playerSashMat;

      // Left leg (pivoted at hip y=0.62)
      const leftLeg = new THREE.Group();
      leftLeg.position.set(-0.09, 0.62, 0);
      const lThigh = new THREE.Mesh(legGeo, darkPantsMat);
      lThigh.position.y = -0.19;
      lThigh.castShadow = true;
      const lBoot = new THREE.Mesh(bootGeo, leatherMat);
      lBoot.position.set(0, -0.48, 0.03);
      lBoot.castShadow = true;
      leftLeg.add(lThigh, lBoot);
      root.add(leftLeg);

      // Right leg
      const rightLeg = new THREE.Group();
      rightLeg.position.set(0.09, 0.62, 0);
      const rThigh = new THREE.Mesh(legGeo, darkPantsMat);
      rThigh.position.y = -0.19;
      rThigh.castShadow = true;
      const rBoot = new THREE.Mesh(bootGeo, leatherMat);
      rBoot.position.set(0, -0.48, 0.03);
      rBoot.castShadow = true;
      rightLeg.add(rThigh, rBoot);
      root.add(rightLeg);

      // Torso + Sash
      const torso = new THREE.Mesh(torsoGeo, coatMat);
      torso.position.y = 0.88;
      torso.castShadow = true;
      root.add(torso);

      const sash = new THREE.Mesh(sashGeo, sashMat);
      sash.position.y = 0.68;
      root.add(sash);

      // Head + Beard + Hat/Bandana
      const head = new THREE.Group();
      head.position.set(0, 1.28, 0);
      const skull = new THREE.Mesh(headGeo, skinMat);
      skull.castShadow = true;
      head.add(skull);

      const beard = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.16, 6), beardMat);
      beard.rotation.x = Math.PI;
      beard.position.set(0, -0.09, 0.05);
      head.add(beard);
      disposables.push(beard.geometry);

      if (isCaptain) {
        const brim = new THREE.Mesh(hatBrimGeo, leatherMat);
        brim.position.y = 0.09;
        brim.rotation.y = Math.PI;
        const crown = new THREE.Mesh(hatCrownGeo, leatherMat);
        crown.position.y = 0.15;
        const trim = new THREE.Mesh(new THREE.CylinderGeometry(0.145, 0.145, 0.035, 8), sashMat);
        trim.position.y = 0.11;
        head.add(brim, crown, trim);
        disposables.push(trim.geometry);
      } else {
        const bandana = new THREE.Mesh(bandanaGeo, sashMat);
        bandana.position.y = 0.02;
        head.add(bandana);
      }
      root.add(head);

      // Left & Right Arms (pivoted at shoulder y=1.08)
      const leftArm = new THREE.Group();
      leftArm.position.set(-0.24, 1.08, 0);
      const lArmMesh = new THREE.Mesh(armGeo, coatMat);
      lArmMesh.position.y = -0.18;
      lArmMesh.castShadow = true;
      leftArm.add(lArmMesh);
      root.add(leftArm);

      const rightArm = new THREE.Group();
      rightArm.position.set(0.24, 1.08, 0);
      const rArmMesh = new THREE.Mesh(armGeo, coatMat);
      rArmMesh.position.y = -0.18;
      rArmMesh.castShadow = true;
      rightArm.add(rArmMesh);

      if (!isCaptain) {
        // Ramrod / linstock tool held by gunners
        const tool = new THREE.Mesh(ramrodGeo, mastMat);
        tool.rotation.x = Math.PI / 2;
        tool.position.set(0, -0.35, 0.25);
        rightArm.add(tool);
      }
      root.add(rightArm);

      return { root, leftLeg, rightLeg, leftArm, rightArm, head };
    }

    function createShip(id: 'player' | 'enemy', startX: number, startZ: number, startYaw: number): ShipEntity {
      const isEnemy = id === 'enemy';
      const group = new THREE.Group();
      group.scale.setScalar(SHIP_SCALE);
      group.position.set(startX, 0, startZ);
      group.rotation.order = 'YXZ';
      group.rotation.y = startYaw;

      const hullMat = (isEnemy ? enemyHullMat : playerHullMat).clone();
      const trimMat = isEnemy ? enemyTrimMat : playerTrimMat;
      const sailMat = isEnemy ? enemySailMat : playerSailMat;
      disposables.push(hullMat);

      // 1. Primary Silhouette: Lofted 3D Galleon Hull
      const hullMesh = new THREE.Mesh(sharedHullGeo, hullMat);
      hullMesh.castShadow = true;
      hullMesh.receiveShadow = true;
      group.add(hullMesh);

      // Main Deck & Quarterdeck planks
      const mainDeckGeo = new THREE.BoxGeometry(4.45, 0.22, 11.2);
      const mainDeck = new THREE.Mesh(mainDeckGeo, deckMat);
      mainDeck.position.set(0, 1.88, -0.6);
      mainDeck.receiveShadow = true;
      group.add(mainDeck);

      const qDeckGeo = new THREE.BoxGeometry(3.85, 0.72, 4.3);
      const qDeck = new THREE.Mesh(qDeckGeo, deckMat);
      qDeck.position.set(0, 2.25, 5.1);
      qDeck.castShadow = true;
      qDeck.receiveShadow = true;
      group.add(qDeck);

      // Foredeck / Forecastle
      const foreDeckGeo = new THREE.BoxGeometry(3.2, 0.45, 2.8);
      const foreDeck = new THREE.Mesh(foreDeckGeo, deckMat);
      foreDeck.position.set(0, 2.15, -5.6);
      foreDeck.receiveShadow = true;
      group.add(foreDeck);

      // Trim rails & Stern gallery windows + lanterns
      const sternRailGeo = new THREE.BoxGeometry(3.5, 0.22, 0.22);
      const sternRail = new THREE.Mesh(sternRailGeo, trimMat);
      sternRail.position.set(0, 2.95, 7.25);
      group.add(sternRail);

      const sternWindowGeo = new THREE.BoxGeometry(2.2, 0.55, 0.18);
      const sternWindow = new THREE.Mesh(sternWindowGeo, lanternMat);
      sternWindow.position.set(0, 2.05, 7.56);
      group.add(sternWindow);

      const lanternGeo = new THREE.CylinderGeometry(0.14, 0.1, 0.34, 6);
      [-1.3, 1.3].forEach((lx) => {
        const lMesh = new THREE.Mesh(lanternGeo, lanternMat);
        lMesh.position.set(lx, 3.15, 7.25);
        group.add(lMesh);
      });

      // Helm Wheel on Quarterdeck
      const wheelGroup = new THREE.Group();
      wheelGroup.position.set(0, 3.18, 4.15);
      const wheelPost = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.78, 0.24), carriageWoodMat);
      wheelPost.position.set(0, -0.35, 0.14);
      wheelGroup.add(wheelPost);

      const wheelRingGroup = new THREE.Group();
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.045, 8, 18), trimMat);
      wheelRingGroup.add(rim);
      for (let s = 0; s < 4; s++) {
        const spoke = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.0, 6), carriageWoodMat);
        spoke.rotation.z = (s * Math.PI) / 4;
        wheelRingGroup.add(spoke);
      }
      wheelGroup.add(wheelRingGroup);
      group.add(wheelGroup);
      disposables.push(
        mainDeckGeo,
        qDeckGeo,
        foreDeckGeo,
        sternRailGeo,
        sternWindowGeo,
        lanternGeo,
        wheelPost.geometry,
        rim.geometry,
      );

      // Cargo barrels & crates for deck depth
      const barrelGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.56, 10);
      [
        [-1.35, 2.25, 1.6],
        [-1.05, 2.25, 2.1],
        [1.35, 2.25, -1.5],
      ].forEach(([bx, by, bz]) => {
        const barrel = new THREE.Mesh(barrelGeo, carriageWoodMat);
        barrel.position.set(bx, by, bz);
        barrel.castShadow = true;
        group.add(barrel);
      });
      disposables.push(barrelGeo);

      // 2. Bowsprit & 3 Masts with Billowing Sails + Crow's Nest + Flag
      const bowspritGeo = new THREE.CylinderGeometry(0.09, 0.19, 5.6, 8);
      const bowsprit = new THREE.Mesh(bowspritGeo, mastMat);
      bowsprit.rotation.x = -Math.PI / 2 + 0.34;
      bowsprit.position.set(0, 3.05, -9.2);
      bowsprit.castShadow = true;
      group.add(bowsprit);
      disposables.push(bowspritGeo);

      const sails: THREE.Mesh[] = [];
      const mastSpecs = [
        { z: -4.2, h: 10.6, yBase: 2.1, sailGeo: foreSailGeo, sailY: 7.35, yardW: 6.0, topY: 10.1, hasTop: false },
        { z: 0.2, h: 13.4, yBase: 1.9, sailGeo: mainSailGeo, sailY: 7.75, yardW: 7.6, topY: 11.7, hasTop: true },
        { z: 4.9, h: 9.2, yBase: 2.5, sailGeo: mizzenSailGeo, sailY: 7.15, yardW: 4.8, topY: 9.5, hasTop: false },
      ];

      mastSpecs.forEach((m) => {
        const mastGeo = new THREE.CylinderGeometry(0.14, 0.26, m.h, 10);
        const mast = new THREE.Mesh(mastGeo, mastMat);
        mast.position.set(0, m.yBase + m.h * 0.5, m.z);
        mast.castShadow = true;
        group.add(mast);

        const yardGeo = new THREE.CylinderGeometry(0.08, 0.08, m.yardW, 8);
        const yard = new THREE.Mesh(yardGeo, mastMat);
        yard.rotation.z = Math.PI / 2;
        yard.position.set(0, m.sailY + 2.35, m.z - 0.18);
        yard.castShadow = true;
        group.add(yard);

        const sail = new THREE.Mesh(m.sailGeo, sailMat);
        sail.position.set(0, m.sailY, m.z - 0.35);
        sail.castShadow = true;
        group.add(sail);
        sails.push(sail);

        if (m.hasTop) {
          // Crow's nest
          const nestGeo = new THREE.CylinderGeometry(0.68, 0.5, 0.52, 10);
          const nest = new THREE.Mesh(nestGeo, carriageWoodMat);
          nest.position.set(0, m.topY - 1.2, m.z);
          group.add(nest);

          // Upper topsail
          const topYardGeo = new THREE.CylinderGeometry(0.06, 0.06, 5.4, 8);
          const topYard = new THREE.Mesh(topYardGeo, mastMat);
          topYard.rotation.z = Math.PI / 2;
          topYard.position.set(0, m.topY + 1.5, m.z - 0.16);
          group.add(topYard);

          const topSail = new THREE.Mesh(topSailGeo, sailMat);
          topSail.position.set(0, m.topY + 0.15, m.z - 0.32);
          topSail.castShadow = true;
          group.add(topSail);
          sails.push(topSail);
          disposables.push(nestGeo, topYardGeo);
        }

        disposables.push(mastGeo, yardGeo);
      });

      // Pennant Flag on Mainmast
      const flagGeo = new THREE.PlaneGeometry(2.4, 1.15, 6, 2);
      flagGeo.translate(1.2, 0, 0);
      const flagMat = new THREE.MeshStandardMaterial({
        color: isEnemy ? 0x161618 : 0x1b3b5f,
        roughness: 0.78,
        side: THREE.DoubleSide,
      });
      const flagMesh = new THREE.Mesh(flagGeo, flagMat);
      flagMesh.position.set(0, 14.1, 0.2);
      group.add(flagMesh);
      disposables.push(flagGeo, flagMat);

      // Standing Rigging Lines
      const rigPts = [
        // Stays between masts & bowsprit
        0, 3.8, -11.4, 0, 10.6, -4.2,
        0, 10.6, -4.2, 0, 13.8, 0.2,
        0, 13.8, 0.2, 0, 10.4, 4.9,
        // Shrouds (port & starboard)
        -2.25, 2.2, 0.0, 0, 10.2, 0.2,
        2.25, 2.2, 0.0, 0, 10.2, 0.2,
        -2.1, 2.2, 0.8, 0, 10.2, 0.2,
        2.1, 2.2, 0.8, 0, 10.2, 0.2,
        -1.9, 2.3, -4.2, 0, 9.2, -4.2,
        1.9, 2.3, -4.2, 0, 9.2, -4.2,
      ];
      const rigGeo = new THREE.BufferGeometry();
      rigGeo.setAttribute('position', new THREE.Float32BufferAttribute(rigPts, 3));
      const rigLines = new THREE.LineSegments(rigGeo, riggingMat);
      group.add(rigLines);
      disposables.push(rigGeo);

      // 3. Mounted 3D Cannons (3 Port, 3 Starboard, 2 Bow Chasers)
      const cannons: CannonMount[] = [];
      const carriageGeo = new THREE.BoxGeometry(0.56, 0.34, 0.82);
      const wheelGeo = new THREE.CylinderGeometry(0.13, 0.13, 0.09, 10);
      wheelGeo.rotateZ(Math.PI / 2);
      disposables.push(carriageGeo, wheelGeo);

      const addCannon = (
        side: BroadsideSide,
        lx: number,
        ly: number,
        lz: number,
        rotY: number,
        aimDirLocal: THREE.Vector3,
      ) => {
        const cRoot = new THREE.Group();
        cRoot.position.set(lx, ly, lz);
        cRoot.rotation.y = rotY;

        const carriage = new THREE.Mesh(carriageGeo, carriageWoodMat);
        carriage.position.set(0, 0.22, 0);
        carriage.castShadow = true;
        cRoot.add(carriage);

        [
          [-0.31, 0.13, 0.25],
          [0.31, 0.13, 0.25],
          [-0.31, 0.13, -0.25],
          [0.31, 0.13, -0.25],
        ].forEach(([wx, wy, wz]) => {
          const w = new THREE.Mesh(wheelGeo, cannonMetalMat);
          w.position.set(wx, wy, wz);
          cRoot.add(w);
        });

        const barrelGroup = new THREE.Group();
        barrelGroup.position.set(0, 0.44, -0.35);
        barrelGroup.rotation.x = -0.14; // slight upward ballistic elevation
        const barrelMesh = new THREE.Mesh(sharedBarrelGeo, cannonMetalMat);
        barrelMesh.castShadow = true;
        barrelGroup.add(barrelMesh);
        cRoot.add(barrelGroup);

        group.add(cRoot);
        cannons.push({
          side,
          root: cRoot,
          barrelGroup,
          muzzleLocal: new THREE.Vector3(0, 0, 1.48),
          baseLocalPos: new THREE.Vector3(0, 0.44, -0.35),
          aimDirLocal,
          recoil: 0,
        });
      };

      [-2.7, 0.0, 2.7].forEach((cz) => {
        // Port cannons face -X (rotY = -Math.PI/2 rotates +Z to -X)
        addCannon('port', -2.02, 1.98, cz, -Math.PI / 2, new THREE.Vector3(-1, 0, 0));
        // Starboard cannons face +X (rotY = +Math.PI/2 rotates +Z to +X)
        addCannon('starboard', 2.02, 1.98, cz, Math.PI / 2, new THREE.Vector3(1, 0, 0));
      });
      // 2 Bow Chasers on foredeck facing -Z (rotY = Math.PI rotates +Z to -Z)
      addCannon('bow', -0.78, 2.36, -5.85, Math.PI, new THREE.Vector3(0, 0, -1));
      addCannon('bow', 0.78, 2.36, -5.85, Math.PI, new THREE.Vector3(0, 0, -1));

      // 4. Five Stylized 3D Pirate Crew Figures per Ship (Positioned visibly across the decks)
      const crew: PirateCrewMember[] = [];
      const gunStations: { pos: THREE.Vector3; yaw: number }[] = [
        { pos: new THREE.Vector3(-1.35, 1.99, -2.7), yaw: -Math.PI / 2 },
        { pos: new THREE.Vector3(-1.35, 1.99, 0.0), yaw: -Math.PI / 2 },
        { pos: new THREE.Vector3(-1.35, 1.99, 2.7), yaw: -Math.PI / 2 },
        { pos: new THREE.Vector3(1.35, 1.99, -2.7), yaw: Math.PI / 2 },
        { pos: new THREE.Vector3(1.35, 1.99, 0.0), yaw: Math.PI / 2 },
        { pos: new THREE.Vector3(1.35, 1.99, 2.7), yaw: Math.PI / 2 },
      ];

      // Pirate 0: Captain / Helmsman at the quarterdeck wheel
      const capRig = createPirateFigure(isEnemy, true);
      const capPos = new THREE.Vector3(0, 2.61, 4.78);
      capRig.root.position.copy(capPos);
      capRig.root.rotation.y = Math.PI; // facing forward (-Z)
      group.add(capRig.root);
      crew.push({
        ...capRig,
        role: 'helmsman',
        localPos: capPos.clone(),
        targetLocalPos: capPos.clone(),
        facingYaw: Math.PI,
        targetYaw: Math.PI,
        stationIdx: -1,
        state: 'aim',
        stateTimer: 0,
        walkPhase: 0,
      });

      // Pirates 1-4: Gun crew patrolling & operating deck cannons
      const initialStations = [0, 2, 3, 5];
      for (let i = 0; i < 4; i++) {
        const stIdx = initialStations[i];
        const st = gunStations[stIdx];
        const rig = createPirateFigure(isEnemy, false);
        rig.root.position.copy(st.pos);
        rig.root.rotation.y = st.yaw;
        group.add(rig.root);
        crew.push({
          ...rig,
          role: 'gunner',
          localPos: st.pos.clone(),
          targetLocalPos: st.pos.clone(),
          facingYaw: st.yaw,
          targetYaw: st.yaw,
          stationIdx: stIdx,
          state: i % 2 === 0 ? 'reload' : 'aim',
          stateTimer: 1.2 + i * 0.65,
          walkPhase: i * 1.3,
        });
      }

      scene.add(group);

      return {
        id,
        group,
        hullMesh,
        wheelMesh: wheelRingGroup,
        flagMesh,
        sails,
        cannons,
        crew,
        x: startX,
        z: startZ,
        y: 0,
        yaw: startYaw,
        pitch: 0,
        roll: 0,
        speed: 0,
        vx: 0,
        vz: 0,
        rudderAngle: 0,
        hp: 100,
        maxHp: 100,
        reloadTimer: 0,
        reloadDuration: isEnemy ? 3.6 : 0.68,
        hitFlashTimer: 0,
        sinkProgress: 0,
        wakeTimer: 0,
        smokeTimer: 0,
      };
    }

    const playerShip = createShip('player', 0, 42, 0);
    const enemyShip = createShip('enemy', 22, -40, Math.PI * 0.72);

    // ------------------------------------------------------------------------
    // 7. 3D Aiming Reticle & Ballistic Arc Preview
    // ------------------------------------------------------------------------
    const reticleGroup = new THREE.Group();
    const reticleOuterMat = new THREE.MeshBasicMaterial({
      color: 0xfbbf24,
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const reticleOuter = new THREE.Mesh(new THREE.RingGeometry(1.75, 2.25, 32), reticleOuterMat);
    reticleOuter.rotation.x = -Math.PI / 2;
    const reticleInner = new THREE.Mesh(new THREE.RingGeometry(0.32, 0.58, 16), reticleOuterMat);
    reticleInner.rotation.x = -Math.PI / 2;
    reticleGroup.add(reticleOuter, reticleInner);
    scene.add(reticleGroup);
    disposables.push(reticleOuter.geometry, reticleInner.geometry, reticleOuterMat);

    // Ballistic preview arc line (20 points)
    const ARC_POINTS = 20;
    const arcPositions = new Float32Array(ARC_POINTS * 3);
    const arcGeo = new THREE.BufferGeometry();
    arcGeo.setAttribute('position', new THREE.BufferAttribute(arcPositions, 3));
    const arcMat = new THREE.LineDashedMaterial({
      color: 0xfde68a,
      dashSize: 1.4,
      gapSize: 0.9,
      transparent: true,
      opacity: 0.55,
    });
    const arcLine = new THREE.Line(arcGeo, arcMat);
    arcLine.frustumCulled = false;
    scene.add(arcLine);
    disposables.push(arcGeo, arcMat);

    // ------------------------------------------------------------------------
    // 8. Pooled InstancedMesh Projectiles & 3D Particle System (Zero GC)
    // ------------------------------------------------------------------------
    const MAX_BALLS = 48;
    const cannonballs: Cannonball[] = Array.from({ length: MAX_BALLS }, () => ({
      active: false,
      owner: 'player',
      pos: new THREE.Vector3(),
      vel: new THREE.Vector3(),
      age: 0,
    }));
    const ballGeo = new THREE.SphereGeometry(0.28, 10, 10);
    const ballMat = new THREE.MeshStandardMaterial({
      color: 0x1e2124,
      metalness: 0.88,
      roughness: 0.25,
    });
    const ballInstanced = new THREE.InstancedMesh(ballGeo, ballMat, MAX_BALLS);
    ballInstanced.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    ballInstanced.frustumCulled = false;
    ballInstanced.castShadow = true;
    ballInstanced.count = 0;
    scene.add(ballInstanced);
    disposables.push(ballGeo, ballMat);

    // Pooled 3D Particles (Smoke, Fire, Splash droplets, Foam rings, Wood splinters, Wake)
    const MAX_PARTICLES = 360;
    const particles: Particle[] = Array.from({ length: MAX_PARTICLES }, () => ({
      active: false,
      kind: 'smoke',
      pos: new THREE.Vector3(),
      vel: new THREE.Vector3(),
      rot: new THREE.Euler(),
      rotVel: new THREE.Vector3(),
      age: 0,
      maxAge: 1,
      startScale: 0.5,
      endScale: 1.5,
      color: new THREE.Color(0xffffff),
    }));

    const puffGeo = new THREE.DodecahedronGeometry(0.65, 1);
    const puffMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.92,
      metalness: 0.0,
    });
    const particleInstanced = new THREE.InstancedMesh(puffGeo, puffMat, MAX_PARTICLES);
    particleInstanced.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    particleInstanced.frustumCulled = false;
    particleInstanced.count = 0;
    // Initialize instanceColor buffer
    const initColor = new THREE.Color(0xffffff);
    for (let i = 0; i < MAX_PARTICLES; i++) {
      particleInstanced.setColorAt(i, initColor);
    }
    if (particleInstanced.instanceColor) particleInstanced.instanceColor.needsUpdate = true;
    scene.add(particleInstanced);
    disposables.push(puffGeo, puffMat);

    function spawnParticle(
      kind: Particle['kind'],
      px: number,
      py: number,
      pz: number,
      vx: number,
      vy: number,
      vz: number,
      maxAge: number,
      startScale: number,
      endScale: number,
      hexColor: number,
    ) {
      for (let i = 0; i < MAX_PARTICLES; i++) {
        const p = particles[i];
        if (!p.active) {
          p.active = true;
          p.kind = kind;
          p.pos.set(px, py, pz);
          p.vel.set(vx, vy, vz);
          p.rot.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
          p.rotVel.set((Math.random() - 0.5) * 4, (Math.random() - 0.5) * 4, (Math.random() - 0.5) * 4);
          p.age = 0;
          p.maxAge = maxAge;
          p.startScale = startScale;
          p.endScale = endScale;
          p.color.setHex(hexColor);
          return;
        }
      }
    }

    function spawnMuzzleBurst(wx: number, wy: number, wz: number, dirX: number, dirZ: number) {
      // Activate reusable muzzle point light
      const ml = muzzleLights[0].life <= muzzleLights[1].life ? muzzleLights[0] : muzzleLights[1];
      ml.light.position.set(wx + dirX * 0.6, wy + 0.3, wz + dirZ * 0.6);
      ml.light.intensity = 18;
      ml.life = 0.11;

      // Bright flash puff
      spawnParticle('fire', wx, wy, wz, dirX * 5, 0.8, dirZ * 5, 0.18, 0.55, 1.35, 0xffaa33);
      // Expanding cannon smoke puffs
      for (let i = 0; i < 5; i++) {
        const spread = 2.5;
        spawnParticle(
          'smoke',
          wx + dirX * 0.3,
          wy,
          wz + dirZ * 0.3,
          dirX * (4 + Math.random() * 4) + (Math.random() - 0.5) * spread,
          1.2 + Math.random() * 2.2,
          dirZ * (4 + Math.random() * 4) + (Math.random() - 0.5) * spread,
          0.9 + Math.random() * 0.55,
          0.45,
          1.95 + Math.random() * 0.6,
          0xd8dce0,
        );
      }
    }

    function spawnSplashBurst(wx: number, wy: number, wz: number) {
      // Expanding water foam ring
      spawnParticle('ring', wx, wy + 0.15, wz, 0, 0.05, 0, 0.72, 0.6, 4.2, 0xe8f6ff);
      // Water plume droplets
      for (let i = 0; i < 10; i++) {
        spawnParticle(
          'splash',
          wx + (Math.random() - 0.5) * 0.8,
          wy + 0.2,
          wz + (Math.random() - 0.5) * 0.8,
          (Math.random() - 0.5) * 5.5,
          6.5 + Math.random() * 6.5,
          (Math.random() - 0.5) * 5.5,
          0.65 + Math.random() * 0.3,
          0.32,
          0.08,
          0xdff4ff,
        );
      }
    }

    function spawnHullHitBurst(wx: number, wy: number, wz: number) {
      // Fireballs + dark smoke + spinning wood splinters
      for (let i = 0; i < 4; i++) {
        spawnParticle(
          'fire',
          wx,
          wy,
          wz,
          (Math.random() - 0.5) * 5,
          2.2 + Math.random() * 3,
          (Math.random() - 0.5) * 5,
          0.32 + Math.random() * 0.15,
          0.65,
          1.8,
          i % 2 === 0 ? 0xff7b1c : 0xffd152,
        );
      }
      for (let i = 0; i < 5; i++) {
        spawnParticle(
          'smoke',
          wx,
          wy + 0.4,
          wz,
          (Math.random() - 0.5) * 4,
          2.8 + Math.random() * 2.5,
          (Math.random() - 0.5) * 4,
          1.1 + Math.random() * 0.4,
          0.55,
          2.2,
          0x2c2f33,
        );
      }
      for (let i = 0; i < 8; i++) {
        spawnParticle(
          'splinter',
          wx,
          wy,
          wz,
          (Math.random() - 0.5) * 11,
          4.5 + Math.random() * 6.5,
          (Math.random() - 0.5) * 11,
          0.85 + Math.random() * 0.35,
          0.34,
          0.24,
          0x8c562c,
        );
      }
    }

    // ------------------------------------------------------------------------
    // 9. Input, Aiming, Firing & window.pirateGame API
    // ------------------------------------------------------------------------
    const keys: Record<string, boolean> = {};
    const apiInputs = {
      left: false,
      right: false,
      up: false,
      down: false,
      leftImpulse: 0,
      rightImpulse: 0,
      upImpulse: 0,
      downImpulse: 0,
    };

    const mouseNdc = new THREE.Vector2(0, 0.08);
    const aimWorldPos = new THREE.Vector3(0, 0, -18);
    const agentAimTarget = new THREE.Vector3();
    let targetLockedOnEnemy = false;

    const pendingShots: PendingShot[] = [];
    const combatBurstDelays: number[] = [];
    let outcome: BattleOutcome = 'playing';
    let shotsFired = 0;
    let hitsLanded = 0;
    let elapsedSec = 0;
    let cameraShake = 0;
    let lastHitNotice = '';
    let lastHitTimer = 0;
    let tacticalNotice = '';
    let tacticalTimer = 0;
    let prevPlayerSteer = 0;

    // Camera smooth state
    const camPos = new THREE.Vector3(0, 15, 62);
    const camLook = new THREE.Vector3(0, 2, 10);
    let camYawOffset = 0;
    let camPitchOffset = 0.28;

    function launchBall(owner: 'player' | 'enemy', cannon: CannonMount, ship: ShipEntity, target: THREE.Vector3, spread: number) {
      // Compute barrel tip world position
      ship.group.updateMatrixWorld(true);
      _v1.copy(cannon.muzzleLocal);
      cannon.barrelGroup.localToWorld(_v1);

      const dx = target.x + (Math.random() - 0.5) * spread - _v1.x;
      const dy = target.y - _v1.y;
      const dz = target.z + (Math.random() - 0.5) * spread - _v1.z;
      const horizDist = Math.hypot(dx, dz);
      const flightTime = THREE.MathUtils.clamp(horizDist / 52, 0.24, 2.35);

      for (let i = 0; i < MAX_BALLS; i++) {
        const b = cannonballs[i];
        if (!b.active) {
          b.active = true;
          b.owner = owner;
          b.age = 0;
          b.pos.copy(_v1);
          b.vel.set(
            dx / flightTime,
            (dy + 0.5 * GRAVITY * flightTime * flightTime) / flightTime,
            dz / flightTime,
          );
          break;
        }
      }

      cannon.recoil = 0.52;

      // World firing direction for muzzle blast
      _v2.copy(cannon.aimDirLocal).applyQuaternion(ship.group.quaternion).normalize();
      spawnMuzzleBurst(_v1.x, _v1.y, _v1.z, _v2.x, _v2.z);

      // Trigger nearby gunners to recoil/fire pose
      ship.crew.forEach((member) => {
        if (member.role === 'gunner' && member.localPos.distanceTo(cannon.root.position) < 4.5) {
          member.state = 'fire';
          member.stateTimer = 0.55;
        }
      });
    }

    function getActiveBroadsideSide(ship: ShipEntity, worldTarget: THREE.Vector3): BroadsideSide {
      _v1.copy(worldTarget);
      ship.group.worldToLocal(_v1);
      if (_v1.x < -2.2) return 'port';
      if (_v1.x > 2.2) return 'starboard';
      return 'bow';
    }

    function fireShipVolley(ship: ShipEntity, worldTarget: THREE.Vector3, spread: number): boolean {
      if (ship.reloadTimer > 0 || ship.hp <= 0 || outcome !== 'playing') return false;
      const side = getActiveBroadsideSide(ship, worldTarget);
      const sideCannons = ship.cannons.filter((c) => c.side === side);
      if (sideCannons.length === 0) return false;

      // Pick the single cannon on that facing side closest to the target
      let bestCannon = sideCannons[0];
      let bestDistSq = Infinity;
      ship.group.updateMatrixWorld(true);
      for (let i = 0; i < sideCannons.length; i++) {
        _v2.copy(sideCannons[i].muzzleLocal);
        sideCannons[i].barrelGroup.localToWorld(_v2);
        const dSq = _v2.distanceToSquared(worldTarget);
        if (dSq < bestDistSq) {
          bestDistSq = dSq;
          bestCannon = sideCannons[i];
        }
      }

      ship.reloadTimer = ship.reloadDuration;
      launchBall(ship.id, bestCannon, ship, worldTarget, spread);

      if (ship.id === 'player') {
        shotsFired += 1;
        cameraShake = Math.max(cameraShake, 0.22);
        const sideLabel =
          side === 'port' ? 'Port Broadside Fired' : side === 'starboard' ? 'Starboard Broadside Fired' : 'Bow Chasers Fired';
        tacticalNotice = sideLabel;
        tacticalTimer = 1.25;
      }
      audio.playCannon(ship.id === 'player' ? 0.45 : 0.24);
      return true;
    }

    // Expose window.pirateGame API
    window.pirateGame = {
      steerLeft: (active?: boolean) => {
        if (typeof active === 'boolean') apiInputs.left = active;
        else apiInputs.leftImpulse = 0.45;
      },
      steerRight: (active?: boolean) => {
        if (typeof active === 'boolean') apiInputs.right = active;
        else apiInputs.rightImpulse = 0.45;
      },
      throttleUp: (active?: boolean) => {
        if (typeof active === 'boolean') apiInputs.up = active;
        else apiInputs.upImpulse = 0.55;
      },
      throttleDown: (active?: boolean) => {
        if (typeof active === 'boolean') apiInputs.down = active;
        else apiInputs.downImpulse = 0.55;
      },
      fire: () => {
        audio.unlock();
        return fireShipVolley(playerShip, aimWorldPos, 0.35);
      },
    };

    function getAgentAimTarget(out: THREE.Vector3): THREE.Vector3 {
      if (targetLockedOnEnemy || enemyShip.hp <= 0) {
        return out.copy(aimWorldPos);
      }
      const dx = enemyShip.x - playerShip.x;
      const dz = enemyShip.z - playerShip.z;
      const dist = Math.hypot(dx, dz);
      const leadTime = THREE.MathUtils.clamp(dist / 52, 0.24, 2.35);
      return out.set(
        enemyShip.x + enemyShip.vx * leadTime * 0.65,
        enemyShip.y + 1.65,
        enemyShip.z + enemyShip.vz * leadTime * 0.65,
      );
    }

    // Expose window.pirateAgent API (tuned for fast AI piloting)
    window.pirateAgent = {
      steerLeft: (durationMs = 1800) => {
        apiInputs.rightImpulse = 0;
        apiInputs.leftImpulse = Math.max(0, durationMs) / 1000;
        if (outcome === 'playing') {
          tacticalNotice = 'Helm to Port · Evading';
          tacticalTimer = 1.4;
        }
      },
      steerRight: (durationMs = 1800) => {
        apiInputs.leftImpulse = 0;
        apiInputs.rightImpulse = Math.max(0, durationMs) / 1000;
        if (outcome === 'playing') {
          tacticalNotice = 'Helm to Starboard · Evading';
          tacticalTimer = 1.4;
        }
      },
      accelerate: () => {
        apiInputs.downImpulse = 0;
        apiInputs.upImpulse = 2.6;
        if (outcome === 'playing' && playerShip.hp > 0) {
          playerShip.speed = Math.min(30.0, Math.max(playerShip.speed + 9.5, 16.0));
          tacticalNotice = 'Full Sail · Ahead';
          tacticalTimer = 1.4;
        }
      },
      slowDown: () => {
        apiInputs.upImpulse = 0;
        apiInputs.downImpulse = 1.6;
        if (outcome === 'playing' && playerShip.hp > 0 && playerShip.speed > 4) {
          playerShip.speed *= 0.55;
        }
        if (outcome === 'playing') {
          tacticalNotice = 'Reefing Sails · Slowing';
          tacticalTimer = 1.4;
        }
      },
      fireBroadside: () => {
        audio.unlock();
        if (outcome !== 'playing' || playerShip.hp <= 0) return false;
        // Allow rapid salvo firing for AI commands with brief 0.14s cadence floor
        if (playerShip.reloadTimer > 0 && playerShip.reloadTimer <= playerShip.reloadDuration - 0.14) {
          playerShip.reloadTimer = 0;
        }
        getAgentAimTarget(agentAimTarget);
        return fireShipVolley(playerShip, agentAimTarget, 0.3);
      },
      combatBurst: () => {
        audio.unlock();
        if (outcome !== 'playing' || playerShip.hp <= 0) return false;
        window.pirateAgent?.accelerate();
        // Smooth tactical turn to bring broadside cannons onto enemy & dodge incoming fire
        playerShip.group.updateMatrixWorld(true);
        _v1.set(enemyShip.x, enemyShip.y, enemyShip.z);
        playerShip.group.worldToLocal(_v1);
        if (_v1.x >= 0) {
          window.pirateAgent?.steerLeft(1500);
        } else {
          window.pirateAgent?.steerRight(1500);
        }
        // Fire immediate lead shot + queue two rapid follow-up salvo shots
        playerShip.reloadTimer = 0;
        getAgentAimTarget(agentAimTarget);
        const fired = fireShipVolley(playerShip, agentAimTarget, 0.28);
        combatBurstDelays.length = 0;
        combatBurstDelays.push(0.2, 0.4);
        tacticalNotice = 'Athena Maneuver · Evasive Broadside';
        tacticalTimer = 1.6;
        return fired;
      },
      restartGame: () => {
        if (outcome === 'victory' || outcome === 'defeat') {
          resetBattle();
          return true;
        }
        return false;
      },
      getBattleState: () => ({
        playerHp: playerShip.hp,
        enemyHp: enemyShip.hp,
        cannonsReady: playerShip.reloadTimer <= Math.max(0, playerShip.reloadDuration - 0.14) && outcome === 'playing',
        heading: ((Math.round((-playerShip.yaw * 180) / Math.PI) % 360) + 360) % 360,
        speed: Math.round(Math.abs(playerShip.speed) * 1.15),
        status: outcome,
      }),
    };

    const onKeyDown = (e: KeyboardEvent) => {
      audio.unlock();
      keys[e.code] = true;
      if (e.code === 'Space' && outcome === 'playing') {
        e.preventDefault();
        fireShipVolley(playerShip, aimWorldPos, 0.35);
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    const onPointerMove = (e: PointerEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouseNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouseNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return;
      audio.unlock();
      onPointerMove(e);
      if (outcome === 'playing') {
        fireShipVolley(playerShip, aimWorldPos, 0.35);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    // ------------------------------------------------------------------------
    // 10. Reset / Replay Function
    // ------------------------------------------------------------------------
    const resetBattle = () => {
      playerShip.x = 0;
      playerShip.z = 42;
      playerShip.y = 0;
      playerShip.yaw = 0;
      playerShip.pitch = 0;
      playerShip.roll = 0;
      playerShip.speed = 0;
      playerShip.vx = 0;
      playerShip.vz = 0;
      playerShip.rudderAngle = 0;
      playerShip.hp = playerShip.maxHp;
      playerShip.reloadTimer = 0;
      playerShip.hitFlashTimer = 0;
      playerShip.sinkProgress = 0;

      enemyShip.x = 22;
      enemyShip.z = -40;
      enemyShip.y = 0;
      enemyShip.yaw = Math.PI * 0.72;
      enemyShip.pitch = 0;
      enemyShip.roll = 0;
      enemyShip.speed = 9;
      enemyShip.vx = 0;
      enemyShip.vz = 0;
      enemyShip.rudderAngle = 0;
      enemyShip.hp = enemyShip.maxHp;
      enemyShip.reloadTimer = 2.0;
      enemyShip.hitFlashTimer = 0;
      enemyShip.sinkProgress = 0;

      cannonballs.forEach((b) => {
        b.active = false;
      });
      particles.forEach((p) => {
        p.active = false;
      });
      pendingShots.length = 0;
      combatBurstDelays.length = 0;
      outcome = 'playing';
      shotsFired = 0;
      hitsLanded = 0;
      elapsedSec = 0;
      cameraShake = 0;
      lastHitNotice = '';
      lastHitTimer = 0;
      tacticalNotice = '';
      tacticalTimer = 0;
      prevPlayerSteer = 0;
      hudEmitTimer = 1;
    };
    resetFnRef.current = resetBattle;

    // ------------------------------------------------------------------------
    // 11. Ship Physics, Wave Floating, Crew Animation & AI Update
    // ------------------------------------------------------------------------
    const gunStationTargets: { pos: THREE.Vector3; yaw: number }[] = [
      { pos: new THREE.Vector3(-1.25, 1.99, -2.7), yaw: -Math.PI / 2 },
      { pos: new THREE.Vector3(-1.25, 1.99, 0.0), yaw: -Math.PI / 2 },
      { pos: new THREE.Vector3(-1.25, 1.99, 2.7), yaw: -Math.PI / 2 },
      { pos: new THREE.Vector3(1.25, 1.99, -2.7), yaw: Math.PI / 2 },
      { pos: new THREE.Vector3(1.25, 1.99, 0.0), yaw: Math.PI / 2 },
      { pos: new THREE.Vector3(1.25, 1.99, 2.7), yaw: Math.PI / 2 },
      { pos: new THREE.Vector3(-0.68, 2.38, -4.85), yaw: Math.PI },
      { pos: new THREE.Vector3(0.68, 2.38, -4.85), yaw: Math.PI },
    ];

    function updateShipMotion(
      ship: ShipEntity,
      throttle: number,
      steer: number,
      dt: number,
      time: number,
    ) {
      if (ship.hp <= 0) {
        ship.sinkProgress = Math.min(1, ship.sinkProgress + dt * 0.24);
        ship.y = THREE.MathUtils.damp(ship.y, -9.5, 1.4, dt);
        ship.roll = THREE.MathUtils.damp(ship.roll, 0.62, 1.6, dt);
        ship.pitch = THREE.MathUtils.damp(ship.pitch, -0.35, 1.5, dt);
        ship.group.position.set(ship.x, ship.y, ship.z);
        ship.group.rotation.set(ship.pitch, ship.yaw, ship.roll);
        return;
      }

      // Thrust & Water Drag (Fast, responsive naval handling)
      const maxForward = ship.id === 'player' ? 30.0 : 20.5;
      const maxReverse = -9.5;
      const targetSpeed = throttle > 0 ? throttle * maxForward : throttle * Math.abs(maxReverse);
      const accelRate = throttle !== 0 ? 3.5 : 1.5;
      ship.speed = THREE.MathUtils.damp(ship.speed, targetSpeed, accelRate, dt);

      // Rudder yaw (ships turn slightly faster with headway, plus small static pivot for responsiveness)
      ship.rudderAngle = THREE.MathUtils.damp(ship.rudderAngle, steer, 6.5, dt);
      const turnAuthority = 0.48 + 0.52 * Math.min(1, Math.abs(ship.speed) / 9.0);
      const turnDir = ship.speed < -0.5 ? -1 : 1;
      const turnSpeed = ship.id === 'player' ? 1.22 : 0.92;
      ship.yaw += ship.rudderAngle * turnAuthority * turnDir * turnSpeed * dt;

      // Rotate helm wheel visibly
      ship.wheelMesh.rotation.z = -ship.rudderAngle * 2.2;

      // Forward vector (-Z in local space)
      const fwdX = -Math.sin(ship.yaw);
      const fwdZ = -Math.cos(ship.yaw);
      ship.vx = fwdX * ship.speed;
      ship.vz = fwdZ * ship.speed;
      ship.x += ship.vx * dt;
      ship.z += ship.vz * dt;

      // Arena perimeter soft pushback & sea-stack obstacle avoidance
      const distFromCenter = Math.hypot(ship.x, ship.z);
      if (distFromCenter > ARENA_RADIUS) {
        const inv = ARENA_RADIUS / distFromCenter;
        ship.x *= inv;
        ship.z *= inv;
        ship.speed *= 0.88;
      }

      for (let i = 0; i < rockObstacles.length; i++) {
        const r = rockObstacles[i];
        const dx = ship.x - r.x;
        const dz = ship.z - r.z;
        const dist = Math.hypot(dx, dz);
        const minSep = r.radius + 4.4 * SHIP_SCALE;
        if (dist < minSep && dist > 0.001) {
          const push = (minSep - dist) / dist;
          ship.x += dx * push;
          ship.z += dz * push;
          ship.speed *= 0.72;
        }
      }

      // 4-point ocean wave sampling for authentic Pitch, Roll & Heave (scaled for larger hull)
      const cosY = Math.cos(ship.yaw);
      const sinY = Math.sin(ship.yaw);
      const bowDist = 6.5 * SHIP_SCALE;
      const beamDist = 2.5 * SHIP_SCALE;
      const hBow = getWaveHeight(ship.x - sinY * bowDist, ship.z - cosY * bowDist, time);
      const hStern = getWaveHeight(ship.x + sinY * bowDist, ship.z + cosY * bowDist, time);
      const hPort = getWaveHeight(ship.x - cosY * beamDist, ship.z + sinY * beamDist, time);
      const hStar = getWaveHeight(ship.x + cosY * beamDist, ship.z - sinY * beamDist, time);

      const targetY = (hBow + hStern + hPort + hStar) * 0.25 - 0.24;
      const targetPitch = Math.atan2(hBow - hStern, bowDist * 2) * 0.92;
      const turnBank = -ship.rudderAngle * Math.min(1, Math.abs(ship.speed) / 18) * 0.11;
      const targetRoll = Math.atan2(hStar - hPort, beamDist * 2) * 0.92 + turnBank;

      ship.y = THREE.MathUtils.damp(ship.y, targetY, 5.5, dt);
      ship.pitch = THREE.MathUtils.damp(ship.pitch, targetPitch, 5.2, dt);
      ship.roll = THREE.MathUtils.damp(ship.roll, targetRoll, 5.2, dt);

      ship.group.position.set(ship.x, ship.y, ship.z);
      ship.group.rotation.set(ship.pitch, ship.yaw, ship.roll);

      // Cooldown & Hit flash
      if (ship.reloadTimer > 0) ship.reloadTimer = Math.max(0, ship.reloadTimer - dt);
      if (ship.hitFlashTimer > 0) {
        ship.hitFlashTimer = Math.max(0, ship.hitFlashTimer - dt);
        const hullMaterial = ship.hullMesh.material as THREE.MeshStandardMaterial;
        hullMaterial.emissive.setHex(ship.hitFlashTimer > 0 ? 0x6b1d08 : 0x000000);
        hullMaterial.emissiveIntensity = ship.hitFlashTimer * 3.0;
      }

      // Cannon recoil recovery
      for (let i = 0; i < ship.cannons.length; i++) {
        const c = ship.cannons[i];
        c.recoil = THREE.MathUtils.damp(c.recoil, 0, 8.5, dt);
        c.barrelGroup.position.z = c.baseLocalPos.z - c.recoil;
      }

      // Sail billow & flag flutter
      const windFactor = 0.92 + Math.min(0.28, Math.abs(ship.speed) * 0.015) + Math.sin(time * 2.2) * 0.04;
      for (let i = 0; i < ship.sails.length; i++) {
        ship.sails[i].scale.z = windFactor;
      }
      ship.flagMesh.rotation.y = Math.sin(time * 6.5) * 0.22 + 0.15;

      // Wake foam particles while sailing
      ship.wakeTimer -= dt;
      if (Math.abs(ship.speed) > 2.5 && ship.wakeTimer <= 0) {
        ship.wakeTimer = 0.08;
        const bowX = ship.x - sinY * (7.5 * SHIP_SCALE);
        const bowZ = ship.z - cosY * (7.5 * SHIP_SCALE);
        const sternX = ship.x + sinY * (7.8 * SHIP_SCALE);
        const sternZ = ship.z + cosY * (7.8 * SHIP_SCALE);
        spawnParticle(
          'wake',
          bowX + (Math.random() - 0.5) * 1.4,
          getWaveHeight(bowX, bowZ, time) + 0.12,
          bowZ + (Math.random() - 0.5) * 1.4,
          (Math.random() - 0.5) * 2.2,
          0.15,
          (Math.random() - 0.5) * 2.2,
          0.9,
          0.45,
          1.75,
          0xd8eef7,
        );
        spawnParticle(
          'wake',
          sternX + (Math.random() - 0.5) * 1.6,
          getWaveHeight(sternX, sternZ, time) + 0.1,
          sternZ + (Math.random() - 0.5) * 1.6,
          0,
          0.08,
          0,
          1.15,
          0.65,
          2.3,
          0xc8e5f2,
        );
      }

      // Persistent hull damage smoke when HP < 70%
      if (ship.hp < ship.maxHp * 0.7) {
        ship.smokeTimer -= dt;
        const rate = ship.hp < ship.maxHp * 0.35 ? 0.1 : 0.22;
        if (ship.smokeTimer <= 0) {
          ship.smokeTimer = rate;
          const sx = ship.x + (Math.random() - 0.5) * 2.2;
          const sz = ship.z + (Math.random() - 0.5) * 4.5;
          spawnParticle(
            'smoke',
            sx,
            ship.y + 2.4,
            sz,
            (Math.random() - 0.5) * 1.2,
            2.4 + Math.random() * 1.6,
            (Math.random() - 0.5) * 1.2,
            1.4,
            0.55,
            2.1,
            ship.hp < ship.maxHp * 0.35 ? 0x222226 : 0x45494f,
          );
          if (ship.hp < ship.maxHp * 0.4 && Math.random() < 0.45) {
            spawnParticle('fire', sx, ship.y + 2.3, sz, 0, 2.2, 0, 0.35, 0.4, 0.9, 0xff7722);
          }
        }
      }
    }

    function updateCrewAnimations(ship: ShipEntity, steer: number, dt: number, time: number) {
      for (let i = 0; i < ship.crew.length; i++) {
        const p = ship.crew[i];

        if (p.role === 'helmsman') {
          // Captain / Helmsman grips the wheel & leans into turns
          p.leftLeg.rotation.x = 0;
          p.rightLeg.rotation.x = 0;
          p.leftArm.rotation.x = -1.05 + steer * 0.25;
          p.rightArm.rotation.x = -1.05 - steer * 0.25;
          p.head.rotation.y = Math.sin(time * 0.8 + i) * 0.28;
          p.root.position.y = p.localPos.y + Math.sin(time * 3.0) * 0.015;
          continue;
        }

        // Gunner crew: move between gun stations, reload, aim, and fire
        p.stateTimer -= dt;
        if (p.state === 'walk') {
          const dx = p.targetLocalPos.x - p.localPos.x;
          const dz = p.targetLocalPos.z - p.localPos.z;
          const dist = Math.hypot(dx, dz);
          if (dist < 0.08) {
            p.localPos.copy(p.targetLocalPos);
            p.state = 'reload';
            p.stateTimer = 1.4 + Math.random() * 1.1;
          } else {
            const step = Math.min(dist, 2.2 * dt);
            p.localPos.x += (dx / dist) * step;
            p.localPos.z += (dz / dist) * step;
            p.targetYaw = Math.atan2(dx, dz);
            p.walkPhase += dt * 10.5;
            p.leftLeg.rotation.x = Math.sin(p.walkPhase) * 0.55;
            p.rightLeg.rotation.x = -Math.sin(p.walkPhase) * 0.55;
            p.leftArm.rotation.x = -Math.sin(p.walkPhase) * 0.45;
            p.rightArm.rotation.x = Math.sin(p.walkPhase) * 0.45;
          }
        } else if (p.state === 'reload') {
          // Ramrod loading thrust motion
          p.targetYaw = gunStationTargets[p.stationIdx].yaw;
          const ram = Math.sin(time * 7.5 + i * 1.7) * 0.42;
          p.leftLeg.rotation.x = -0.15;
          p.rightLeg.rotation.x = 0.15;
          p.leftArm.rotation.x = -1.1 + ram;
          p.rightArm.rotation.x = -1.25 + ram;
          if (p.stateTimer <= 0) {
            p.state = 'aim';
            p.stateTimer = 1.6 + Math.random() * 1.2;
          }
        } else if (p.state === 'aim') {
          p.targetYaw = gunStationTargets[p.stationIdx].yaw;
          p.leftLeg.rotation.x = 0;
          p.rightLeg.rotation.x = 0;
          p.leftArm.rotation.x = -0.45 + Math.sin(time * 2.5 + i) * 0.08;
          p.rightArm.rotation.x = -0.85;
          if (p.stateTimer <= 0) {
            // Move to another gun station along the deck
            const nextIdx = (p.stationIdx + 1 + Math.floor(Math.random() * 3)) % gunStationTargets.length;
            p.stationIdx = nextIdx;
            p.targetLocalPos.copy(gunStationTargets[nextIdx].pos);
            p.state = 'walk';
            p.stateTimer = 4.0;
          }
        } else if (p.state === 'fire') {
          // Recoil brace & linstock swing
          p.leftArm.rotation.x = -1.65;
          p.rightArm.rotation.x = -1.85;
          p.leftLeg.rotation.x = 0.25;
          p.rightLeg.rotation.x = -0.25;
          if (p.stateTimer <= 0) {
            p.state = 'reload';
            p.stateTimer = 1.5;
          }
        }

        // Smooth facing yaw & deck Y height
        let diff = p.targetYaw - p.facingYaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        p.facingYaw += diff * Math.min(1, dt * 8);

        p.root.position.set(
          p.localPos.x,
          p.localPos.y + (p.state === 'walk' ? Math.abs(Math.sin(p.walkPhase)) * 0.05 : 0),
          p.localPos.z,
        );
        p.root.rotation.y = p.facingYaw;
      }
    }

    function updateEnemyAI(dt: number, time: number): { throttle: number; steer: number } {
      if (enemyShip.hp <= 0 || playerShip.hp <= 0) {
        return { throttle: 0, steer: 0 };
      }

      const dx = playerShip.x - enemyShip.x;
      const dz = playerShip.z - enemyShip.z;
      const dist = Math.max(1, Math.hypot(dx, dz));
      const angleToPlayer = Math.atan2(-dx, -dz);

      // Desired course: circle/flank at ~52 units to present broadside
      const preferredDist = 52;
      const radialBias = THREE.MathUtils.clamp((dist - preferredDist) / 28, -0.75, 0.75);
      let desiredYaw = angleToPlayer + Math.PI / 2 - radialBias * 0.85;

      // Boundary & rock avoidance override
      const distCenter = Math.hypot(enemyShip.x, enemyShip.z);
      if (distCenter > ARENA_RADIUS - 24) {
        desiredYaw = Math.atan2(enemyShip.x, enemyShip.z); // steer back toward center (0,0)
      } else {
        for (let i = 0; i < rockObstacles.length; i++) {
          const r = rockObstacles[i];
          const rdx = enemyShip.x - r.x;
          const rdz = enemyShip.z - r.z;
          const rDist = Math.hypot(rdx, rdz);
          if (rDist < r.radius + 22) {
            desiredYaw = Math.atan2(-rdx, -rdz);
            break;
          }
        }
      }

      let yawErr = desiredYaw - enemyShip.yaw;
      while (yawErr > Math.PI) yawErr -= Math.PI * 2;
      while (yawErr < -Math.PI) yawErr += Math.PI * 2;

      const steer = THREE.MathUtils.clamp(yawErr * 1.5, -1, 1);
      const throttle = dist < 24 ? 0.45 : 0.82;

      // Gentle AI aiming (1 single shot, generous dispersion so player can easily dodge)
      if (enemyShip.reloadTimer <= 0 && dist < 96) {
        const leadTime = dist / 52;
        _v3.set(
          playerShip.x + playerShip.vx * leadTime * 0.35,
          playerShip.y + 1.8,
          playerShip.z + playerShip.vz * leadTime * 0.35,
        );
        const side = getActiveBroadsideSide(enemyShip, _v3);
        if (side !== 'bow' || Math.sin(time) > 0.25) {
          fireShipVolley(enemyShip, _v3, 9.5);
        }
      }

      return { throttle, steer };
    }

    function resolveShipToShipCollision() {
      if (playerShip.hp <= 0 || enemyShip.hp <= 0) return;
      const dx = enemyShip.x - playerShip.x;
      const dz = enemyShip.z - playerShip.z;
      const dist = Math.hypot(dx, dz);
      const minDist = 11.2 * SHIP_SCALE;
      if (dist < minDist && dist > 0.001) {
        const overlap = (minDist - dist) * 0.5;
        const nx = dx / dist;
        const nz = dz / dist;
        playerShip.x -= nx * overlap;
        playerShip.z -= nz * overlap;
        enemyShip.x += nx * overlap;
        enemyShip.z += nz * overlap;
        playerShip.speed *= 0.65;
        enemyShip.speed *= 0.65;
      }
    }

    function checkCannonballShipHit(ball: Cannonball, ship: ShipEntity): boolean {
      if (ship.hp <= 0) return false;
      // Transform ball into ship local space for OBB hull collision
      _v4.copy(ball.pos);
      ship.group.worldToLocal(_v4);
      const xTol = ship.id === 'enemy' ? 3.25 : 2.85;
      const yMax = ship.id === 'enemy' ? 6.4 : 5.4;
      return (
        Math.abs(_v4.x) < xTol &&
        _v4.y > -1.0 &&
        _v4.y < yMax &&
        _v4.z > -8.4 &&
        _v4.z < 8.0
      );
    }

    // ------------------------------------------------------------------------
    // 12. Main 60 FPS Animation & Physics Loop (Software-WebGL Paced)
    // ------------------------------------------------------------------------
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const clock = new THREE.Clock();
    let frameId = 0;
    let hudEmitTimer = 0;

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      const rawDt = clock.getDelta();
      const dt = Math.min(rawDt, 0.05);
      const elapsed = clock.elapsedTime;
      oceanUniforms.uTime.value = elapsed;

      if (outcome === 'playing') {
        elapsedSec += dt;
      }
      if (lastHitTimer > 0) {
        lastHitTimer = Math.max(0, lastHitTimer - dt);
        if (lastHitTimer === 0) lastHitNotice = '';
      }
      if (tacticalTimer > 0) {
        tacticalTimer = Math.max(0, tacticalTimer - dt);
        if (tacticalTimer === 0) tacticalNotice = '';
      }

      // Decay API impulses
      if (apiInputs.leftImpulse > 0) apiInputs.leftImpulse = Math.max(0, apiInputs.leftImpulse - dt);
      if (apiInputs.rightImpulse > 0) apiInputs.rightImpulse = Math.max(0, apiInputs.rightImpulse - dt);
      if (apiInputs.upImpulse > 0) apiInputs.upImpulse = Math.max(0, apiInputs.upImpulse - dt);
      if (apiInputs.downImpulse > 0) apiInputs.downImpulse = Math.max(0, apiInputs.downImpulse - dt);

      // Player WASD + API inputs
      const pUp = keys['KeyW'] || keys['ArrowUp'] || apiInputs.up || apiInputs.upImpulse > 0;
      const pDown = keys['KeyS'] || keys['ArrowDown'] || apiInputs.down || apiInputs.downImpulse > 0;
      const pLeft = keys['KeyA'] || keys['ArrowLeft'] || apiInputs.left || apiInputs.leftImpulse > 0;
      const pRight = keys['KeyD'] || keys['ArrowRight'] || apiInputs.right || apiInputs.rightImpulse > 0;

      const playerThrottle = (pUp ? 1 : 0) - (pDown ? 1 : 0);
      const playerSteer = (pLeft ? 1 : 0) - (pRight ? 1 : 0);

      if (outcome === 'playing' && playerSteer !== prevPlayerSteer && playerSteer !== 0 && tacticalTimer <= 0.4) {
        tacticalNotice = playerSteer > 0 ? 'Helm to Port · Evading' : 'Helm to Starboard · Evading';
        tacticalTimer = 1.1;
      }
      prevPlayerSteer = playerSteer;

      // Update Player & AI Ships
      updateShipMotion(playerShip, playerThrottle, playerSteer, dt, elapsed);
      const aiCtrl = updateEnemyAI(dt, elapsed);
      updateShipMotion(enemyShip, aiCtrl.throttle, aiCtrl.steer, dt, elapsed);
      resolveShipToShipCollision();

      // Update 5 Pirate Crew Figures per Ship
      updateCrewAnimations(playerShip, playerSteer, dt, elapsed);
      updateCrewAnimations(enemyShip, aiCtrl.steer, dt, elapsed);

      // Update 3D Camera (Smooth chase + mouse aim azimuth)
      const targetYawOffset = -mouseNdc.x * 1.48;
      const targetPitchOffset = THREE.MathUtils.clamp(0.32 - mouseNdc.y * 0.24, 0.14, 0.62);
      camYawOffset = THREE.MathUtils.damp(camYawOffset, targetYawOffset, 5.5, dt);
      camPitchOffset = THREE.MathUtils.damp(camPitchOffset, targetPitchOffset, 5.5, dt);

      const camDist = 37.5;
      const totalYaw = playerShip.yaw + camYawOffset;
      const desiredCamX = playerShip.x + Math.sin(totalYaw) * Math.cos(camPitchOffset) * camDist;
      const desiredCamY = playerShip.y + Math.sin(camPitchOffset) * camDist + 5.2;
      const desiredCamZ = playerShip.z + Math.cos(totalYaw) * Math.cos(camPitchOffset) * camDist;

      camPos.x = THREE.MathUtils.damp(camPos.x, desiredCamX, 7.0, dt);
      camPos.y = THREE.MathUtils.damp(camPos.y, desiredCamY, 7.0, dt);
      camPos.z = THREE.MathUtils.damp(camPos.z, desiredCamZ, 7.0, dt);

      const lookAheadX = playerShip.x - Math.sin(totalYaw) * 16.0;
      const lookAheadZ = playerShip.z - Math.cos(totalYaw) * 16.0;
      camLook.x = THREE.MathUtils.damp(camLook.x, lookAheadX, 9.0, dt);
      camLook.y = THREE.MathUtils.damp(camLook.y, playerShip.y + 4.2, 9.0, dt);
      camLook.z = THREE.MathUtils.damp(camLook.z, lookAheadZ, 9.0, dt);

      if (cameraShake > 0) {
        cameraShake = Math.max(0, cameraShake - dt * 1.8);
        camera.position.set(
          camPos.x + (Math.random() - 0.5) * cameraShake * 1.6,
          camPos.y + (Math.random() - 0.5) * cameraShake * 1.3,
          camPos.z + (Math.random() - 0.5) * cameraShake * 1.6,
        );
      } else {
        camera.position.copy(camPos);
      }
      camera.lookAt(camLook);

      // Keep ocean & shadow frustum centered near player
      sunLight.position.set(playerShip.x + 70, 58, playerShip.z - 90);
      sunLight.target.position.set(playerShip.x, 0, playerShip.z);
      skyDome.position.set(playerShip.x, 0, playerShip.z);

      // Raycast mouse into 3D space for Aiming Reticle & Ballistic Arc
      _ndc.copy(mouseNdc);
      _raycaster.setFromCamera(_ndc, camera);

      targetLockedOnEnemy = false;
      if (enemyShip.hp > 0) {
        const enemyHits = _raycaster.intersectObject(enemyShip.hullMesh, false);
        if (enemyHits.length > 0) {
          aimWorldPos.copy(enemyHits[0].point);
          targetLockedOnEnemy = true;
        }
      }
      if (!targetLockedOnEnemy) {
        if (_raycaster.ray.intersectPlane(_oceanPlane, _v1)) {
          // Clamp aim range to sensible cannon range (12..145m)
          const dx = _v1.x - playerShip.x;
          const dz = _v1.z - playerShip.z;
          const d = Math.hypot(dx, dz);
          if (d > 145) {
            _v1.x = playerShip.x + (dx / d) * 145;
            _v1.z = playerShip.z + (dz / d) * 145;
          } else if (d < 10) {
            _v1.x = playerShip.x - Math.sin(totalYaw) * 34;
            _v1.z = playerShip.z - Math.cos(totalYaw) * 34;
          }
          _v1.y = getWaveHeight(_v1.x, _v1.z, elapsed) + 0.25;
          aimWorldPos.copy(_v1);
        }
      }

      reticleGroup.position.copy(aimWorldPos);
      reticleGroup.position.y += 0.28;
      reticleOuter.rotation.z = elapsed * 1.4;
      reticleOuterMat.color.setHex(targetLockedOnEnemy ? 0xef4444 : 0xfbbf24);
      reticleGroup.visible = outcome === 'playing';

      // Update Ballistic Preview Arc from the exact active single cannon
      const activeSide = getActiveBroadsideSide(playerShip, aimWorldPos);
      const sideCannons = playerShip.cannons.filter((c) => c.side === activeSide);
      let repCannon: CannonMount | undefined = sideCannons[0];
      let minArcDistSq = Infinity;
      playerShip.group.updateMatrixWorld(true);
      for (let i = 0; i < sideCannons.length; i++) {
        _v2.copy(sideCannons[i].muzzleLocal);
        sideCannons[i].barrelGroup.localToWorld(_v2);
        const dSq = _v2.distanceToSquared(aimWorldPos);
        if (dSq < minArcDistSq) {
          minArcDistSq = dSq;
          repCannon = sideCannons[i];
        }
      }
      if (repCannon && outcome === 'playing') {
        _v1.copy(repCannon.muzzleLocal);
        repCannon.barrelGroup.localToWorld(_v1);
        const dx = aimWorldPos.x - _v1.x;
        const dy = aimWorldPos.y - _v1.y;
        const dz = aimWorldPos.z - _v1.z;
        const dist = Math.hypot(dx, dz);
        const T = THREE.MathUtils.clamp(dist / 52, 0.24, 2.35);
        const vx0 = dx / T;
        const vz0 = dz / T;
        const vy0 = (dy + 0.5 * GRAVITY * T * T) / T;

        for (let i = 0; i < ARC_POINTS; i++) {
          const frac = i / (ARC_POINTS - 1);
          const tt = frac * T;
          arcPositions[i * 3] = _v1.x + vx0 * tt;
          arcPositions[i * 3 + 1] = _v1.y + vy0 * tt - 0.5 * GRAVITY * tt * tt;
          arcPositions[i * 3 + 2] = _v1.z + vz0 * tt;
        }
        arcGeo.attributes.position.needsUpdate = true;
        arcLine.computeLineDistances();
        arcMat.color.setHex(targetLockedOnEnemy ? 0xf87171 : 0xfde68a);
        arcLine.visible = true;
      } else {
        arcLine.visible = false;
      }

      // Process staggered broadside shots
      for (let i = pendingShots.length - 1; i >= 0; i--) {
        const s = pendingShots[i];
        s.delay -= dt;
        if (s.delay <= 0) {
          launchBall(s.owner, s.cannon, s.ship, s.target, s.spread);
          pendingShots.splice(i, 1);
        }
      }

      // Process queued combatBurst follow-up broadside shots
      for (let i = combatBurstDelays.length - 1; i >= 0; i--) {
        combatBurstDelays[i] -= dt;
        if (combatBurstDelays[i] <= 0) {
          combatBurstDelays.splice(i, 1);
          if (outcome === 'playing' && playerShip.hp > 0) {
            playerShip.reloadTimer = 0;
            getAgentAimTarget(agentAimTarget);
            fireShipVolley(playerShip, agentAimTarget, 0.28);
          }
        }
      }

      // Update Muzzle Flash PointLights
      for (let i = 0; i < muzzleLights.length; i++) {
        const ml = muzzleLights[i];
        if (ml.life > 0) {
          ml.life = Math.max(0, ml.life - dt);
          ml.light.intensity = (ml.life / 0.11) * 18;
        } else {
          ml.light.intensity = 0;
        }
      }

      // Update Cannonballs & Collisions
      let activeBallCount = 0;
      for (let i = 0; i < MAX_BALLS; i++) {
        const b = cannonballs[i];
        if (!b.active) continue;

        b.age += dt;
        b.pos.addScaledVector(b.vel, dt);
        b.vel.y -= GRAVITY * dt;

        // Check ship hull hit
        const targetShip = b.owner === 'player' ? enemyShip : playerShip;
        if (checkCannonballShipHit(b, targetShip)) {
          b.active = false;
          spawnHullHitBurst(b.pos.x, b.pos.y, b.pos.z);

          const dmg = b.owner === 'player' ? 20 : 6;
          targetShip.hp = Math.max(0, targetShip.hp - dmg);
          targetShip.hitFlashTimer = 0.24;
          targetShip.roll += (Math.random() > 0.5 ? 1 : -1) * 0.14;
          audio.playHit(targetShip.id === 'player');

          if (b.owner === 'player') {
            hitsLanded += 1;
            lastHitNotice = `Direct Hit (-${dmg} HP)`;
            lastHitTimer = 1.6;
            cameraShake = Math.max(cameraShake, 0.3);
          } else {
            lastHitNotice = `Hull Struck (-${dmg} HP)`;
            lastHitTimer = 1.6;
            cameraShake = Math.max(cameraShake, 0.45);
          }

          if (targetShip.hp <= 0 && outcome === 'playing') {
            outcome = targetShip.id === 'enemy' ? 'victory' : 'defeat';
            audio.playOutcome(outcome === 'victory');
          }
          continue;
        }

        // Check ocean wave impact
        const waveY = getWaveHeight(b.pos.x, b.pos.z, elapsed);
        if (b.pos.y <= waveY) {
          b.active = false;
          spawnSplashBurst(b.pos.x, waveY, b.pos.z);
          audio.playSplash();
          continue;
        }

        if (b.age > 5.0) {
          b.active = false;
          continue;
        }

        _m1.makeTranslation(b.pos.x, b.pos.y, b.pos.z);
        ballInstanced.setMatrixAt(activeBallCount++, _m1);
      }
      ballInstanced.count = activeBallCount;
      ballInstanced.instanceMatrix.needsUpdate = true;

      // Update 3D Instanced Particles
      let activeParticleCount = 0;
      for (let i = 0; i < MAX_PARTICLES; i++) {
        const p = particles[i];
        if (!p.active) continue;

        p.age += dt;
        if (p.age >= p.maxAge) {
          p.active = false;
          continue;
        }

        const tNorm = p.age / p.maxAge;
        p.pos.addScaledVector(p.vel, dt);

        if (p.kind === 'splash' || p.kind === 'splinter') {
          p.vel.y -= GRAVITY * 0.85 * dt;
        } else if (p.kind === 'smoke') {
          p.vel.multiplyScalar(1 - dt * 1.4);
          p.vel.y += 0.6 * dt;
        }

        p.rot.x += p.rotVel.x * dt;
        p.rot.y += p.rotVel.y * dt;
        p.rot.z += p.rotVel.z * dt;

        const scale = THREE.MathUtils.lerp(p.startScale, p.endScale, tNorm);
        const fade = 1 - tNorm * tNorm;
        _e1.copy(p.rot);
        _q1.setFromEuler(_e1);

        if (p.kind === 'ring' || p.kind === 'wake') {
          _v1.set(scale, 0.14 * fade, scale);
        } else if (p.kind === 'splinter') {
          _v1.set(scale * 1.8, scale * 0.22, scale * 0.45);
        } else {
          const s = scale * (p.kind === 'smoke' ? 0.5 + 0.5 * fade : fade);
          _v1.set(s, s, s);
        }

        _m1.compose(p.pos, _q1, _v1);
        particleInstanced.setMatrixAt(activeParticleCount, _m1);
        particleInstanced.setColorAt(activeParticleCount, p.color);
        activeParticleCount++;
      }
      particleInstanced.count = activeParticleCount;
      particleInstanced.instanceMatrix.needsUpdate = true;
      if (particleInstanced.instanceColor) particleInstanced.instanceColor.needsUpdate = true;

      // Emit throttled HUD state snapshot (~15 Hz) so React HUD stays crisp without hurting 60 FPS
      hudEmitTimer += dt;
      if (hudEmitTimer >= 0.065) {
        hudEmitTimer = 0;
        const headingDeg = ((Math.round((-playerShip.yaw * 180) / Math.PI) % 360) + 360) % 360;
        onHudUpdateRef.current({
          playerHp: playerShip.hp,
          playerMaxHp: playerShip.maxHp,
          enemyHp: enemyShip.hp,
          enemyMaxHp: enemyShip.maxHp,
          reloadProgress: 1 - playerShip.reloadTimer / playerShip.reloadDuration,
          activeSide,
          speedKnots: Math.round(Math.abs(playerShip.speed) * 1.15),
          headingDeg,
          shotsFired,
          hitsLanded,
          elapsedSec,
          outcome,
          targetLocked: targetLockedOnEnemy,
          lastHitNotice,
          tacticalNotice,
        });
      }

      renderer.render(scene, camera);
      if (isSoftwareGl) afterDraw(tick);
      else frameId = requestAnimationFrame(tick);
    }

    tick();

    // ------------------------------------------------------------------------
    // 13. Resize & Clean Disposal
    // ------------------------------------------------------------------------
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('webglcontextlost', handleContextLost);
      delete window.pirateGame;
      delete window.pirateAgent;
      audio.dispose();
      disposables.forEach((d) => d.dispose());
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} className="w-full h-full cursor-crosshair" />;
};
