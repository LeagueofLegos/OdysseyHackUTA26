import { FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import {
  CheckCircle2,
  Eye,
  Loader2,
  Maximize2,
  Minimize2,
  Phone,
  RefreshCw,
  RotateCcw,
  Send,
  Sparkles,
  Terminal,
  VolumeX,
  XCircle,
} from 'lucide-react';

type ViewTab = 'display' | 'history' | 'status';

interface ScreenVisual {
  id: string;
  title: string;
  content: string;
  items: string[];
  kind: string;
  caption: string;
  svg?: string;
  source: 'studio' | 'facetime';
  createdAt: string;
}

interface DoctorCheck {
  name: string;
  status: 'pass' | 'fail' | 'warn' | 'skip';
  detail: string;
  fix?: string;
}

interface ChertStatusResponse {
  whoami?: {
    signed_in?: boolean;
    email?: string;
    project_id?: string;
    project_name?: string;
    role?: string;
  };
  onboarding?: {
    status?: string;
    receiving_number?: string;
    line_id?: string;
    message?: string;
  };
  bridge?: {
    agentStatus: 'stopped' | 'starting' | 'running' | 'error';
    chertStatus: 'stopped' | 'connecting' | 'ready' | 'in_call' | 'error';
    lastMessage: string;
    lastError: string | null;
    logs: string[];
  };
  login?: {
    status: 'idle' | 'pending' | 'signed_in' | 'error';
    userCode?: string;
    verificationUrl?: string;
    verificationUrlComplete?: string;
    message?: string;
    error?: string;
  };
  env?: {
    hasGeminiKey: boolean;
    hasLiveKitUrl: boolean;
    hasLiveKitKey: boolean;
    hasLiveKitSecret: boolean;
    agentName: string;
  };
}

const SAMPLE_DISPLAYS = [
  {
    label: 'Meeting Notes',
    payload: {
      title: 'Product Launch Checklist',
      content: 'Key focus areas before opening access to beta users this week.',
      items: [
        'Voice Pipeline: Verify Chert FaceTime line routes cleanly to LiveKit room',
        'Display Panel: Test live show_on_screen updates across notes and steps',
        'Audio Policy: Browser stays muted so only the agent speaks on call',
        'Monitoring: Keep doctor diagnostics ready for quick line checks',
      ],
    },
  },
  {
    label: 'Step-by-Step Guide',
    payload: {
      title: 'How to Pour-Over Coffee',
      content: 'Clean, balanced 3-minute extraction using a 1:16 coffee-to-water ratio.',
      items: [
        'Step 1: Rinse paper filter with hot water and add 20g medium-fine grounds',
        'Step 2: Pour 40g water at 93°C to bloom for 35 seconds',
        'Step 3: Slowly spiral-pour remaining 280g water in two steady pulses',
        'Step 4: Swirl gently once drawdown begins and serve at 2:45–3:00',
      ],
    },
  },
  {
    label: 'Comparison',
    payload: {
      title: 'FaceTime Video vs FaceTime Audio',
      content: 'How each call mode interacts with your live AI display setup.',
      items: [
        'FaceTime Video: Shows the AI camera screen directly on your iPhone + updates this full-screen panel',
        'FaceTime Audio: Voice-only on your phone while this muted web panel displays full-screen notes & visuals',
        'Browser Audio: Always muted so there is zero microphone echo or duplicate speaker playback',
      ],
    },
  },
];

function formatClock(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  } catch {
    return '';
  }
}

function splitItemLabel(item: string): { label: string | null; body: string } {
  const colonIdx = item.indexOf(':');
  if (colonIdx > 1 && colonIdx < 32) {
    return {
      label: item.slice(0, colonIdx).trim(),
      body: item.slice(colonIdx + 1).trim(),
    };
  }
  return { label: null, body: item };
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ViewTab>('display');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [chertStatus, setChertStatus] = useState<ChertStatusResponse | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [doctorChecks, setDoctorChecks] = useState<DoctorCheck[] | null>(null);
  const [doctorOk, setDoctorOk] = useState<boolean | null>(null);
  const [runningDoctor, setRunningDoctor] = useState(false);
  const [doctorError, setDoctorError] = useState<string | null>(null);
  const [startingLogin, setStartingLogin] = useState(false);

  const [activeVisual, setActiveVisual] = useState<ScreenVisual | null>(null);
  const [history, setHistory] = useState<ScreenVisual[]>([]);
  const [promptInput, setPromptInput] = useState('');
  const [isRendering, setIsRendering] = useState(false);
  const [renderError, setRenderError] = useState<string | null>(null);

  const displayPanelRef = useRef<HTMLDivElement | null>(null);

  const fetchStatus = useCallback(async () => {
    setLoadingStatus(true);
    try {
      const res = await fetch('/api/chert/status');
      if (res.ok) {
        const data = (await res.json()) as ChertStatusResponse;
        setChertStatus(data);
      }
    } catch {
      /* ignore transient fetch failure */
    } finally {
      setLoadingStatus(false);
    }
  }, []);

  const runDoctor = useCallback(async (checkAgent = false) => {
    setRunningDoctor(true);
    setDoctorError(null);
    try {
      const res = await fetch('/api/chert/doctor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ checkAgent }),
      });
      const data = await res.json();
      if (Array.isArray(data.checks)) {
        setDoctorChecks(data.checks);
        setDoctorOk(Boolean(data.ok));
      } else {
        setDoctorError(data.message || 'Doctor check returned an unexpected response.');
      }
    } catch (err) {
      setDoctorError(err instanceof Error ? err.message : 'Failed to run Chert doctor.');
    } finally {
      setRunningDoctor(false);
    }
  }, []);

  const startChertLogin = async () => {
    setStartingLogin(true);
    try {
      const res = await fetch('/api/chert/login', { method: 'POST' });
      if (res.ok) {
        await fetchStatus();
      }
    } finally {
      setStartingLogin(false);
    }
  };

  const restartBridge = async () => {
    setRunningDoctor(true);
    try {
      await fetch('/api/chert/bridge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'restart' }),
      });
      await fetchStatus();
    } finally {
      setRunningDoctor(false);
    }
  };

  const loginPending = chertStatus?.login?.status === 'pending';

  useEffect(() => {
    void fetchStatus();
    const timer = setInterval(() => {
      void fetchStatus();
    }, loginPending ? 2000 : 5000);
    return () => clearInterval(timer);
  }, [fetchStatus, loginPending]);

  // Passive display stream listener — browser stays muted, only receives show_on_screen updates
  useEffect(() => {
    const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const screenWs = new WebSocket(`${protocol}//${location.host}/api/screen/stream`);
    screenWs.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'init') {
          setActiveVisual(msg.activeVisual ?? null);
          setHistory(Array.isArray(msg.history) ? msg.history : []);
        } else if (msg.type === 'visual') {
          setActiveVisual(msg.visual ?? null);
          if (Array.isArray(msg.history)) setHistory(msg.history);
          setIsRendering(false);
        } else if (msg.type === 'clear') {
          setActiveVisual(null);
          if (Array.isArray(msg.history)) setHistory(msg.history);
        }
      } catch {
        /* ignore malformed ws frame */
      }
    };
    return () => {
      screenWs.close();
    };
  }, []);

  useEffect(() => {
    const onFsChange = () => {
      if (!document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isFullscreen && !document.fullscreenElement) {
        setIsFullscreen(false);
      }
    };
    document.addEventListener('fullscreenchange', onFsChange);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('fullscreenchange', onFsChange);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [isFullscreen]);

  const toggleFullscreen = async () => {
    if (!isFullscreen) {
      setIsFullscreen(true);
      try {
        if (displayPanelRef.current && document.fullscreenEnabled && !document.fullscreenElement) {
          await displayPanelRef.current.requestFullscreen();
        }
      } catch {
        /* CSS full-viewport fallback stays active inside iframe */
      }
    } else {
      setIsFullscreen(false);
      try {
        if (document.fullscreenElement) {
          await document.exitFullscreen();
        }
      } catch {
        /* ignore */
      }
    }
  };

  const triggerSampleDisplay = async (payload: { title: string; content: string; items: string[] }) => {
    setRenderError(null);
    const res = await fetch('/api/screen/show', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (res.ok && data.visual) {
      setActiveVisual(data.visual);
      if (Array.isArray(data.history)) setHistory(data.history);
    }
  };

  const renderVisualPreview = async (promptText: string) => {
    const trimmed = promptText.trim();
    if (!trimmed) return;
    setIsRendering(true);
    setRenderError(null);
    try {
      const res = await fetch('/api/screen/render', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: trimmed, kind: 'illustration', title: trimmed.slice(0, 48) }),
      });
      const data = await res.json();
      if (!res.ok) {
        setRenderError(data.error || 'Failed to render visual.');
      } else {
        setActiveVisual(data.visual);
        if (Array.isArray(data.history)) setHistory(data.history);
      }
    } catch (err) {
      setRenderError(err instanceof Error ? err.message : 'Network error rendering visual.');
    } finally {
      setIsRendering(false);
    }
  };

  const handlePromptSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim()) return;
    const text = promptInput.trim();
    setPromptInput('');
    void renderVisualPreview(text);
  };

  const clearScreen = async () => {
    await fetch('/api/screen/clear', { method: 'POST' });
    setActiveVisual(null);
  };

  const liveKitReady = Boolean(
    chertStatus?.env?.hasLiveKitUrl && chertStatus?.env?.hasLiveKitKey && chertStatus?.env?.hasLiveKitSecret,
  );
  const receivingNumber = chertStatus?.onboarding?.receiving_number || '+19132821013';
  const agentName = chertStatus?.env?.agentName || 'chert-visual-agent';
  const needsChertLogin =
    chertStatus?.whoami?.signed_in === false ||
    /sign in|login_required|chert login/i.test(chertStatus?.bridge?.lastError || '');
  const bridgeReady =
    chertStatus?.bridge?.agentStatus === 'running' &&
    (chertStatus?.bridge?.chertStatus === 'ready' || chertStatus?.bridge?.chertStatus === 'in_call');
  const inCall = chertStatus?.bridge?.chertStatus === 'in_call';

  return (
    <div className="min-h-screen bg-[#070B13] text-slate-100 flex flex-col">
      {/* Minimal Top Bar */}
      <header className="border-b border-slate-800/80 bg-[#090D16]/95 sticky top-0 z-30">
        <div className="max-w-[1600px] mx-auto px-6 h-14 flex items-center justify-between gap-6">
          <div className="flex items-center gap-4 min-w-0">
            <a
              href="#display"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('display');
              }}
              className="font-display text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
            >
              Chert Display Panel
            </a>
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-slate-400 whitespace-nowrap">
              <span
                className={`w-2 h-2 rounded-full ${
                  inCall ? 'bg-emerald-400' : bridgeReady ? 'bg-emerald-500/80' : 'bg-amber-400'
                }`}
              />
              {inCall
                ? `On FaceTime (${receivingNumber})`
                : bridgeReady
                  ? `FaceTime Ready · ${receivingNumber}`
                  : `Bridge ${chertStatus?.bridge?.chertStatus || 'connecting'}`}
            </span>
          </div>

          <nav className="flex items-center gap-6 text-sm font-medium">
            <button
              type="button"
              onClick={() => setActiveTab('display')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 cursor-pointer ${
                activeTab === 'display'
                  ? 'text-white border-emerald-500'
                  : 'text-slate-400 border-transparent hover:text-slate-200'
              }`}
            >
              Display Panel
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 cursor-pointer ${
                activeTab === 'history'
                  ? 'text-white border-emerald-500'
                  : 'text-slate-400 border-transparent hover:text-slate-200'
              }`}
            >
              History
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('status')}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 cursor-pointer ${
                activeTab === 'status'
                  ? 'text-white border-emerald-500'
                  : 'text-slate-400 border-transparent hover:text-slate-200'
              }`}
            >
              FaceTime Status
            </button>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <div
              className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-slate-800 bg-[#0E1525] text-xs text-slate-300 whitespace-nowrap"
              title="Browser microphone and speakers stay muted so only the LiveKit FaceTime agent publishes audio"
            >
              <VolumeX className="w-3.5 h-3.5 text-emerald-400" />
              Browser Muted
            </div>
            {activeTab === 'display' && (
              <button
                type="button"
                onClick={() => void toggleFullscreen()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                {isFullscreen ? 'Exit Full Screen' : 'Full Screen'}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 flex flex-col">
        {activeTab === 'display' && (
          <div
            ref={displayPanelRef}
            className={
              isFullscreen
                ? 'fixed inset-0 z-50 bg-[#070B13] flex flex-col justify-between p-6 sm:p-10 overflow-y-auto'
                : 'flex-1 max-w-[1600px] w-full mx-auto px-6 py-6 flex flex-col gap-5'
            }
          >
            {!isFullscreen && (chertStatus?.bridge?.chertStatus === 'error' || chertStatus?.bridge?.lastError || needsChertLogin) && (
              <div className="rounded-xl border border-amber-500/40 bg-amber-950/30 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-100">
                <div className="space-y-1">
                  <div>
                    {needsChertLogin
                      ? 'Chert sign-in required. Approve this server in Chert to reconnect your FaceTime line.'
                      : chertStatus?.bridge?.lastError ||
                        'FaceTime bridge is disconnected or held by another agent. Click Reconnect Line to route calls here.'}
                  </div>
                  {chertStatus?.login?.status === 'pending' && chertStatus.login.userCode && (
                    <div className="flex flex-wrap items-center gap-2 text-amber-200">
                      <span>Code:</span>
                      <code className="px-2 py-0.5 rounded bg-amber-900/60 font-mono font-bold text-white">
                        {chertStatus.login.userCode}
                      </code>
                      <span>Waiting for browser approval...</span>
                    </div>
                  )}
                  {chertStatus?.login?.error && <div className="text-rose-300">{chertStatus.login.error}</div>}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {needsChertLogin ? (
                    <>
                      {chertStatus?.login?.status === 'pending' &&
                      (chertStatus.login.verificationUrlComplete || chertStatus.login.verificationUrl) ? (
                        <a
                          href={chertStatus.login.verificationUrlComplete || chertStatus.login.verificationUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-semibold transition-colors whitespace-nowrap shrink-0"
                        >
                          Open Chert Approval
                        </a>
                      ) : null}
                      <button
                        type="button"
                        onClick={() => void startChertLogin()}
                        disabled={startingLogin}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        {startingLogin ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}
                        {chertStatus?.login?.status === 'pending' ? 'New Code' : 'Sign in to Chert'}
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void restartBridge()}
                      disabled={runningDoctor}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Reconnect Line
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Full-Screen Display Surface */}
            <section className="flex-1 min-h-[calc(100vh-12rem)] rounded-2xl border border-slate-800/90 bg-[#0B1120] p-6 sm:p-10 flex flex-col justify-between relative overflow-hidden">
              {/* Top Display Bar */}
              <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-slate-800/80">
                <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                  <span className="inline-flex items-center gap-1.5 text-emerald-400">
                    <Phone className="w-3.5 h-3.5" />
                    {receivingNumber}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{activeVisual ? `show_on_screen (${activeVisual.source})` : 'Waiting for AI screen update'}</span>
                  {activeVisual && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>{formatClock(activeVisual.createdAt)}</span>
                    </>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {activeVisual && (
                    <button
                      type="button"
                      onClick={() => void clearScreen()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900/90 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Clear
                    </button>
                  )}
                  {isFullscreen && (
                    <button
                      type="button"
                      onClick={() => void toggleFullscreen()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-900/90 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
                    >
                      <Minimize2 className="w-3.5 h-3.5" />
                      Exit Full Screen
                    </button>
                  )}
                </div>
              </div>

              {/* Center Stage: Structured Display + Optional Visual */}
              {activeVisual ? (
                <div className="flex-1 py-8 flex flex-col justify-center">
                  <div
                    className={
                      activeVisual.svg && (activeVisual.content || activeVisual.items.length > 0)
                        ? 'grid grid-cols-1 xl:grid-cols-12 gap-8 items-center'
                        : 'max-w-5xl w-full mx-auto flex flex-col gap-7'
                    }
                  >
                    {/* Structured Title, Content & Items */}
                    {(activeVisual.content || activeVisual.items.length > 0 || !activeVisual.svg) && (
                      <div
                        className={
                          activeVisual.svg && (activeVisual.content || activeVisual.items.length > 0)
                            ? 'xl:col-span-6 flex flex-col gap-6'
                            : 'flex flex-col gap-6'
                        }
                      >
                        <div>
                          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-tight">
                            {activeVisual.title}
                          </h1>
                          {activeVisual.content && (
                            <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
                              {activeVisual.content}
                            </p>
                          )}
                        </div>

                        {activeVisual.items && activeVisual.items.length > 0 && (
                          <div
                            className={`grid gap-3.5 ${
                              activeVisual.items.length >= 4 && !activeVisual.svg
                                ? 'grid-cols-1 md:grid-cols-2'
                                : 'grid-cols-1'
                            }`}
                          >
                            {activeVisual.items.map((item, idx) => {
                              const { label, body } = splitItemLabel(item);
                              return (
                                <div
                                  key={`${activeVisual.id}-${idx}`}
                                  className="rounded-xl border border-slate-800 bg-[#111827]/90 px-5 py-4 flex items-start gap-4"
                                >
                                  <span className="font-mono text-xs font-semibold text-emerald-400 mt-1 shrink-0 w-6">
                                    {String(idx + 1).padStart(2, '0')}
                                  </span>
                                  <div className="min-w-0 text-base text-slate-100 leading-relaxed">
                                    {label ? (
                                      <>
                                        <span className="font-semibold text-white">{label}: </span>
                                        <span className="text-slate-300">{body}</span>
                                      </>
                                    ) : (
                                      <span>{body}</span>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Optional SVG Visual Canvas */}
                    {activeVisual.svg && (
                      <div
                        className={
                          activeVisual.content || activeVisual.items.length > 0
                            ? 'xl:col-span-6 flex flex-col gap-3'
                            : 'w-full max-w-5xl mx-auto flex flex-col gap-3'
                        }
                      >
                        {!(activeVisual.content || activeVisual.items.length > 0) && (
                          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white">
                            {activeVisual.title}
                          </h1>
                        )}
                        <div
                          className="aspect-video w-full rounded-xl border border-slate-800 bg-[#090D16] overflow-hidden [&>svg]:w-full [&>svg]:h-full [&>svg]:block"
                          dangerouslySetInnerHTML={{ __html: activeVisual.svg }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex-1 py-12 flex flex-col items-center justify-center text-center max-w-2xl mx-auto">
                  <div className="w-16 h-16 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 flex items-center justify-center mb-6">
                    <VolumeX className="w-7 h-7 text-emerald-400" />
                  </div>
                  <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white">
                    Live AI Display Panel
                  </h1>
                  <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed">
                    Call <span className="font-mono text-white">{receivingNumber}</span> on FaceTime and ask your agent to
                    show notes, steps, comparisons, or visuals. This browser stays muted so only your agent speaks.
                  </p>
                  <div className="mt-6 text-xs font-mono text-slate-400">
                    {bridgeReady
                      ? 'Chert FaceTime bridge is live and listening for show_on_screen updates.'
                      : chertStatus?.bridge?.lastError || chertStatus?.bridge?.lastMessage || 'Connecting bridge...'}
                  </div>
                </div>
              )}

              {/* Subtle Footer Indicator */}
              <div className="pt-4 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
                <span>Browser audio muted · LiveKit agent owns call audio</span>
                <span>Tool: show_on_screen(title, content, items)</span>
              </div>

              {isRendering && (
                <div className="absolute inset-0 bg-[#070B13]/80 flex flex-col items-center justify-center gap-3 z-10">
                  <Loader2 className="w-7 h-7 text-emerald-400 animate-spin" />
                  <p className="text-sm font-medium text-slate-200">Rendering visual...</p>
                </div>
              )}
            </section>

            {/* Compact Control Dock (hidden in full-screen presentation mode) */}
            {!isFullscreen && (
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pt-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500 mr-1">Preview display:</span>
                  {SAMPLE_DISPLAYS.map((sample) => (
                    <button
                      key={sample.label}
                      type="button"
                      onClick={() => void triggerSampleDisplay(sample.payload)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-800 bg-[#111827] hover:border-slate-600 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      {sample.label}
                    </button>
                  ))}
                </div>

                <form onSubmit={handlePromptSubmit} className="flex gap-2 w-full lg:w-[440px]">
                  <input
                    type="text"
                    value={promptInput}
                    onChange={(e) => setPromptInput(e.target.value)}
                    placeholder="Preview a visual diagram or illustration..."
                    className="flex-1 px-3.5 py-2 rounded-lg border border-slate-800 bg-[#111827] text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    disabled={isRendering || !promptInput.trim()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-white disabled:opacity-50 text-slate-950 font-semibold text-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    Preview
                  </button>
                </form>
              </div>
            )}

            {renderError && (
              <div className="px-4 py-2.5 rounded-lg border border-rose-500/40 bg-rose-950/30 text-xs text-rose-200">
                {renderError}
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="max-w-[1440px] w-full mx-auto px-6 py-8 space-y-6">
            <div>
              <h1 className="font-display text-2xl font-bold tracking-tight text-white">Display History</h1>
              <p className="mt-1 text-sm text-slate-400">
                Notes, steps, comparisons, and visuals shown by your agent appear here.
              </p>
            </div>

            {history.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-[#111827] p-12 text-center">
                <Eye className="w-8 h-8 text-slate-600 mx-auto mb-3" />
                <h2 className="font-display text-base font-semibold text-white">Nothing displayed yet</h2>
                <p className="mt-1 text-sm text-slate-400">
                  Call {receivingNumber} on FaceTime or trigger a sample preview in Display Panel.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {history.map((item) => (
                  <article
                    key={item.id}
                    className="rounded-xl border border-slate-800 bg-[#111827] overflow-hidden flex flex-col justify-between p-5 gap-4"
                  >
                    {item.svg ? (
                      <div
                        className="aspect-video w-full rounded-lg bg-[#090D16] overflow-hidden [&>svg]:w-full [&>svg]:h-full [&>svg]:block"
                        dangerouslySetInnerHTML={{ __html: item.svg }}
                      />
                    ) : (
                      <div className="space-y-2">
                        <h3 className="font-display text-base font-semibold text-white">{item.title}</h3>
                        {item.content && <p className="text-xs text-slate-400 line-clamp-2">{item.content}</p>}
                        {item.items?.length > 0 && (
                          <ul className="space-y-1 pt-1">
                            {item.items.slice(0, 3).map((entry, idx) => (
                              <li key={idx} className="text-xs text-slate-300 truncate">
                                • {entry}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    )}

                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-white truncate">{item.title}</div>
                        <div className="text-xs text-slate-400 font-mono">
                          {item.source} · {formatClock(item.createdAt)}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setActiveVisual(item);
                          setActiveTab('display');
                        }}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-xs font-medium text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        Open
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'status' && (
          <div className="max-w-4xl w-full mx-auto px-6 py-8 space-y-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl font-bold tracking-tight text-white">
                  Chert FaceTime + LiveKit Agent ({receivingNumber})
                </h1>
                <p className="mt-1.5 text-sm text-slate-400 max-w-2xl leading-relaxed">
                  Only the LiveKit agent publishes audio. Your browser stays muted and listens passively for{' '}
                  <code className="font-mono text-slate-200">show_on_screen</code> updates.
                </p>
              </div>
              <div className="flex items-center gap-3">
                {needsChertLogin ? (
                  <button
                    type="button"
                    onClick={() => void startChertLogin()}
                    disabled={startingLogin}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 disabled:opacity-60 text-slate-950 font-semibold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    {startingLogin ? <Loader2 className="w-4 h-4 animate-spin" /> : <RotateCcw className="w-4 h-4" />}
                    Sign in to Chert
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => void restartBridge()}
                    disabled={runningDoctor}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 font-medium text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reconnect Bridge
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => void runDoctor(false)}
                  disabled={runningDoctor}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold text-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {runningDoctor ? <Loader2 className="w-4 h-4 animate-spin" /> : <Terminal className="w-4 h-4" />}
                  Run Chert Doctor
                </button>
              </div>
            </div>

            {needsChertLogin && (
              <div className="rounded-xl border border-amber-500/40 bg-amber-950/30 p-5 flex flex-wrap items-center justify-between gap-4">
                <div className="space-y-1.5 text-sm">
                  <div className="font-semibold text-amber-100">Chert Sign-In Needed</div>
                  <p className="text-amber-200/90 text-xs leading-relaxed">
                    The server does not currently hold a saved Chert session. Click Sign in to Chert, open the approval link, and choose your Chert project. Your session will be saved in workspace storage.
                  </p>
                  {chertStatus?.login?.status === 'pending' && chertStatus.login.userCode && (
                    <div className="pt-1 flex flex-wrap items-center gap-2 text-xs text-amber-100">
                      <span>Approval code:</span>
                      <code className="px-2.5 py-1 rounded bg-amber-900/70 font-mono font-bold text-white">
                        {chertStatus.login.userCode}
                      </code>
                      <a
                        href={chertStatus.login.verificationUrlComplete || chertStatus.login.verificationUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-3 py-1 rounded-md bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-semibold"
                      >
                        Open Chert Approval
                      </a>
                    </div>
                  )}
                  {chertStatus?.login?.error && <p className="text-xs text-rose-300">{chertStatus.login.error}</p>}
                </div>
              </div>
            )}

            <div className="rounded-xl border border-slate-800 bg-[#111827] divide-y divide-slate-800">
              <div className="p-5 flex items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-white">
                    1. LiveKit Voice + Screen Agent ({agentName})
                  </h2>
                  <p className="text-sm text-slate-400 mt-0.5">
                    Handles FaceTime voice audio and updates this display panel via show_on_screen(title, content, items).
                  </p>
                </div>
                <span
                  className={`font-mono text-xs uppercase ${
                    chertStatus?.bridge?.agentStatus === 'running' ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {chertStatus?.bridge?.agentStatus || 'starting'}
                </span>
              </div>

              <div className="p-5 flex items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-white">
                    2. Chert FaceTime Bridge ({receivingNumber})
                  </h2>
                  <p className="text-sm text-slate-400 mt-0.5">
                    {chertStatus?.bridge?.lastError ||
                      chertStatus?.bridge?.lastMessage ||
                      'Connects Apple FaceTime calls to your LiveKit room.'}
                  </p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => void fetchStatus()}
                    className="p-1.5 rounded-md hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
                    aria-label="Refresh status"
                  >
                    <RefreshCw className={`w-4 h-4 ${loadingStatus ? 'animate-spin' : ''}`} />
                  </button>
                  <span
                    className={`font-mono text-xs uppercase ${
                      chertStatus?.bridge?.chertStatus === 'ready' || chertStatus?.bridge?.chertStatus === 'in_call'
                        ? 'text-emerald-400'
                        : chertStatus?.bridge?.chertStatus === 'error'
                          ? 'text-rose-400'
                          : 'text-amber-400'
                    }`}
                  >
                    {chertStatus?.bridge?.chertStatus || 'connecting'}
                  </span>
                </div>
              </div>

              <div className="p-5 flex items-center justify-between gap-4 text-sm">
                <span className="text-slate-400">Account &amp; Secrets</span>
                <span className="font-mono text-xs text-slate-300">
                  Chert: {chertStatus?.whoami?.signed_in ? chertStatus.whoami.email || 'Signed in' : 'Sign-in needed'} · Gemini:{' '}
                  {chertStatus?.env?.hasGeminiKey ? 'OK' : 'Missing'} · LiveKit: {liveKitReady ? 'OK' : 'Missing'}
                </span>
              </div>

              {chertStatus?.bridge?.logs && chertStatus.bridge.logs.length > 0 && (
                <div className="p-5">
                  <h3 className="text-xs font-medium text-slate-400 mb-2">Recent Bridge Activity</h3>
                  <pre className="p-3 rounded-lg bg-[#090D16] border border-slate-800 text-xs text-slate-300 overflow-x-auto max-h-48">
                    {chertStatus.bridge.logs.slice(-10).join('\n')}
                  </pre>
                </div>
              )}
            </div>

            {/* Doctor Diagnostics */}
            <div className="rounded-xl border border-slate-800 bg-[#111827] overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-white">Live Chert Doctor Diagnostics</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {doctorChecks
                      ? doctorOk
                        ? 'All checks passed.'
                        : 'Review failing or warning checks below.'
                      : 'Run Chert Doctor to inspect sign-in, line availability, and LiveKit readiness.'}
                  </p>
                </div>
                {doctorChecks && (
                  <button
                    type="button"
                    onClick={() => void runDoctor(true)}
                    disabled={runningDoctor}
                    className="px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-800 text-xs font-medium text-slate-200 transition-colors cursor-pointer"
                  >
                    Test Agent Join
                  </button>
                )}
              </div>

              {doctorError && <div className="p-5 text-sm text-rose-300">{doctorError}</div>}

              {!doctorChecks ? (
                <div className="p-8 text-center text-sm text-slate-400">
                  Click <span className="text-slate-200 font-medium">Run Chert Doctor</span> above to fetch live checks.
                </div>
              ) : (
                <div className="divide-y divide-slate-800">
                  {doctorChecks.map((check) => (
                    <div key={check.name} className="px-5 py-3.5 flex items-start justify-between gap-4 text-sm">
                      <div className="flex items-start gap-3">
                        {check.status === 'pass' ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                        ) : (
                          <XCircle
                            className={`w-4 h-4 mt-0.5 shrink-0 ${
                              check.status === 'fail' ? 'text-rose-400' : 'text-amber-400'
                            }`}
                          />
                        )}
                        <div>
                          <div className="font-mono text-xs text-slate-300">{check.name}</div>
                          <div className="text-slate-200 mt-0.5">{check.detail}</div>
                          {check.fix && <div className="text-xs text-slate-400 mt-1">{check.fix}</div>}
                        </div>
                      </div>
                      <span
                        className={`font-mono text-xs uppercase shrink-0 ${
                          check.status === 'pass'
                            ? 'text-emerald-400'
                            : check.status === 'fail'
                              ? 'text-rose-400'
                              : 'text-amber-400'
                        }`}
                      >
                        {check.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
