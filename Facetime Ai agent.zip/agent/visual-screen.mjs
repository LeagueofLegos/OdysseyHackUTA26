import { ThinkingLevel } from '@google/genai';
import sharp from 'sharp';

export const WIDTH = 640;
export const HEIGHT = 360;
export const FPS = 10;

const BG = [9, 13, 22];
const SURFACE = [17, 24, 39];
const BORDER = [31, 41, 55];
const TEAL = [16, 185, 129];
const SKY = [56, 189, 248];
const MUTED = [100, 116, 139];

function escapeXml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

export function sanitizeSvg(rawSvg, title = 'AI Visual Screen', caption = '') {
  const match = String(rawSvg || '').match(/<svg[\s\S]*?<\/svg>/i);
  let svg = match ? match[0] : '';

  // Strip scripts, foreignObject, and external href/src attributes
  svg = svg
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<foreignObject[\s\S]*?<\/foreignObject>/gi, '')
    .replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, '')
    .replace(/(?:href|xlink:href)\s*=\s*(?:"https?:[^"]*"|'https?:[^']*')/gi, '');

  if (!svg) {
    svg = buildFallbackIllustrationSvg(title, caption || 'Visual canvas ready');
  }

  // Ensure root <svg> has fixed 640x360 dimensions and viewBox
  svg = svg.replace(/<svg\b([^>]*)>/i, (_full, attrs) => {
    let cleaned = attrs
      .replace(/\bwidth\s*=\s*(?:"[^"]*"|'[^']*')/gi, '')
      .replace(/\bheight\s*=\s*(?:"[^"]*"|'[^']*')/gi, '')
      .replace(/\bviewBox\s*=\s*(?:"[^"]*"|'[^']*')/gi, '');
    if (!/\bxmlns\s*=/.test(cleaned)) {
      cleaned += ' xmlns="http://www.w3.org/2000/svg"';
    }
    return `<svg${cleaned} width="${WIDTH}" height="${HEIGHT}" viewBox="0 0 ${WIDTH} ${HEIGHT}">`;
  });

  // Add subtle editorial caption overlay bar at bottom if caption/title provided
  const safeTitle = escapeXml(title).slice(0, 56);
  const safeCaption = escapeXml(caption).slice(0, 72);
  const footer = `
  <g id="chert-screen-hud">
    <rect x="0" y="324" width="640" height="36" fill="#090D16" fill-opacity="0.88"/>
    <line x1="0" y1="324" x2="640" y2="324" stroke="#1F2937" stroke-width="1"/>
    <circle cx="20" cy="342" r="4" fill="#10B981"/>
    <text x="32" y="346" font-family="DejaVu Sans, Arial, sans-serif" font-size="13" font-weight="600" fill="#F8FAFC">${safeTitle}</text>
    ${safeCaption ? `<text x="624" y="346" text-anchor="end" font-family="DejaVu Sans, Arial, sans-serif" font-size="11" fill="#94A3B8">${safeCaption}</text>` : ''}
  </g>`;

  svg = svg.replace(/<\/svg>\s*$/i, `${footer}\n</svg>`);
  return svg;
}

export function buildFallbackIllustrationSvg(title = 'Visual Screen', subtitle = '') {
  const safeTitle = escapeXml(title).slice(0, 46);
  const safeSub = escapeXml(subtitle).slice(0, 76);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
  <rect width="640" height="360" fill="#090D16"/>
  <g stroke="#1E293B" stroke-width="1">
    <line x1="80" y1="40" x2="80" y2="300"/>
    <line x1="200" y1="40" x2="200" y2="300"/>
    <line x1="320" y1="40" x2="320" y2="300"/>
    <line x1="440" y1="40" x2="440" y2="300"/>
    <line x1="560" y1="40" x2="560" y2="300"/>
    <line x1="40" y1="80" x2="600" y2="80"/>
    <line x1="40" y1="160" x2="600" y2="160"/>
    <line x1="40" y1="240" x2="600" y2="240"/>
  </g>
  <rect x="72" y="64" width="496" height="212" rx="12" fill="#111827" stroke="#334155" stroke-width="1.5"/>
  <circle cx="320" cy="146" r="36" fill="none" stroke="#10B981" stroke-width="3"/>
  <circle cx="320" cy="146" r="18" fill="#0EA5E9" fill-opacity="0.35" stroke="#38BDF8" stroke-width="2"/>
  <text x="320" y="216" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="20" font-weight="700" fill="#F8FAFC">${safeTitle}</text>
  <text x="320" y="242" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="13" fill="#94A3B8">${safeSub}</text>
</svg>`;
}

function wrapTextLines(text = '', maxChars = 66, maxLines = 2) {
  const words = String(text || '').trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let current = '';
  for (const word of words) {
    const next = current ? `${current} ${word}` : word;
    if (next.length > maxChars) {
      if (current) lines.push(current);
      current = word;
      if (lines.length >= maxLines) break;
    } else {
      current = next;
    }
  }
  if (current && lines.length < maxLines) lines.push(current);
  return lines.slice(0, maxLines);
}

export function buildStructuredDisplaySvg({ title = 'On Screen', content = '', items = [] }) {
  const safeTitle = escapeXml(String(title || 'On Screen')).slice(0, 44);
  const contentLines = wrapTextLines(content, 64, 2);
  const normalizedItems = (Array.isArray(items) ? items : [])
    .map((it) => (typeof it === 'string' ? it : JSON.stringify(it)))
    .filter(Boolean)
    .slice(0, 5);

  const contentSvg = contentLines
    .map(
      (line, idx) =>
        `<text x="36" y="${98 + idx * 20}" font-family="DejaVu Sans, Arial, sans-serif" font-size="13" fill="#CBD5E1">${escapeXml(line)}</text>`,
    )
    .join('\n  ');

  const listStartY = contentLines.length > 0 ? 148 : 104;
  const itemsSvg = normalizedItems
    .map((item, idx) => {
      const y = listStartY + idx * 36;
      const truncated = escapeXml(item.length > 62 ? `${item.slice(0, 59)}...` : item);
      return `<g>
    <rect x="36" y="${y}" width="568" height="28" rx="6" fill="#111827" stroke="#1F2937" stroke-width="1"/>
    <circle cx="52" cy="${y + 14}" r="3.5" fill="#10B981"/>
    <text x="66" y="${y + 18}" font-family="DejaVu Sans, Arial, sans-serif" font-size="12" fill="#F1F5F9">${truncated}</text>
  </g>`;
    })
    .join('\n  ');

  return `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
  <rect width="640" height="360" fill="#090D16"/>
  <rect x="20" y="20" width="600" height="320" rx="14" fill="#0B1120" stroke="#1E293B" stroke-width="1.5"/>
  <rect x="36" y="38" width="6" height="24" rx="3" fill="#10B981"/>
  <text x="52" y="57" font-family="DejaVu Sans, Arial, sans-serif" font-size="20" font-weight="700" fill="#F8FAFC">${safeTitle}</text>
  <line x1="36" y1="74" x2="604" y2="74" stroke="#1E293B" stroke-width="1"/>
  ${contentSvg}
  ${itemsSvg}
</svg>`;
}

export async function generateIllustrationSvg({ ai, title, kind = 'illustration', prompt, caption = '' }) {
  const systemInstruction = `Render a clean, crisp 640x360 SVG visual for a live video call.
Return ONLY a single <svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">...</svg>.
Rules:
- Dark background (#090D16 or #0B1120); keep y >= 324 clear for the title bar.
- High-contrast colors (#F8FAFC, #94A3B8, #10B981, #38BDF8, #F59E0B, #F43F5E) and sans-serif labels >= 12px.
- Be concise and fast: use 8 to 18 clean geometric/vector elements (shapes, arrows, paths, labels). Avoid verbose paths or extra comments.
- Never include <script>, <foreignObject>, or external URLs.`;

  const userPrompt = `Type: ${kind}
Title: ${title}
Draw: ${prompt}${caption ? `\nCaption: ${caption}` : ''}`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: userPrompt,
    config: {
      systemInstruction,
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
    },
  });

  const rawText = response.text || '';
  const svg = sanitizeSvg(rawText, title, caption);
  return { svg, title, kind, caption };
}

export async function svgToRgba(svg) {
  const { data } = await sharp(Buffer.from(svg, 'utf8'))
    .resize(WIDTH, HEIGHT, { fit: 'cover' })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });
  return Uint8Array.from(data);
}

let cachedStudioBase = null;

export async function initStudioBase() {
  if (cachedStudioBase) return cachedStudioBase;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
  <defs>
    <linearGradient id="studioBg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#090D16"/>
      <stop offset="100%" stop-color="#0F172A"/>
    </linearGradient>
  </defs>
  <rect width="640" height="360" fill="url(#studioBg)"/>
  <g stroke="#1E293B" stroke-width="1" opacity="0.6">
    <line x1="80" y1="0" x2="80" y2="360"/>
    <line x1="160" y1="0" x2="160" y2="360"/>
    <line x1="240" y1="0" x2="240" y2="360"/>
    <line x1="320" y1="0" x2="320" y2="360"/>
    <line x1="400" y1="0" x2="400" y2="360"/>
    <line x1="480" y1="0" x2="480" y2="360"/>
    <line x1="560" y1="0" x2="560" y2="360"/>
    <line x1="0" y1="60" x2="640" y2="60"/>
    <line x1="0" y1="120" x2="640" y2="120"/>
    <line x1="0" y1="180" x2="640" y2="180"/>
    <line x1="0" y1="240" x2="640" y2="240"/>
    <line x1="0" y1="300" x2="640" y2="300"/>
  </g>
  <rect x="64" y="42" width="512" height="276" rx="16" fill="#111827" fill-opacity="0.92" stroke="#334155" stroke-width="1.5"/>
  <circle cx="320" cy="134" r="46" fill="#090D16" stroke="#10B981" stroke-width="2.5"/>
  <circle cx="320" cy="134" r="26" fill="#10B981" fill-opacity="0.2" stroke="#38BDF8" stroke-width="1.5"/>
  <text x="320" y="218" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="20" font-weight="700" fill="#F8FAFC">AI VISUAL CAMERA SCREEN</text>
  <text x="320" y="244" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="13" fill="#94A3B8">Ask me to illustrate, diagram, or visualize anything</text>
  <text x="320" y="294" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="11" fill="#10B981">LIVE FACETIME VIDEO + VOICE CONNECTED</text>
</svg>`;
  cachedStudioBase = await svgToRgba(svg);
  return cachedStudioBase;
}

export function renderStudioFrame(tick, speaking) {
  const pixels = cachedStudioBase ? new Uint8Array(cachedStudioBase) : new Uint8Array(WIDTH * HEIGHT * 4);
  if (!cachedStudioBase) {
    for (let i = 0; i < pixels.length; i += 4) {
      pixels[i] = BG[0];
      pixels[i + 1] = BG[1];
      pixels[i + 2] = BG[2];
      pixels[i + 3] = 255;
    }
  }

  const cx = WIDTH / 2;

  // Reactive equalizer bars below the circle (y: 256..276)
  const barCount = 15;
  const barWidth = 8;
  const barGap = 6;
  const startX = cx - (barCount * barWidth + (barCount - 1) * barGap) / 2;
  for (let b = 0; b < barCount; b++) {
    const phase = tick * 0.35 + b * 0.55;
    const h = speaking
      ? Math.round(6 + 14 * Math.abs(Math.sin(phase)))
      : Math.round(3 + 3 * Math.abs(Math.sin(tick * 0.12 + b * 0.4)));
    const bx = Math.round(startX + b * (barWidth + barGap));
    const byTop = 274 - h;
    for (let y = byTop; y < 276; y++) {
      for (let x = bx; x < bx + barWidth; x++) {
        const idx = (y * WIDTH + x) * 4;
        const c = speaking ? TEAL : SKY;
        pixels[idx] = c[0];
        pixels[idx + 1] = c[1];
        pixels[idx + 2] = c[2];
        pixels[idx + 3] = 255;
      }
    }
  }

  // Subtle live activity bar along bottom edge
  const pulseX = (tick * 8) % (WIDTH - 48);
  for (let y = HEIGHT - 5; y < HEIGHT - 2; y++) {
    for (let x = pulseX; x < pulseX + 48; x++) {
      const idx = (y * WIDTH + x) * 4;
      pixels[idx] = TEAL[0];
      pixels[idx + 1] = TEAL[1];
      pixels[idx + 2] = TEAL[2];
      pixels[idx + 3] = 255;
    }
  }

  return pixels;
}

export function cloneWithSpeakingPulse(baseRgba, tick, speaking) {
  const frame = new Uint8Array(baseRgba);
  const pulseWidth = speaking ? 44 : 18;
  const pulseX = 12 + ((tick * 5) % 80);
  const c = speaking ? TEAL : SKY;
  for (let y = HEIGHT - 5; y < HEIGHT - 2; y++) {
    for (let x = pulseX; x < Math.min(WIDTH - 12, pulseX + pulseWidth); x++) {
      const idx = (y * WIDTH + x) * 4;
      frame[idx] = c[0];
      frame[idx + 1] = c[1];
      frame[idx + 2] = c[2];
      frame[idx + 3] = 255;
    }
  }
  return frame;
}
