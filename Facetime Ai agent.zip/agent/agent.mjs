import { fileURLToPath } from 'node:url';
import { GoogleGenAI, Modality, Type } from '@google/genai';
import { AutoSubscribe, defineAgent } from '@livekit/agents';
import { AccessToken } from 'livekit-server-sdk';
import {
  AudioFrame,
  AudioSource,
  AudioStream,
  LocalAudioTrack,
  LocalVideoTrack,
  Room,
  RoomEvent,
  TrackKind,
  TrackSource,
  VideoBufferType,
  VideoFrame,
  VideoSource,
  VideoStream,
} from '@livekit/rtc-node';
import sharp from 'sharp';
import { runAgent } from './chert-rooms.mjs';
import { greetOnBridgeReady } from './greet.mjs';
import {
  buildStructuredDisplaySvg,
  cloneWithSpeakingPulse,
  FPS,
  generateIllustrationSvg,
  HEIGHT,
  initStudioBase,
  renderStudioFrame,
  svgToRgba,
  WIDTH,
} from './visual-screen.mjs';

const PIRATE_ROOM_NAME = 'pirate-battle';
const PIRATE_COMMANDS = ['steer_left', 'steer_right', 'accelerate', 'slow_down', 'fire', 'restart'];

const ODYSSEY_ROOM_NAME = 'odyssey-game';
const ODYSSEY_TARGET_IDENTITY = 'odyssey-game';
const ODYSSEY_RPC_METHOD = 'odyssey_command';
const ODYSSEY_DATA_TOPIC = 'odyssey';
const ODYSSEY_COMMANDS = [
  'get_game_state',
  'move',
  'look',
  'aim_at_enemy',
  'shoot',
  'interact',
  'jump',
  'restart',
  'stop',
];

const SYSTEM_INSTRUCTIONS = `You are a helpful, expressive AI partner on a live FaceTime voice and video call paired with a full-screen live Display Panel.
You HAVE an active Display Panel in the web app AND a live FaceTime camera screen that update in real time.
NEVER say you cannot show visuals, notes, or a screen.
SPEED RULE: Whenever the caller asks to see notes, steps, comparisons, lists, summaries, or visuals, IMMEDIATELY call show_on_screen(title, content, items) first with crisp, concise arguments (short title, 1-sentence content, 3 to 5 brief items) so the screen updates instantaneously, then briefly explain it.
If the caller explicitly asks you to draw/sketch a custom illustration, diagram, chart, or picture, call show_visual_screen with a short 1-sentence prompt so it renders immediately.
If the caller asks to clear the screen, call clear_visual_screen.

PIRATE SEAS 3D BATTLE MODE:
You pilot the player's ship in the Pirate Seas 3D game using control_ship(command) (valid commands: "steer_left", "steer_right", "accelerate", "slow_down", "fire", "restart").
Whenever the user asks you to play, steer, dodge, fight, or battle in the pirate game:
1. Emit MULTIPLE control_ship tool calls back-to-back in the SAME turn (for example: accelerate, steer_left or steer_right, fire, fire) instead of waiting for the user to speak again between moves.
2. Keep spoken replies ultra-short (3 to 6 words max, e.g., "Hard left, opening fire!" or "Dodging right, cannons firing!") or silent between bursts so tool calls execute rapidly without voice lag slowing down the match.
3. Repeat bursts of steering + rapid firing continuously until the enemy ship is defeated or the user tells you to stop.

ODYSSEY (UNREAL ENGINE 5.8) GAMEPLAY MODE:
You also control Odysseus in the Unreal Engine 5.8 game "Odyssey" via odyssey_command(command, ...) targeting LiveKit participant "odyssey-game" (valid commands: "get_game_state", "move", "look", "aim_at_enemy", "shoot", "interact", "jump", "restart", "stop").
Whenever the user asks you to play Odyssey, control Odysseus, inspect the game, or defeat enemies:
1. Start by calling odyssey_command({ command: "get_game_state" }) (optionally paired with tactical actions) to inspect player health, position, enemies alive, active target, and status.
2. Based on the returned game state, execute tactical commands (aim_at_enemy, shoot, move, look, jump, interact, get_game_state) to fight and defeat all enemies.
3. Keep spoken FaceTime updates brief (1 short sentence or 3 to 6 words during combat, e.g., "Target locked, firing!" or "Two enemies left.") and keep playing across ticks until all enemies are defeated or the caller tells you to stop.
Outside game battle modes, keep spoken replies conversational, clear, and concise (1 to 3 short sentences at a time).`;

const GREETING_PROMPT =
  'Greet the caller warmly in one short sentence. Let them know audio is connected and that they can ask you to put notes, steps, comparisons, or visuals on the screen anytime.';

const SHOW_ON_SCREEN_TOOL = {
  name: 'show_on_screen',
  description:
    'Updates the clean full-screen display panel in the web app and the FaceTime camera screen whenever the caller asks to see notes, steps, comparisons, lists, or visuals.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'Clear heading displayed prominently at the top of the screen panel.',
      },
      content: {
        type: Type.STRING,
        description: 'Main explanation, summary, notes, or visual description shown on screen.',
      },
      items: {
        type: Type.ARRAY,
        description: 'List of structured points, numbered steps, comparison rows, or key takeaways to display.',
        items: {
          type: Type.STRING,
        },
      },
    },
    required: ['title', 'content', 'items'],
  },
};

const SHOW_VISUAL_TOOL = {
  name: 'show_visual_screen',
  description:
    'Generates an SVG illustration or diagram and displays it on the screen panel and FaceTime camera screen.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'Short title shown on the screen (max 50 chars).',
      },
      kind: {
        type: Type.STRING,
        description: 'Visual style: illustration, diagram, chart, flowchart, geometry, or scene.',
      },
      prompt: {
        type: Type.STRING,
        description: 'Detailed visual composition, labels, shapes, and colors to render on the 640x360 canvas.',
      },
      caption: {
        type: Type.STRING,
        description: 'Optional brief caption.',
      },
    },
    required: ['title', 'kind', 'prompt'],
  },
};

const CLEAR_VISUAL_TOOL = {
  name: 'clear_visual_screen',
  description: 'Clears the active display panel and returns the screen to its idle state.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const CONTROL_SHIP_TOOL = {
  name: 'control_ship',
  description:
    'Pilots the player ship in Pirate Seas 3D. Can be called multiple times back-to-back in the same turn for rapid maneuver + cannon bursts.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      command: {
        type: Type.STRING,
        enum: PIRATE_COMMANDS,
        description:
          'Ship maneuver or combat action: steer_left, steer_right, accelerate, slow_down, fire, or restart.',
      },
    },
    required: ['command'],
  },
};

const ODYSSEY_COMMAND_TOOL = {
  name: 'odyssey_command',
  description:
    'Sends a validated gameplay command to the Unreal Engine 5.8 Odyssey game bridge ("odyssey-game") over LiveKit RPC (with authenticated DataPacket fallback) and returns the game state or execution acknowledgment.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      command: {
        type: Type.STRING,
        enum: ODYSSEY_COMMANDS,
        description:
          'Gameplay command: get_game_state, move, look, aim_at_enemy, shoot, interact, jump, restart, or stop.',
      },
      direction: {
        type: Type.STRING,
        description:
          'Movement direction when command is "move" (e.g. forward, backward, left, right, forward_left, forward_right).',
      },
      duration_ms: {
        type: Type.NUMBER,
        description: 'Optional hold/action duration in milliseconds (clamped 50-3000) for move or shoot.',
      },
      yaw: {
        type: Type.NUMBER,
        description: 'Optional horizontal look delta in degrees (-180 to 180) when command is "look".',
      },
      pitch: {
        type: Type.NUMBER,
        description: 'Optional vertical look delta in degrees (-89 to 89) when command is "look".',
      },
      target: {
        type: Type.STRING,
        description: 'Optional target identifier or index for aim_at_enemy, shoot, or interact.',
      },
      count: {
        type: Type.NUMBER,
        description: 'Optional shot burst count (1-10) when command is "shoot".',
      },
    },
    required: ['command'],
  },
};

async function publishToStudioMonitor(payload) {
  const studioUrl = process.env.STUDIO_URL || 'http://127.0.0.1:3000';
  try {
    await fetch(`${studioUrl}/api/screen/publish`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(2500),
    });
  } catch {
    /* Web studio monitor may not be running locally */
  }
}

function createGeminiClient(apiVersion) {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      ...(apiVersion ? { apiVersion } : {}),
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const agent = defineAgent({
  prewarm: async () => {
    await initStudioBase();
  },
  entry: async (ctx) => {
    await ctx.connect(undefined, AutoSubscribe.SUBSCRIBE_ALL);

    let caller;
    try {
      caller = await ctx.waitForParticipant();
    } catch (err) {
      if (err instanceof Error && /disconnected while waiting/i.test(err.message)) {
        return;
      }
      throw err;
    }

    if (!process.env.GEMINI_API_KEY) {
      throw new Error('GEMINI_API_KEY is required in the environment to run the Chert Visual Agent.');
    }

    const aiStandard = createGeminiClient();
    const aiLive = createGeminiClient('v1alpha');

    let tick = 0;
    let speaking = false;
    let speakingTimeout = null;
    let activeIllustrationRgba = null;
    let visualSeq = 0;
    let closed = false;

    // Connect to LiveKit room "pirate-battle" (data-only companion when this call is on a Chert room)
    const textEncoder = new TextEncoder();
    const textDecoder = new TextDecoder();
    let pirateRoom = ctx.room.name === PIRATE_ROOM_NAME ? ctx.room : null;
    let pirateConnectPromise = null;
    let onPirateRoomReady = null;

    // Continuous battle burst state
    const MAX_BATTLE_BURSTS = 24;
    let pirateBattleActive = false;
    let calledShipThisTurn = false;
    let battleBurstCount = 0;
    let battleTickTimer = null;
    let latestPirateState = null;

    const stopBattleLoop = () => {
      pirateBattleActive = false;
      battleBurstCount = 0;
      if (battleTickTimer) {
        clearTimeout(battleTickTimer);
        battleTickTimer = null;
      }
    };

    const ensurePirateRoom = async () => {
      if (closed) return null;
      if (ctx.room.name === PIRATE_ROOM_NAME) return ctx.room;
      if (pirateRoom?.localParticipant) return pirateRoom;
      if (pirateConnectPromise) return pirateConnectPromise;

      const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET } = process.env;
      if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
        return null;
      }

      pirateConnectPromise = (async () => {
        const room = new Room();
        try {
          const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
            identity: `chert-pirate-pilot-${ctx.job?.id || Date.now()}`,
            name: 'Chert Pirate Pilot',
          });
          token.addGrant({
            room: PIRATE_ROOM_NAME,
            roomJoin: true,
            canPublish: true,
            canPublishData: true,
            canSubscribe: true,
          });
          const jwt = await token.toJwt();
          await room.connect(LIVEKIT_URL, jwt, { autoSubscribe: true });
          if (closed) {
            await room.disconnect().catch(() => {});
            return null;
          }
          pirateRoom = room;
          room.on(RoomEvent.Disconnected, () => {
            if (pirateRoom === room) pirateRoom = null;
          });
          if (onPirateRoomReady) onPirateRoomReady(room);
          console.log(`[chert-visual-agent] connected to LiveKit room "${PIRATE_ROOM_NAME}"`);
          return room;
        } catch (err) {
          console.error(`[chert-visual-agent] failed to connect to "${PIRATE_ROOM_NAME}":`, err);
          await room.disconnect().catch(() => {});
          return null;
        } finally {
          pirateConnectPromise = null;
        }
      })();

      return pirateConnectPromise;
    };

    // Start connecting to "pirate-battle" right away without delaying FaceTime call setup
    void ensurePirateRoom();

    // Connect to LiveKit room "odyssey-game" to communicate with participant "odyssey-game"
    let odysseyRoom = ctx.room.name === ODYSSEY_ROOM_NAME ? ctx.room : null;
    let odysseyConnectPromise = null;
    let onOdysseyRoomReady = null;
    const pendingOdysseyRequests = new Map();

    const MAX_ODYSSEY_TURNS = 40;
    let odysseyActive = false;
    let calledOdysseyThisTurn = false;
    let odysseyTurnCount = 0;
    let odysseyTickTimer = null;
    let latestOdysseyState = null;

    const stopOdysseyLoop = () => {
      odysseyActive = false;
      odysseyTurnCount = 0;
      if (odysseyTickTimer) {
        clearTimeout(odysseyTickTimer);
        odysseyTickTimer = null;
      }
    };

    const checkOdysseyMatchEnded = (state) => {
      if (!state || typeof state !== 'object') return false;
      const enemiesAlive =
        typeof state.enemiesAlive === 'number'
          ? state.enemiesAlive
          : typeof state.enemiesRemaining === 'number'
            ? state.enemiesRemaining
            : null;
      const ended =
        state.victory === true ||
        state.allEnemiesDefeated === true ||
        state.defeat === true ||
        state.gameOver === true ||
        state.status === 'victory' ||
        state.status === 'defeat' ||
        enemiesAlive === 0;
      if (ended) {
        stopOdysseyLoop();
      }
      return ended;
    };

    const ensureOdysseyRoom = async () => {
      if (closed) return null;
      if (ctx.room.name === ODYSSEY_ROOM_NAME) return ctx.room;
      if (odysseyRoom?.localParticipant) return odysseyRoom;
      if (odysseyConnectPromise) return odysseyConnectPromise;

      const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET } = process.env;
      if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET) {
        return null;
      }

      odysseyConnectPromise = (async () => {
        const room = new Room();
        try {
          const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
            identity: `chert-odyssey-agent-${ctx.job?.id || Date.now()}`,
            name: 'Chert Odyssey Agent',
          });
          token.addGrant({
            room: ODYSSEY_ROOM_NAME,
            roomJoin: true,
            canPublish: true,
            canPublishData: true,
            canSubscribe: true,
          });
          const jwt = await token.toJwt();
          await room.connect(LIVEKIT_URL, jwt, { autoSubscribe: true });
          if (closed) {
            await room.disconnect().catch(() => {});
            return null;
          }
          odysseyRoom = room;
          room.on(RoomEvent.Disconnected, () => {
            if (odysseyRoom === room) odysseyRoom = null;
          });
          if (onOdysseyRoomReady) onOdysseyRoomReady(room);
          console.log(`[chert-visual-agent] connected to LiveKit room "${ODYSSEY_ROOM_NAME}"`);
          return room;
        } catch (err) {
          console.error(`[chert-visual-agent] failed to connect to "${ODYSSEY_ROOM_NAME}":`, err);
          await room.disconnect().catch(() => {});
          return null;
        } finally {
          odysseyConnectPromise = null;
        }
      })();

      return odysseyConnectPromise;
    };

    void ensureOdysseyRoom();

    // Ensure studio canvas is initialized (instant no-op when prewarmed) before first frame capture
    await initStudioBase();

    // Video track: capture the initial 640x360 studio frame BEFORE publishing, matching Chert's video-agent spec
    const videoSource = new VideoSource(WIDTH, HEIGHT);
    const videoTrack = LocalVideoTrack.createVideoTrack('agent-video', videoSource);

    const pushVideoFrame = () => {
      if (closed) return;
      const rgba = activeIllustrationRgba
        ? cloneWithSpeakingPulse(activeIllustrationRgba, tick++, speaking)
        : renderStudioFrame(tick++, speaking);
      try {
        videoSource.captureFrame(new VideoFrame(rgba, WIDTH, HEIGHT, VideoBufferType.RGBA));
      } catch {
        /* ignore frame error during teardown */
      }
    };

    pushVideoFrame();
    await ctx.room.localParticipant.publishTrack(videoTrack, {
      source: TrackSource.SOURCE_CAMERA,
    });
    const videoTimer = setInterval(pushVideoFrame, 1000 / FPS);
    console.log('[chert-visual-agent] camera video track published (640x360)');

    // Audio track: publish 24kHz mono microphone track from the exact same participant
    const audioSource = new AudioSource(24000, 1);
    const audioTrack = LocalAudioTrack.createAudioTrack('agent-audio', audioSource);
    await ctx.room.localParticipant.publishTrack(audioTrack, {
      source: TrackSource.SOURCE_MICROPHONE,
    });

    // Serialized audio capture queue so 24kHz PCM chunks play smoothly in order
    let audioQueue = Promise.resolve();
    let epoch = 0;

    const enqueuePcm24k = (base64Pcm) => {
      const currentEpoch = epoch;
      const pcmBuf = Buffer.from(base64Pcm, 'base64');
      if (pcmBuf.byteLength < 2) return;

      const sampleCount = Math.floor(pcmBuf.byteLength / 2);
      const samples = new Int16Array(sampleCount);
      new Uint8Array(samples.buffer).set(pcmBuf.subarray(0, sampleCount * 2));

      speaking = true;
      if (speakingTimeout) clearTimeout(speakingTimeout);
      speakingTimeout = setTimeout(() => {
        speaking = false;
      }, 450);

      audioQueue = audioQueue.then(async () => {
        if (closed || currentEpoch !== epoch) return;
        // Slice into 20ms (480 samples @ 24kHz) standalone frames (byteOffset=0 for LiveKit FFI)
        const chunkSize = 480;
        for (let offset = 0; offset < samples.length; offset += chunkSize) {
          if (closed || currentEpoch !== epoch) return;
          const slice = Int16Array.from(samples.subarray(offset, Math.min(samples.length, offset + chunkSize)));
          const frame = new AudioFrame(slice, 24000, 1, slice.length);
          await audioSource.captureFrame(frame).catch(() => {});
        }
      });
    };

    let session = null;

    const handleToolCalls = async (functionCalls) => {
      for (const call of functionCalls) {
        console.log(`[chert-visual-agent] toolCall: ${call.name}`, JSON.stringify(call.args || {}));
        if (call.name === 'show_on_screen') {
          const seq = ++visualSeq;
          const args = call.args || {};
          const title = String(args.title || 'On Screen');
          const content = String(args.content || '');
          const rawItems = Array.isArray(args.items) ? args.items : args.items ? [args.items] : [];
          const items = rawItems
            .map((item) => {
              if (typeof item === 'string') return item.trim();
              if (item && typeof item === 'object') {
                const label = item.label || item.title || item.key || '';
                const val = item.detail || item.value || item.description || item.text || '';
                return label && val ? `${label}: ${val}` : String(label || val || JSON.stringify(item));
              }
              return String(item ?? '').trim();
            })
            .filter(Boolean);

          try {
            // 1. Update web Display Panel immediately without blocking on HTTP
            void publishToStudioMonitor({
              type: 'display',
              source: 'facetime',
              title,
              content,
              items,
              kind: 'display',
            });

            // 2. Render instant structured card onto FaceTime video track
            const cardSvg = buildStructuredDisplaySvg({ title, content, items });
            const cardRgba = await svgToRgba(cardSvg);
            if (!closed && visualSeq === seq) {
              activeIllustrationRgba = cardRgba;
              pushVideoFrame();
            }

            // 3. Return tool response immediately so the AI keeps talking with zero stall
            session?.sendToolResponse({
              functionResponses: [
                {
                  id: call.id,
                  name: call.name,
                  response: {
                    status: 'displayed',
                    title,
                    itemCount: items.length,
                    message: `Displayed "${title}" on screen.`,
                  },
                },
              ],
            });

            // 4. Upgrade with fast Flash-Lite custom SVG in the background when visual/diagram is requested
            if (
              /\b(draw|illustrat|diagram|chart|graph|visual|sketch|picture|anatomy|cutaway|flowchart|orbit|circuit)\b/i.test(
                `${title} ${content}`,
              )
            ) {
              void (async () => {
                try {
                  const visual = await generateIllustrationSvg({
                    ai: aiStandard,
                    title,
                    kind: 'illustration',
                    prompt: `${title}. ${content}. Elements: ${items.slice(0, 4).join('; ')}`,
                    caption: items[0] || '',
                  });
                  if (closed || visualSeq !== seq) return;
                  void publishToStudioMonitor({
                    type: 'display',
                    source: 'facetime',
                    title,
                    content,
                    items,
                    kind: 'visual',
                    svg: visual.svg,
                  });
                  const svgRgba = await svgToRgba(visual.svg);
                  if (closed || visualSeq !== seq) return;
                  activeIllustrationRgba = svgRgba;
                  pushVideoFrame();
                } catch {
                  /* keep instant structured card if async illustration fails */
                }
              })();
            }
          } catch (error) {
            console.error('[chert-visual-agent] show_on_screen error:', error);
            session?.sendToolResponse({
              functionResponses: [
                {
                  id: call.id,
                  name: call.name,
                  response: {
                    status: 'error',
                    error: error instanceof Error ? error.message : 'Failed to update display panel',
                  },
                },
              ],
            });
          }
        } else if (call.name === 'show_visual_screen') {
          const seq = ++visualSeq;
          const args = call.args || {};
          const title = String(args.title || 'Illustration');
          const kind = String(args.kind || 'illustration');
          const prompt = String(args.prompt || title);
          const caption = String(args.caption || '');
          try {
            // 1. Instant preview on both web Display Panel and FaceTime camera (<30ms)
            const previewItems = [kind ? `Visual (${kind})` : 'Visual', 'Rendering illustration...'];
            void publishToStudioMonitor({
              type: 'display',
              source: 'facetime',
              title,
              content: caption || prompt,
              items: previewItems,
              kind,
              caption,
            });
            const previewSvg = buildStructuredDisplaySvg({
              title,
              content: caption || prompt,
              items: previewItems,
            });
            const previewRgba = await svgToRgba(previewSvg);
            if (!closed && visualSeq === seq) {
              activeIllustrationRgba = previewRgba;
              pushVideoFrame();
            }

            // 2. Acknowledge immediately so voice never pauses waiting for SVG generation
            session?.sendToolResponse({
              functionResponses: [
                {
                  id: call.id,
                  name: call.name,
                  response: {
                    status: 'displayed',
                    title,
                    message: `Showing "${title}" on screen.`,
                  },
                },
              ],
            });

            // 3. Render custom SVG in background with gemini-3.1-flash-lite (MINIMAL thinking)
            void (async () => {
              try {
                const visual = await generateIllustrationSvg({ ai: aiStandard, title, kind, prompt, caption });
                if (closed || visualSeq !== seq) return;
                console.log(`[chert-visual-agent] visual rendered: "${visual.title}"`);
                void publishToStudioMonitor({
                  type: 'visual',
                  source: 'facetime',
                  title: visual.title,
                  content: caption || prompt,
                  items: [],
                  kind: visual.kind,
                  caption: visual.caption,
                  svg: visual.svg,
                });
                const svgRgba = await svgToRgba(visual.svg);
                if (closed || visualSeq !== seq) return;
                activeIllustrationRgba = svgRgba;
                pushVideoFrame();
              } catch (err) {
                console.error('[chert-visual-agent] async visual render error:', err);
              }
            })();
          } catch (error) {
            console.error('[chert-visual-agent] visual render error:', error);
            session?.sendToolResponse({
              functionResponses: [
                {
                  id: call.id,
                  name: call.name,
                  response: {
                    status: 'error',
                    error: error instanceof Error ? error.message : 'Failed to render visual',
                  },
                },
              ],
            });
          }
        } else if (call.name === 'clear_visual_screen') {
          ++visualSeq;
          activeIllustrationRgba = null;
          pushVideoFrame();
          void publishToStudioMonitor({ type: 'clear', source: 'facetime' });
          session?.sendToolResponse({
            functionResponses: [
              {
                id: call.id,
                name: call.name,
                response: { status: 'cleared', message: 'Cleared the display panel.' },
              },
            ],
          });
        } else if (call.name === 'control_ship' || call.name === 'odyssey_command') {
          // Handled as dedicated game transport batches below
        }
      }

      const shipCalls = functionCalls.filter((c) => c.name === 'control_ship');
      if (shipCalls.length > 0) {
        calledShipThisTurn = true;
        pirateBattleActive = true;
        if (battleTickTimer) {
          clearTimeout(battleTickTimer);
          battleTickTimer = null;
        }

        const shipResponses = [];
        let targetRoom = null;
        let roomError = null;
        try {
          targetRoom = await ensurePirateRoom();
          if (!targetRoom?.localParticipant) {
            roomError = `Not connected to LiveKit room "${PIRATE_ROOM_NAME}".`;
          }
        } catch (err) {
          roomError = err instanceof Error ? err.message : 'Failed to connect to pirate-battle room.';
        }

        for (const call of shipCalls) {
          const command = String(call.args?.command || '').trim();
          if (!PIRATE_COMMANDS.includes(command)) {
            shipResponses.push({
              id: call.id,
              name: call.name,
              response: { ok: false, error: `Invalid ship command "${command}".` },
            });
            continue;
          }
          if (roomError || !targetRoom?.localParticipant) {
            shipResponses.push({
              id: call.id,
              name: call.name,
              response: { ok: false, error: roomError || 'Room unavailable.' },
            });
            continue;
          }
          try {
            const payload = textEncoder.encode(
              JSON.stringify({
                type: 'ship_command',
                command,
              }),
            );
            await targetRoom.localParticipant.publishData(payload, { reliable: true });
            console.log(`[chert-visual-agent] ship_command -> ${PIRATE_ROOM_NAME}: ${command}`);
            shipResponses.push({
              id: call.id,
              name: call.name,
              response: { ok: true, command },
            });
          } catch (error) {
            console.error('[chert-visual-agent] control_ship error:', error);
            shipResponses.push({
              id: call.id,
              name: call.name,
              response: {
                ok: false,
                error: error instanceof Error ? error.message : 'Failed to send ship command.',
              },
            });
          }
        }

        session?.sendToolResponse({
          functionResponses: shipResponses,
        });
      }

      const odysseyCalls = functionCalls.filter((c) => c.name === 'odyssey_command');
      if (odysseyCalls.length > 0) {
        if (odysseyTickTimer) {
          clearTimeout(odysseyTickTimer);
          odysseyTickTimer = null;
        }

        const sanitizeOdysseyParams = (rawArgs) => {
          const params = {};
          if (!rawArgs || typeof rawArgs !== 'object') return params;
          if (typeof rawArgs.direction === 'string' && rawArgs.direction.trim()) {
            params.direction = rawArgs.direction.trim().slice(0, 32);
          }
          if (typeof rawArgs.duration_ms === 'number' && Number.isFinite(rawArgs.duration_ms)) {
            params.duration_ms = Math.min(3000, Math.max(50, Math.round(rawArgs.duration_ms)));
          }
          if (typeof rawArgs.yaw === 'number' && Number.isFinite(rawArgs.yaw)) {
            params.yaw = Math.min(180, Math.max(-180, Number(rawArgs.yaw.toFixed(2))));
          }
          if (typeof rawArgs.pitch === 'number' && Number.isFinite(rawArgs.pitch)) {
            params.pitch = Math.min(89, Math.max(-89, Number(rawArgs.pitch.toFixed(2))));
          }
          if (typeof rawArgs.target === 'string' && rawArgs.target.trim()) {
            params.target = rawArgs.target.trim().slice(0, 80);
          }
          if (typeof rawArgs.count === 'number' && Number.isFinite(rawArgs.count)) {
            params.count = Math.min(10, Math.max(1, Math.round(rawArgs.count)));
          }
          return params;
        };

        const resolveOdysseyRoomAndTarget = async () => {
          if (ctx.room.remoteParticipants.has(ODYSSEY_TARGET_IDENTITY)) {
            return { room: ctx.room, hasBridge: true };
          }
          const companion = await ensureOdysseyRoom();
          if (!companion?.localParticipant) {
            return { room: null, hasBridge: false };
          }
          return {
            room: companion,
            hasBridge: companion.remoteParticipants.has(ODYSSEY_TARGET_IDENTITY),
          };
        };

        const sendOdysseyCommand = async (command, rawArgs) => {
          if (!ODYSSEY_COMMANDS.includes(command)) {
            return {
              ok: false,
              command,
              error: `Invalid Odyssey command "${command}". Supported: ${ODYSSEY_COMMANDS.join(', ')}`,
            };
          }

          const { room: targetRoom, hasBridge } = await resolveOdysseyRoomAndTarget();
          if (!targetRoom?.localParticipant) {
            return {
              ok: false,
              command,
              error: `Not connected to LiveKit room "${ODYSSEY_ROOM_NAME}".`,
            };
          }
          if (!hasBridge) {
            return {
              ok: false,
              command,
              bridgeConnected: false,
              error: `Game bridge participant "${ODYSSEY_TARGET_IDENTITY}" is not currently connected in room "${ODYSSEY_ROOM_NAME}".`,
            };
          }

          const requestId = crypto.randomUUID();
          const params = sanitizeOdysseyParams(rawArgs);
          const envelope = {
            type: 'odyssey_command',
            version: 1,
            requestId,
            command,
            params,
            callerIdentity: caller.identity,
            issuedAt: new Date().toISOString(),
          };
          const payloadStr = JSON.stringify(envelope);

          try {
            const rpcRaw = await targetRoom.localParticipant.performRpc({
              destinationIdentity: ODYSSEY_TARGET_IDENTITY,
              method: ODYSSEY_RPC_METHOD,
              payload: payloadStr,
              responseTimeout: 3500,
            });
            let parsed = rpcRaw;
            try {
              parsed = JSON.parse(rpcRaw);
            } catch {
              /* plain-text RPC response */
            }
            if (parsed && typeof parsed === 'object') {
              const stateCandidate = parsed.state && typeof parsed.state === 'object' ? parsed.state : parsed;
              if (
                'enemiesAlive' in stateCandidate ||
                'enemiesRemaining' in stateCandidate ||
                'playerHp' in stateCandidate ||
                'health' in stateCandidate ||
                'status' in stateCandidate ||
                'victory' in stateCandidate
              ) {
                latestOdysseyState = stateCandidate;
                checkOdysseyMatchEnded(stateCandidate);
              }
            }
            console.log(`[chert-visual-agent] odyssey RPC -> ${ODYSSEY_TARGET_IDENTITY}: ${command}`);
            return {
              ok: parsed && typeof parsed === 'object' && typeof parsed.ok === 'boolean' ? parsed.ok : true,
              transport: 'rpc',
              command,
              requestId,
              result: parsed,
            };
          } catch (rpcErr) {
            const rpcCode = rpcErr && typeof rpcErr === 'object' && 'code' in rpcErr ? rpcErr.code : undefined;
            const rpcMsg = rpcErr instanceof Error ? rpcErr.message : String(rpcErr || 'RPC error');
            const shouldFallbackToData = rpcCode === 1400 || /UNSUPPORTED_METHOD/i.test(rpcMsg);

            if (!shouldFallbackToData) {
              console.error('[chert-visual-agent] odyssey RPC failed:', rpcMsg);
              return {
                ok: false,
                transport: 'rpc',
                command,
                requestId,
                code: rpcCode,
                error: rpcMsg,
              };
            }

            try {
              const ackPromise = new Promise((resolve) => {
                const timer = setTimeout(() => {
                  pendingOdysseyRequests.delete(requestId);
                  resolve(null);
                }, 3500);
                pendingOdysseyRequests.set(requestId, { resolve, timer });
              });

              await targetRoom.localParticipant.publishData(textEncoder.encode(payloadStr), {
                reliable: true,
                destination_identities: [ODYSSEY_TARGET_IDENTITY],
                topic: ODYSSEY_DATA_TOPIC,
              });
              console.log(`[chert-visual-agent] odyssey DataPacket -> ${ODYSSEY_TARGET_IDENTITY}: ${command}`);

              const ack = await ackPromise;
              if (ack && typeof ack === 'object') {
                return {
                  ok: typeof ack.ok === 'boolean' ? ack.ok : true,
                  transport: 'data_packet',
                  command,
                  requestId,
                  result: ack,
                };
              }
              return {
                ok: true,
                transport: 'data_packet',
                command,
                requestId,
                note: 'Command delivered via authenticated LiveKit DataPacket.',
              };
            } catch (dataErr) {
              pendingOdysseyRequests.delete(requestId);
              return {
                ok: false,
                transport: 'data_packet',
                command,
                requestId,
                error: dataErr instanceof Error ? dataErr.message : 'Failed to send authenticated DataPacket.',
              };
            }
          }
        };

        const odysseyResponses = [];
        let requestedStop = false;
        let bridgeReady = true;

        for (const call of odysseyCalls) {
          const command = String(call.args?.command || '').trim();
          const res = await sendOdysseyCommand(command, call.args);
          if (command === 'stop') {
            requestedStop = true;
          }
          if (res.bridgeConnected === false) {
            bridgeReady = false;
          }
          odysseyResponses.push({
            id: call.id,
            name: call.name,
            response: res,
          });
        }

        if (requestedStop || !bridgeReady || checkOdysseyMatchEnded(latestOdysseyState)) {
          stopOdysseyLoop();
          calledOdysseyThisTurn = false;
        } else {
          calledOdysseyThisTurn = true;
          odysseyActive = true;
        }

        session?.sendToolResponse({
          functionResponses: odysseyResponses,
        });
      }
    };

    session = await aiLive.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        inputAudioTranscription: {},
        outputAudioTranscription: {},
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Zephyr' },
          },
        },
        systemInstruction: SYSTEM_INSTRUCTIONS,
        tools: [
          {
            functionDeclarations: [
              SHOW_ON_SCREEN_TOOL,
              SHOW_VISUAL_TOOL,
              CLEAR_VISUAL_TOOL,
              CONTROL_SHIP_TOOL,
              ODYSSEY_COMMAND_TOOL,
            ],
          },
        ],
      },
      callbacks: {
        onopen: () => {
          console.log('[chert-visual-agent] Gemini Live v1alpha connected');
        },
        onmessage: (message) => {
          if (closed) return;
          if (message.serverContent?.interrupted) {
            epoch += 1;
            speaking = false;
            if (battleTickTimer) {
              clearTimeout(battleTickTimer);
              battleTickTimer = null;
            }
            if (odysseyTickTimer) {
              clearTimeout(odysseyTickTimer);
              odysseyTickTimer = null;
            }
            try {
              audioSource.clearQueue();
            } catch {
              /* ignore */
            }
          }
          if (message.serverContent?.inputTranscription?.text) {
            const callerText = message.serverContent.inputTranscription.text;
            console.log('[chert-visual-agent] caller:', callerText);
            if (/\b(stop|pause|hold fire|stand down|quit|cancel|done|we won|enemy sunk|game over)\b/i.test(callerText)) {
              stopBattleLoop();
              stopOdysseyLoop();
            } else {
              if (/\b(play|battle|fight|sink|dodge|steer|fire|pirate)\b/i.test(callerText)) {
                battleBurstCount = 0;
              }
              if (/\b(odyssey|odysseus|play|attack|shoot|aim|enemy|enemies|defeat|restart)\b/i.test(callerText)) {
                odysseyTurnCount = 0;
              }
            }
          }
          if (message.serverContent?.outputTranscription?.text) {
            console.log('[chert-visual-agent] ai:', message.serverContent.outputTranscription.text);
          }
          for (const part of message.serverContent?.modelTurn?.parts ?? []) {
            if (part.inlineData?.data) {
              enqueuePcm24k(part.inlineData.data);
            }
          }
          if (message.toolCall?.functionCalls?.length) {
            void handleToolCalls(message.toolCall.functionCalls);
          }
          if (message.serverContent?.turnComplete) {
            const hadShipCalls = calledShipThisTurn;
            calledShipThisTurn = false;
            const hadOdysseyCalls = calledOdysseyThisTurn;
            calledOdysseyThisTurn = false;

            if (pirateBattleActive && hadShipCalls && !closed) {
              if (battleBurstCount < MAX_BATTLE_BURSTS) {
                battleBurstCount += 1;
                if (battleTickTimer) clearTimeout(battleTickTimer);
                const delayMs = speaking ? 650 : 300;
                battleTickTimer = setTimeout(() => {
                  battleTickTimer = null;
                  if (closed || !pirateBattleActive) return;
                  const telemetryHint = latestPirateState
                    ? ` Telemetry: ${JSON.stringify(latestPirateState).slice(0, 140)}.`
                    : '';
                  try {
                    session?.sendClientContent({
                      turns: [
                        {
                          role: 'user',
                          parts: [
                            {
                              text: `[BATTLE TICK] Enemy ship still active.${telemetryHint} Immediately execute your next back-to-back burst of control_ship calls (e.g., steer + accelerate + fire + fire) in this turn. Stay silent or speak 3-6 words max.`,
                            },
                          ],
                        },
                      ],
                      turnComplete: true,
                    });
                  } catch {
                    stopBattleLoop();
                  }
                }, delayMs);
              } else {
                stopBattleLoop();
              }
            } else if (pirateBattleActive && !hadShipCalls) {
              stopBattleLoop();
            }

            if (odysseyActive && hadOdysseyCalls && !closed) {
              if (odysseyTurnCount < MAX_ODYSSEY_TURNS) {
                odysseyTurnCount += 1;
                if (odysseyTickTimer) clearTimeout(odysseyTickTimer);
                const delayMs = speaking ? 550 : 220;
                odysseyTickTimer = setTimeout(() => {
                  odysseyTickTimer = null;
                  if (closed || !odysseyActive) return;
                  const stateHint = latestOdysseyState
                    ? ` Latest state: ${JSON.stringify(latestOdysseyState).slice(0, 220)}.`
                    : '';
                  try {
                    session?.sendClientContent({
                      turns: [
                        {
                          role: 'user',
                          parts: [
                            {
                              text: `[ODYSSEY TICK] Continue playing Odyssey.${stateHint} Call odyssey_command (get_game_state / aim_at_enemy / shoot / move / look / jump / interact) to defeat all remaining enemies. Speak briefly or stay silent.`,
                            },
                          ],
                        },
                      ],
                      turnComplete: true,
                    });
                  } catch {
                    stopOdysseyLoop();
                  }
                }, delayMs);
              } else {
                stopOdysseyLoop();
              }
            } else if (odysseyActive && !hadOdysseyCalls) {
              stopOdysseyLoop();
            }
          }
        },
        onerror: (err) => {
          console.error('[chert-visual-agent] Gemini Live error:', err);
        },
        onclose: (ev) => {
          stopBattleLoop();
          stopOdysseyLoop();
          console.log('[chert-visual-agent] Gemini Live closed:', ev?.reason || ev?.code || 'closed');
        },
      },
    });

    // Bridge incoming caller audio (16kHz mono) and optional video (<= 1 FPS JPEG) to Gemini Live
    const activeStreams = new Set();

    const attachTrack = (track) => {
      if (closed || activeStreams.has(track.sid)) return;
      activeStreams.add(track.sid);
      console.log(`[chert-visual-agent] attachTrack kind=${track.kind} sid=${track.sid}`);

      if (track.kind === TrackKind.KIND_AUDIO) {
        const stream = new AudioStream(track, 16000, 1);
        const reader = stream.getReader();
        let audioFrameCount = 0;
        let loggedAudible = false;
        (async () => {
          try {
            while (!closed) {
              const { value: frame, done } = await reader.read();
              if (done || !frame) break;
              audioFrameCount++;
              if (!loggedAudible) {
                let maxAbs = 0;
                for (let i = 0; i < frame.data.length; i++) {
                  const v = Math.abs(frame.data[i]);
                  if (v > maxAbs) maxAbs = v;
                }
                if (maxAbs > 250) {
                  loggedAudible = true;
                  console.log(
                    `[chert-visual-agent] caller audible audio frame #${audioFrameCount} max=${maxAbs} samples=${frame.data.length}`,
                  );
                }
              }
              const pcmBytes = Buffer.from(frame.data.buffer, frame.data.byteOffset, frame.data.byteLength);
              session?.sendRealtimeInput({
                audio: {
                  data: pcmBytes.toString('base64'),
                  mimeType: 'audio/pcm;rate=16000',
                },
              });
            }
          } catch (err) {
            console.error('[chert-visual-agent] audio stream error:', err);
          } finally {
            reader.releaseLock();
          }
        })();
      } else if (track.kind === TrackKind.KIND_VIDEO) {
        const stream = new VideoStream(track);
        const reader = stream.getReader();
        let lastSentAt = 0;
        (async () => {
          try {
            while (!closed) {
              const { value: event, done } = await reader.read();
              if (done || !event?.frame) break;
              const now = Date.now();
              if (now - lastSentAt < 1000) continue; // Cap at 1 FPS per Live API rule
              lastSentAt = now;
              const rgbaFrame = event.frame.convert(VideoBufferType.RGBA);
              const jpeg = await sharp(Buffer.from(rgbaFrame.data), {
                raw: { width: rgbaFrame.width, height: rgbaFrame.height, channels: 4 },
              })
                .resize(640, 360, { fit: 'inside' })
                .jpeg({ quality: 70 })
                .toBuffer();
              session?.sendRealtimeInput({
                video: {
                  data: jpeg.toString('base64'),
                  mimeType: 'image/jpeg',
                },
              });
            }
          } catch {
            /* video track ended */
          } finally {
            reader.releaseLock();
          }
        })();
      }
    };

    for (const publication of caller.trackPublications.values()) {
      if (publication.track) attachTrack(publication.track);
    }

    const onTrackSubscribed = (track, _publication, participant) => {
      if (participant.identity === caller.identity) {
        attachTrack(track);
      }
    };
    ctx.room.on(RoomEvent.TrackSubscribed, onTrackSubscribed);

    // Observe video (<= 1 FPS) and optional game-state telemetry in "pirate-battle"
    const bindPirateRoomEvents = (room) => {
      for (const participant of room.remoteParticipants.values()) {
        for (const pub of participant.trackPublications.values()) {
          if (pub.track && pub.track.kind === TrackKind.KIND_VIDEO) {
            attachTrack(pub.track);
          }
        }
      }
      room.on(RoomEvent.TrackSubscribed, (track) => {
        if (track.kind === TrackKind.KIND_VIDEO) {
          attachTrack(track);
        }
      });
      room.on(RoomEvent.DataReceived, (payload) => {
        try {
          const msg = JSON.parse(textDecoder.decode(payload));
          if (!msg || msg.type === 'ship_command') return;
          latestPirateState = msg;
          if (
            msg.enemySunk === true ||
            msg.victory === true ||
            msg.defeat === true ||
            msg.gameOver === true ||
            msg.status === 'victory' ||
            msg.status === 'defeat' ||
            msg.enemyHp === 0
          ) {
            stopBattleLoop();
          }
        } catch {
          /* ignore non-JSON data packets */
        }
      });
    };
    onPirateRoomReady = bindPirateRoomEvents;
    if (pirateRoom) {
      bindPirateRoomEvents(pirateRoom);
    }

    // Observe video (<= 1 FPS) and authenticated game-state telemetry in "odyssey-game"
    const bindOdysseyRoomEvents = (room) => {
      for (const participant of room.remoteParticipants.values()) {
        if (participant.identity !== ODYSSEY_TARGET_IDENTITY) continue;
        for (const pub of participant.trackPublications.values()) {
          if (pub.track && pub.track.kind === TrackKind.KIND_VIDEO) {
            attachTrack(pub.track);
          }
        }
      }
      room.on(RoomEvent.TrackSubscribed, (track, _pub, participant) => {
        if (participant?.identity === ODYSSEY_TARGET_IDENTITY && track.kind === TrackKind.KIND_VIDEO) {
          attachTrack(track);
        }
      });
      room.on(RoomEvent.DataReceived, (payload, participant) => {
        // Strictly accept game telemetry and command replies only from the authenticated "odyssey-game" participant
        if (!participant || participant.identity !== ODYSSEY_TARGET_IDENTITY) return;
        try {
          const msg = JSON.parse(textDecoder.decode(payload));
          if (!msg || typeof msg !== 'object') return;
          if (msg.type === 'odyssey_command_result' && msg.requestId) {
            const pending = pendingOdysseyRequests.get(msg.requestId);
            if (pending) {
              clearTimeout(pending.timer);
              pendingOdysseyRequests.delete(msg.requestId);
              pending.resolve(msg);
            }
          }
          const stateCandidate = msg.state && typeof msg.state === 'object' ? msg.state : msg;
          if (
            msg.type === 'odyssey_state' ||
            'enemiesAlive' in stateCandidate ||
            'enemiesRemaining' in stateCandidate ||
            'playerHp' in stateCandidate ||
            'health' in stateCandidate ||
            'victory' in stateCandidate
          ) {
            latestOdysseyState = stateCandidate;
            checkOdysseyMatchEnded(stateCandidate);
          }
        } catch {
          /* ignore non-JSON data packets */
        }
      });
    };
    onOdysseyRoomReady = bindOdysseyRoomEvents;
    if (odysseyRoom) {
      bindOdysseyRoomEvents(odysseyRoom);
    }

    // Greet only after chert dev sets chert_bridge_ready: true in room metadata
    const stopGreeting = greetOnBridgeReady(ctx.room, () => {
      try {
        session?.sendClientContent({
          turns: [{ role: 'user', parts: [{ text: GREETING_PROMPT }] }],
          turnComplete: true,
        });
      } catch {
        /* session already closed */
      }
    });

    ctx.addShutdownCallback(async () => {
      closed = true;
      stopBattleLoop();
      stopOdysseyLoop();
      for (const pending of pendingOdysseyRequests.values()) {
        clearTimeout(pending.timer);
        pending.resolve(null);
      }
      pendingOdysseyRequests.clear();
      stopGreeting();
      ctx.room.off(RoomEvent.TrackSubscribed, onTrackSubscribed);
      clearInterval(videoTimer);
      if (speakingTimeout) clearTimeout(speakingTimeout);
      try {
        session?.close();
      } catch {
        /* ignore */
      }
      if (pirateRoom && pirateRoom !== ctx.room) {
        await pirateRoom.disconnect().catch(() => {});
        pirateRoom = null;
      }
      if (odysseyRoom && odysseyRoom !== ctx.room) {
        await odysseyRoom.disconnect().catch(() => {});
        odysseyRoom = null;
      }
      await audioTrack.close().catch(() => {});
      await audioSource.close().catch(() => {});
      await videoTrack.close().catch(() => {});
      await videoSource.close().catch(() => {});
    });
  },
});

export default agent;

runAgent(agent, {
  file: fileURLToPath(import.meta.url),
  agentName: process.env.AGENT_NAME || 'chert-visual-agent',
});
