import 'dotenv/config';
import { ChildProcess, execFile, spawn } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import express from 'express';
import { AccessToken, RoomServiceClient } from 'livekit-server-sdk';
import { WebSocket, WebSocketServer } from 'ws';
import { generateIllustrationSvg } from './agent/visual-screen.mjs';

const execFileAsync = promisify(execFile);
const PORT = 3000;

const ODYSSEY_ROOM_NAME = 'odyssey-game';
const ODYSSEY_PARTICIPANT_IDENTITY = 'odyssey-game';
const ODYSSEY_RPC_METHOD = 'odyssey_command';
const ODYSSEY_DATA_TOPIC = 'odyssey';
const ODYSSEY_COMMANDS = [
  'get_game_state',
  'move',
  'look',
  'aim_at_enemy',
  'shoot',
  'interact',
  'jump',
  'restart',
  'stop',
] as const;

interface ScreenVisual {
  id: string;
  title: string;
  content: string;
  items: string[];
  kind: string;
  caption: string;
  svg?: string;
  source: 'studio' | 'facetime';
  createdAt: string;
}

const studioState: {
  activeVisual: ScreenVisual | null;
  history: ScreenVisual[];
} = {
  activeVisual: null,
  history: [],
};

interface BridgeRuntimeState {
  agentStatus: 'stopped' | 'starting' | 'running' | 'error';
  chertStatus: 'stopped' | 'connecting' | 'ready' | 'in_call' | 'error';
  lastMessage: string;
  lastError: string | null;
  logs: string[];
}

const bridgeState: BridgeRuntimeState = {
  agentStatus: 'stopped',
  chertStatus: 'stopped',
  lastMessage: 'Waiting to start FaceTime bridge.',
  lastError: null,
  logs: [],
};

let agentProc: ChildProcess | null = null;
let chertProc: ChildProcess | null = null;
let loginProc: ChildProcess | null = null;
let bridgeDesired = true;
let bridgeStartInFlight: Promise<void> | null = null;
let restartTimer: NodeJS.Timeout | null = null;
let displacedByOtherSession = false;
let authRequired = false;

interface ChertLoginState {
  status: 'idle' | 'pending' | 'signed_in' | 'error';
  userCode?: string;
  verificationUrl?: string;
  verificationUrlComplete?: string;
  message?: string;
  error?: string;
}

const chertLoginState: ChertLoginState = {
  status: 'idle',
};

const WORKSPACE_CHERT_HOME = join(process.cwd(), '.chert');

function ensureChertHome(): string {
  try {
    mkdirSync(WORKSPACE_CHERT_HOME, { recursive: true, mode: 0o700 });
    const legacyHome = join(homedir(), '.chert');
    if (
      existsSync(legacyHome) &&
      readdirSync(WORKSPACE_CHERT_HOME).length === 0 &&
      readdirSync(legacyHome).length > 0
    ) {
      cpSync(legacyHome, WORKSPACE_CHERT_HOME, { recursive: true });
    }
  } catch {
    /* ignore migration issues */
  }
  return WORKSPACE_CHERT_HOME;
}

function pushBridgeLog(line: string) {
  const clean = line.trim();
  if (!clean) return;
  bridgeState.logs = [...bridgeState.logs.slice(-24), clean];
}

const screenClients = new Set<WebSocket>();

function broadcastScreen(payload: unknown) {
  const raw = JSON.stringify(payload);
  for (const client of screenClients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(raw);
    }
  }
}

function getGeminiClient(apiVersion?: string) {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is not configured in environment secrets.');
  }
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      ...(apiVersion ? { apiVersion } : {}),
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function parseEnvFile(filePath: string): Record<string, string> {
  if (!existsSync(filePath)) return {};
  const content = readFileSync(filePath, 'utf8');
  const out: Record<string, string> = {};
  for (const line of content.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const val = trimmed.slice(eq + 1).trim().replace(/^['"]|['"]$/g, '');
    out[key] = val;
  }
  return out;
}

function isRealEnvValue(val: string | undefined): boolean {
  return Boolean(val) && !/^(wss:\/\/)?YOUR_/.test(val ?? '') && !/^MY_/.test(val ?? '');
}

function getEffectiveConfig() {
  const envLocal = parseEnvFile(join(process.cwd(), '.env.local'));
  const geminiKey = process.env.GEMINI_API_KEY || envLocal.GEMINI_API_KEY;
  const livekitUrl = process.env.LIVEKIT_URL || envLocal.LIVEKIT_URL;
  const livekitKey = process.env.LIVEKIT_API_KEY || envLocal.LIVEKIT_API_KEY;
  const livekitSecret = process.env.LIVEKIT_API_SECRET || envLocal.LIVEKIT_API_SECRET;
  const chertAccessToken = process.env.CHERT_USER_ACCESS_TOKEN || envLocal.CHERT_USER_ACCESS_TOKEN;
  const agentName = envLocal.AGENT_NAME || process.env.AGENT_NAME || 'chert-visual-agent';

  return {
    geminiKey,
    livekitUrl,
    livekitKey,
    livekitSecret,
    chertAccessToken,
    agentName,
    chertHome: ensureChertHome(),
    hasGeminiKey: isRealEnvValue(geminiKey),
    hasLiveKitUrl: isRealEnvValue(livekitUrl),
    hasLiveKitKey: isRealEnvValue(livekitKey),
    hasLiveKitSecret: isRealEnvValue(livekitSecret),
  };
}

async function resolveChertCommand(): Promise<{ bin: string; prefixArgs: string[] }> {
  const localBin = join(process.cwd(), 'node_modules', '.bin', 'chert');
  if (existsSync(localBin)) {
    return { bin: localBin, prefixArgs: [] };
  }
  return { bin: 'npx', prefixArgs: ['--yes', '@trychert/facetime@0.1.0-beta.21'] };
}

async function runChertJson(args: string[]) {
  const { bin, prefixArgs } = await resolveChertCommand();
  const cfg = getEffectiveConfig();
  try {
    const { stdout, stderr } = await execFileAsync(bin, [...prefixArgs, ...args], {
      cwd: process.cwd(),
      timeout: 15000,
      env: {
        ...process.env,
        CHERT_HOME: cfg.chertHome,
        ...(cfg.chertAccessToken ? { CHERT_USER_ACCESS_TOKEN: cfg.chertAccessToken } : {}),
        ...(cfg.livekitUrl ? { LIVEKIT_URL: cfg.livekitUrl } : {}),
        ...(cfg.livekitKey ? { LIVEKIT_API_KEY: cfg.livekitKey } : {}),
        ...(cfg.livekitSecret ? { LIVEKIT_API_SECRET: cfg.livekitSecret } : {}),
        AGENT_NAME: cfg.agentName,
      },
    });
    const text = (stdout || stderr || '').trim();
    try {
      return { ok: true, data: JSON.parse(text) };
    } catch {
      return { ok: true, data: { raw: text } };
    }
  } catch (err: unknown) {
    const e = err as { stdout?: string; stderr?: string; message?: string; code?: number };
    const text = (e.stdout || e.stderr || e.message || '').trim();
    try {
      return { ok: false, exitCode: e.code ?? 1, data: JSON.parse(text) };
    } catch {
      return { ok: false, exitCode: e.code ?? 1, data: { message: text } };
    }
  }
}

function stopFaceTimeProcesses(manualStop = false) {
  if (manualStop) bridgeDesired = false;
  if (restartTimer) {
    clearTimeout(restartTimer);
    restartTimer = null;
  }
  const prevChert = chertProc;
  const prevAgent = agentProc;
  chertProc = null;
  agentProc = null;
  if (prevChert) {
    try {
      prevChert.kill('SIGINT');
    } catch {}
  }
  if (prevAgent) {
    try {
      prevAgent.kill('SIGTERM');
    } catch {}
  }
  bridgeState.agentStatus = 'stopped';
  bridgeState.chertStatus = 'stopped';
  bridgeState.lastMessage = 'FaceTime bridge stopped.';
}

function scheduleBridgeRecovery(delayMs = 2000) {
  if (!bridgeDesired || displacedByOtherSession || authRequired || restartTimer) return;
  restartTimer = setTimeout(() => {
    restartTimer = null;
    if (bridgeDesired && !displacedByOtherSession && !authRequired && (!agentProc || !chertProc)) {
      stopFaceTimeProcesses(false);
      void startFaceTimeProcesses();
    }
  }, delayMs);
}

async function startFaceTimeProcesses() {
  if (bridgeStartInFlight) return bridgeStartInFlight;

  bridgeStartInFlight = (async () => {
    bridgeDesired = true;
    displacedByOtherSession = false;
    authRequired = false;

    const cfg = getEffectiveConfig();
    if (!cfg.hasGeminiKey || !cfg.hasLiveKitUrl || !cfg.hasLiveKitKey || !cfg.hasLiveKitSecret) {
      bridgeState.agentStatus = 'stopped';
      bridgeState.chertStatus = 'stopped';
      bridgeState.lastError = 'Waiting for GEMINI_API_KEY and LiveKit secrets.';
      return;
    }

    const whoamiRes = await runChertJson(['whoami', '--json']);
    const whoamiData = (whoamiRes.data || {}) as { signed_in?: boolean; project_id?: string };
    if (!whoamiData.signed_in) {
      authRequired = true;
      stopFaceTimeProcesses(false);
      bridgeState.agentStatus = 'stopped';
      bridgeState.chertStatus = 'error';
      bridgeState.lastMessage = 'Chert sign-in required before connecting your FaceTime line.';
      bridgeState.lastError = 'Chert sign-in required. Click "Sign in to Chert" to approve this server.';
      return;
    }

    if (agentProc && chertProc) return;
    stopFaceTimeProcesses(false);

    // Ensure no orphaned agent/chert processes from a crashed dev session linger
    await execFileAsync('pkill', ['-f', 'agent/agent.mjs'], { timeout: 2000 }).catch(() => {});
    await new Promise((r) => setTimeout(r, 250));

    bridgeState.lastError = null;
    bridgeState.agentStatus = 'starting';
    bridgeState.chertStatus = 'connecting';
    bridgeState.lastMessage = 'Starting LiveKit AI agent and connecting to Chert FaceTime line...';

    const childEnv: NodeJS.ProcessEnv = {
      ...process.env,
      CHERT_HOME: cfg.chertHome,
      ...(cfg.chertAccessToken ? { CHERT_USER_ACCESS_TOKEN: cfg.chertAccessToken } : {}),
      GEMINI_API_KEY: cfg.geminiKey,
      LIVEKIT_URL: cfg.livekitUrl,
      LIVEKIT_API_KEY: cfg.livekitKey,
      LIVEKIT_API_SECRET: cfg.livekitSecret,
      AGENT_NAME: cfg.agentName,
      STUDIO_URL: `http://127.0.0.1:${PORT}`,
    };

    // 1. Start the LiveKit AI Audio + Video Agent worker and wait until registered before claiming the Chert line
    let resolveRegistered: (() => void) | null = null;
    const workerRegistered = new Promise<void>((resolve) => {
      resolveRegistered = resolve;
      setTimeout(resolve, 6000);
    });

    const spawnedAgent = spawn('node', ['agent/agent.mjs', 'start'], {
      cwd: process.cwd(),
      env: childEnv,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    agentProc = spawnedAgent;

    spawnedAgent.stdout?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        pushBridgeLog(`[agent] ${line}`);
        if (/registered worker|server started/i.test(line)) {
          bridgeState.agentStatus = 'running';
          resolveRegistered?.();
          resolveRegistered = null;
        }
      }
    });

    spawnedAgent.stderr?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        pushBridgeLog(`[agent] ${line}`);
      }
    });

    spawnedAgent.on('exit', (code) => {
      if (agentProc === spawnedAgent) {
        agentProc = null;
        bridgeState.agentStatus = code === 0 ? 'stopped' : 'error';
        if (code && code !== 0) {
          bridgeState.lastError = `AI agent exited with code ${code}; restarting automatically...`;
        }
        resolveRegistered?.();
        resolveRegistered = null;
        // Never leave Chert claiming the line without a live agent worker
        if (bridgeDesired && !displacedByOtherSession && !authRequired) {
          scheduleBridgeRecovery(1500);
        }
      }
    });

    await workerRegistered;
    if (agentProc !== spawnedAgent || !bridgeDesired) return;
    if (bridgeState.agentStatus === 'starting') {
      bridgeState.agentStatus = 'running';
    }

    // 2. Start Chert dev connector to claim the line and bridge FaceTime calls to the registered agent
    const { bin, prefixArgs } = await resolveChertCommand();
    const chertArgs = [
      ...prefixArgs,
      'dev',
      '--agent',
      cfg.agentName,
      ...(whoamiData.project_id ? ['--project', whoamiData.project_id] : []),
      '--takeover',
      '--force',
      '--json',
    ];
    const spawnedChert = spawn(bin, chertArgs, {
      cwd: process.cwd(),
      env: childEnv,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    chertProc = spawnedChert;

    spawnedChert.stdout?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        pushBridgeLog(`[chert] ${trimmed}`);
        try {
          const rec = JSON.parse(trimmed) as {
            code?: string;
            message?: string;
            action?: string;
            video?: boolean;
            state?: string;
          };
          if (rec.message) bridgeState.lastMessage = rec.message;
          if (
            rec.code === 'agent_warm' ||
            rec.code === 'line_claimed' ||
            rec.code === 'listening' ||
            rec.code === 'dev_ready' ||
            rec.code === 'room_ready' ||
            rec.code === 'dev_reconnected'
          ) {
            bridgeState.chertStatus = 'ready';
            bridgeState.lastError = null;
          } else if (rec.code === 'call_started' || rec.code === 'bridge_ready' || rec.code === 'call_connected') {
            bridgeState.chertStatus = 'in_call';
          } else if (rec.code === 'incoming') {
            bridgeState.chertStatus = 'in_call';
            bridgeState.lastMessage = rec.video
              ? 'Incoming FaceTime Video call (video + audio active).'
              : 'Incoming FaceTime Audio call (tap Video in FaceTime to see the AI screen).';
          } else if (rec.code === 'media') {
            if (rec.state === 'video_unused') {
              bridgeState.lastError = 'Caller dialed with FaceTime Audio only. Dial using FaceTime Video to see the AI Camera Screen.';
            } else if (rec.state === 'no_video' || rec.state === 'video_elsewhere') {
              bridgeState.lastError = `Video routing state: ${rec.state}.`;
            } else if (rec.state === 'ok') {
              bridgeState.lastError = null;
            }
          } else if (rec.code === 'call_ended') {
            bridgeState.chertStatus = 'ready';
          } else if (rec.code === 'displaced') {
            displacedByOtherSession = true;
            bridgeState.chertStatus = 'error';
            bridgeState.lastError = rec.message || 'Another session took over this FaceTime line.';
          } else if (
            rec.code === 'login_required' ||
            rec.code === 'project_not_signed_in' ||
            rec.code === 'project_required' ||
            rec.code === 'line_not_found'
          ) {
            authRequired = true;
            bridgeState.chertStatus = 'error';
            bridgeState.lastError = rec.action || rec.message || 'Chert sign-in required.';
          } else if (rec.action && /error|fail|denied|invalid|refused/i.test(rec.code || '')) {
            bridgeState.chertStatus = 'error';
            bridgeState.lastError = rec.message || rec.action || 'Chert bridge interrupted.';
          }
        } catch {
          /* non-JSON line */
        }
      }
    });

    spawnedChert.stderr?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        if (!line.trim()) continue;
        pushBridgeLog(`[chert] ${line}`);
      }
    });

    spawnedChert.on('exit', (code) => {
      if (chertProc === spawnedChert) {
        chertProc = null;
        bridgeState.chertStatus = code === 0 ? 'stopped' : 'error';
        if (code && code !== 0 && !bridgeState.lastError) {
          bridgeState.lastError = `Chert bridge exited with code ${code}.`;
        }
        if (authRequired && agentProc) {
          try {
            agentProc.kill('SIGTERM');
          } catch {}
          agentProc = null;
          bridgeState.agentStatus = 'stopped';
        }
        if (bridgeDesired && !displacedByOtherSession && !authRequired) {
          scheduleBridgeRecovery(2500);
        }
      }
    });
  })().finally(() => {
    bridgeStartInFlight = null;
  });

  return bridgeStartInFlight;
}

async function startChertDeviceLogin(): Promise<ChertLoginState> {
  if (loginProc) {
    try {
      loginProc.kill('SIGTERM');
    } catch {}
    loginProc = null;
  }

  const cfg = getEffectiveConfig();
  const { bin, prefixArgs } = await resolveChertCommand();

  chertLoginState.status = 'pending';
  chertLoginState.userCode = undefined;
  chertLoginState.verificationUrl = undefined;
  chertLoginState.verificationUrlComplete = undefined;
  chertLoginState.message = 'Requesting Chert sign-in code...';
  chertLoginState.error = undefined;

  return new Promise<ChertLoginState>((resolve) => {
    let settled = false;
    const finishInitial = () => {
      if (!settled) {
        settled = true;
        resolve({ ...chertLoginState });
      }
    };
    const timer = setTimeout(finishInitial, 8000);

    const proc = spawn(bin, [...prefixArgs, 'login', '--device', '--json'], {
      cwd: process.cwd(),
      env: {
        ...process.env,
        CHERT_HOME: cfg.chertHome,
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    loginProc = proc;

    proc.stdout?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split(/\r?\n/)) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        pushBridgeLog(`[chert-login] ${trimmed}`);
        try {
          const rec = JSON.parse(trimmed) as {
            code?: string;
            user_code?: string;
            verification_url?: string;
            verification_url_complete?: string;
            message?: string;
            action?: string;
          };
          if (rec.code === 'login_code') {
            chertLoginState.status = 'pending';
            chertLoginState.userCode = rec.user_code;
            chertLoginState.verificationUrl = rec.verification_url;
            chertLoginState.verificationUrlComplete = rec.verification_url_complete;
            chertLoginState.message = rec.message || 'Approve sign-in in your browser.';
            clearTimeout(timer);
            finishInitial();
          } else if (rec.code === 'signed_in') {
            chertLoginState.status = 'signed_in';
            chertLoginState.message = rec.message || 'Signed in to Chert.';
            chertLoginState.error = undefined;
            authRequired = false;
            clearTimeout(timer);
            finishInitial();
            void startFaceTimeProcesses();
          } else if (rec.code === 'login_expired' || rec.code === 'login_unavailable' || rec.code === 'login_interrupted') {
            chertLoginState.status = 'error';
            chertLoginState.error = rec.action || rec.message || 'Chert sign-in did not complete.';
            clearTimeout(timer);
            finishInitial();
          }
        } catch {
          /* non-JSON line */
        }
      }
    });

    proc.stderr?.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8').trim();
      if (text) pushBridgeLog(`[chert-login] ${text}`);
    });

    proc.on('exit', (code) => {
      if (loginProc === proc) {
        loginProc = null;
      }
      if (chertLoginState.status === 'pending' && code !== 0) {
        chertLoginState.status = 'error';
        chertLoginState.error = chertLoginState.error || `Sign-in exited with code ${code}. Click Sign in to Chert to try again.`;
      }
      clearTimeout(timer);
      finishInitial();
    });
  });
}

const SHOW_ON_SCREEN_TOOL = {
  name: 'show_on_screen',
  description:
    'Updates the clean full-screen display panel in the web app whenever the caller asks to see notes, steps, comparisons, lists, or visuals.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'Clear heading displayed at the top of the screen panel.',
      },
      content: {
        type: Type.STRING,
        description: 'Main summary, notes, explanation, or visual description.',
      },
      items: {
        type: Type.ARRAY,
        description: 'Structured list of steps, bullet notes, comparison points, or key highlights.',
        items: {
          type: Type.STRING,
        },
      },
    },
    required: ['title', 'content', 'items'],
  },
};

const SHOW_VISUAL_TOOL = {
  name: 'show_visual_screen',
  description:
    'Generates an illustration, diagram, chart, or visual scene and displays it on the display panel and AI camera screen.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      title: {
        type: Type.STRING,
        description: 'Short display title shown on the screen.',
      },
      kind: {
        type: Type.STRING,
        description: 'Visual type: illustration, diagram, chart, flowchart, geometry, or scene.',
      },
      prompt: {
        type: Type.STRING,
        description: 'Detailed visual composition, labels, shapes, and colors to render on the 640x360 canvas.',
      },
      caption: {
        type: Type.STRING,
        description: 'Optional concise caption.',
      },
    },
    required: ['title', 'kind', 'prompt'],
  },
};

const CLEAR_VISUAL_TOOL = {
  name: 'clear_visual_screen',
  description: 'Clears the active display panel and returns the screen to its idle state.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/chert/status', async (_req, res) => {
    const cfg = getEffectiveConfig();
    const [whoami, onboarding] = await Promise.all([
      runChertJson(['whoami', '--json']),
      runChertJson(['onboard', '--status', '--json']),
    ]);

    res.json({
      whoami: whoami.data,
      onboarding: onboarding.data,
      bridge: bridgeState,
      login: chertLoginState,
      env: {
        hasGeminiKey: cfg.hasGeminiKey,
        hasLiveKitUrl: cfg.hasLiveKitUrl,
        hasLiveKitKey: cfg.hasLiveKitKey,
        hasLiveKitSecret: cfg.hasLiveKitSecret,
        agentName: cfg.agentName,
      },
    });
  });

  app.post('/api/chert/login', async (_req, res) => {
    const login = await startChertDeviceLogin();
    res.json({ login });
  });

  app.post('/api/chert/bridge', async (req, res) => {
    const action = String(req.body?.action || 'restart');
    if (action === 'stop') {
      stopFaceTimeProcesses(true);
    } else if (action === 'restart') {
      stopFaceTimeProcesses(false);
      await startFaceTimeProcesses();
    } else {
      await startFaceTimeProcesses();
    }
    res.json({ bridge: bridgeState });
  });

  app.post('/api/chert/doctor', async (req, res) => {
    const checkAgent = Boolean(req.body?.checkAgent);
    const cfg = getEffectiveConfig();
    const args = ['doctor', '--json'];
    if (checkAgent) {
      args.push('--agent', cfg.agentName);
    }
    const result = await runChertJson(args);
    res.json(result.data);
  });

  app.get('/api/odyssey/info', async (_req, res) => {
    const cfg = getEffectiveConfig();
    let bridgeConnected = false;
    let participants: Array<{ identity: string; kind: number }> = [];

    if (cfg.hasLiveKitUrl && cfg.hasLiveKitKey && cfg.hasLiveKitSecret && cfg.livekitUrl) {
      try {
        const rooms = new RoomServiceClient(cfg.livekitUrl, cfg.livekitKey, cfg.livekitSecret);
        const list = await rooms.listParticipants(ODYSSEY_ROOM_NAME);
        participants = list.map((p) => ({ identity: p.identity, kind: Number(p.kind) }));
        bridgeConnected = list.some((p) => p.identity === ODYSSEY_PARTICIPANT_IDENTITY);
      } catch {
        /* Room does not exist yet or no participants joined */
      }
    }

    res.json({
      livekitUrl: cfg.hasLiveKitUrl ? cfg.livekitUrl : null,
      roomName: ODYSSEY_ROOM_NAME,
      participantIdentity: ODYSSEY_PARTICIPANT_IDENTITY,
      agentName: cfg.agentName,
      rpcMethod: ODYSSEY_RPC_METHOD,
      dataTopic: ODYSSEY_DATA_TOPIC,
      supportedCommands: ODYSSEY_COMMANDS,
      bridgeConnected,
      participants,
    });
  });

  app.post('/api/odyssey/token', async (req, res) => {
    const cfg = getEffectiveConfig();
    if (!cfg.hasLiveKitUrl || !cfg.hasLiveKitKey || !cfg.hasLiveKitSecret || !cfg.livekitUrl || !cfg.livekitKey || !cfg.livekitSecret) {
      res.status(503).json({ error: 'LiveKit credentials are not configured on the server.' });
      return;
    }

    const bridgeSecret = process.env.ODYSSEY_BRIDGE_SECRET;
    if (bridgeSecret) {
      const auth = String(req.headers.authorization || '');
      if (auth !== `Bearer ${bridgeSecret}`) {
        res.status(401).json({ error: 'Invalid or missing bridge authorization.' });
        return;
      }
    }

    const requestedTtl = Number(req.body?.ttlSeconds ?? 600);
    const ttlSeconds = Number.isFinite(requestedTtl) ? Math.min(900, Math.max(60, Math.round(requestedTtl))) : 600;

    try {
      const accessToken = new AccessToken(cfg.livekitKey, cfg.livekitSecret, {
        identity: ODYSSEY_PARTICIPANT_IDENTITY,
        name: 'Odyssey Game Bridge',
        ttl: ttlSeconds,
      });
      accessToken.addGrant({
        room: ODYSSEY_ROOM_NAME,
        roomJoin: true,
        canPublish: true,
        canPublishData: true,
        canSubscribe: true,
      });
      const jwt = await accessToken.toJwt();

      res.json({
        livekitUrl: cfg.livekitUrl,
        roomName: ODYSSEY_ROOM_NAME,
        identity: ODYSSEY_PARTICIPANT_IDENTITY,
        token: jwt,
        expiresInSeconds: ttlSeconds,
        expiresAt: new Date(Date.now() + ttlSeconds * 1000).toISOString(),
        rpcMethod: ODYSSEY_RPC_METHOD,
        dataTopic: ODYSSEY_DATA_TOPIC,
      });
    } catch (error) {
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Failed to issue Odyssey LiveKit token.',
      });
    }
  });

  app.post('/api/odyssey/ping', async (req, res) => {
    const cfg = getEffectiveConfig();
    if (!cfg.hasLiveKitUrl || !cfg.hasLiveKitKey || !cfg.hasLiveKitSecret || !cfg.livekitUrl || !cfg.livekitKey || !cfg.livekitSecret) {
      res.status(503).json({ error: 'LiveKit credentials are not configured on the server.' });
      return;
    }

    const bridgeSecret = process.env.ODYSSEY_BRIDGE_SECRET;
    if (bridgeSecret) {
      const auth = String(req.headers.authorization || '');
      if (auth !== `Bearer ${bridgeSecret}`) {
        res.status(401).json({ error: 'Invalid or missing bridge authorization.' });
        return;
      }
    }

    const preferTransport = req.body?.transport === 'data_packet' ? 'data_packet' : 'rpc';
    const { Room, RoomEvent } = await import('@livekit/rtc-node');
    const probeRoom = new Room();
    const requestId = crypto.randomUUID();
    const payloadStr = JSON.stringify({
      type: 'odyssey_command',
      version: 1,
      requestId,
      command: 'get_game_state',
      params: {},
      callerIdentity: 'server-probe',
      issuedAt: new Date().toISOString(),
    });

    try {
      const token = new AccessToken(cfg.livekitKey, cfg.livekitSecret, {
        identity: `chert-odyssey-probe-${Date.now()}`,
        name: 'Chert Odyssey Probe',
        ttl: 60,
      });
      token.addGrant({
        room: ODYSSEY_ROOM_NAME,
        roomJoin: true,
        canPublish: true,
        canPublishData: true,
        canSubscribe: true,
      });
      await probeRoom.connect(cfg.livekitUrl, await token.toJwt(), { autoSubscribe: true, dynacast: false });

      if (!probeRoom.remoteParticipants.has(ODYSSEY_PARTICIPANT_IDENTITY)) {
        res.status(404).json({
          ok: false,
          bridgeConnected: false,
          error: `Participant "${ODYSSEY_PARTICIPANT_IDENTITY}" is not connected to room "${ODYSSEY_ROOM_NAME}".`,
        });
        return;
      }

      if (preferTransport === 'rpc') {
        try {
          const rpcRaw = await probeRoom.localParticipant!.performRpc({
            destinationIdentity: ODYSSEY_PARTICIPANT_IDENTITY,
            method: ODYSSEY_RPC_METHOD,
            payload: payloadStr,
            responseTimeout: 3500,
          });
          let parsed: unknown = rpcRaw;
          try {
            parsed = JSON.parse(rpcRaw);
          } catch {
            /* plain-text RPC response */
          }
          res.json({ ok: true, transport: 'rpc', requestId, result: parsed });
          return;
        } catch (rpcErr) {
          const rpcCode = rpcErr && typeof rpcErr === 'object' && 'code' in rpcErr ? (rpcErr as { code?: number }).code : undefined;
          const rpcMsg = rpcErr instanceof Error ? rpcErr.message : String(rpcErr || 'RPC failed');
          if (rpcCode !== 1400 && !/UNSUPPORTED_METHOD/i.test(rpcMsg)) {
            res.status(502).json({ ok: false, transport: 'rpc', requestId, code: rpcCode, error: rpcMsg });
            return;
          }
        }
      }

      const enc = new TextEncoder();
      const dec = new TextDecoder();
      const ack = await new Promise<unknown>((resolve) => {
        const timer = setTimeout(() => resolve(null), 3500);
        probeRoom.on(RoomEvent.DataReceived, (payload, participant, _kind, topic) => {
          if (participant?.identity !== ODYSSEY_PARTICIPANT_IDENTITY) return;
          if (topic && topic !== ODYSSEY_DATA_TOPIC) return;
          try {
            const msg = JSON.parse(dec.decode(payload));
            if (msg?.type === 'odyssey_command_result' && msg?.requestId === requestId) {
              clearTimeout(timer);
              resolve(msg);
            }
          } catch {
            /* ignore non-JSON */
          }
        });
        void probeRoom.localParticipant!.publishData(enc.encode(payloadStr), {
          reliable: true,
          destination_identities: [ODYSSEY_PARTICIPANT_IDENTITY],
          topic: ODYSSEY_DATA_TOPIC,
        });
      });

      res.json({
        ok: true,
        transport: 'data_packet',
        requestId,
        result: ack ?? { note: 'Delivered via authenticated LiveKit DataPacket.' },
      });
    } catch (error) {
      res.status(500).json({
        ok: false,
        error: error instanceof Error ? error.message : 'Odyssey ping failed.',
      });
    } finally {
      await probeRoom.disconnect().catch(() => {});
    }
  });

  app.get('/api/screen/state', (_req, res) => {
    res.json(studioState);
  });

  app.post('/api/screen/render', async (req, res) => {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) {
      res.status(400).json({ error: 'A visual prompt is required.' });
      return;
    }
    const title = String(req.body?.title || prompt.slice(0, 44)).trim();
    const kind = String(req.body?.kind || 'illustration').trim();
    const caption = String(req.body?.caption || '').trim();

    try {
      const ai = getGeminiClient();
      const rendered = await generateIllustrationSvg({ ai, title, kind, prompt, caption });
      const visual: ScreenVisual = {
        id: crypto.randomUUID(),
        title: rendered.title,
        content: caption || prompt,
        items: [],
        kind: rendered.kind,
        caption: rendered.caption,
        svg: rendered.svg,
        source: 'studio',
        createdAt: new Date().toISOString(),
      };
      studioState.activeVisual = visual;
      studioState.history = [visual, ...studioState.history].slice(0, 12);
      broadcastScreen({ type: 'visual', visual, history: studioState.history });
      res.json({ visual, history: studioState.history });
    } catch (error) {
      res.status(500).json({
        error: error instanceof Error ? error.message : 'Failed to generate illustration.',
      });
    }
  });

  app.post('/api/screen/show', (req, res) => {
    const body = req.body || {};
    const title = String(body.title || '').trim();
    if (!title) {
      res.status(400).json({ error: 'A display title is required.' });
      return;
    }
    const content = String(body.content || '').trim();
    const rawItems = Array.isArray(body.items) ? body.items : [];
    const items = rawItems.map((i: unknown) => String(i ?? '').trim()).filter(Boolean);
    const visual: ScreenVisual = {
      id: crypto.randomUUID(),
      title,
      content,
      items,
      kind: String(body.kind || 'display'),
      caption: String(body.caption || ''),
      svg: body.svg ? String(body.svg) : undefined,
      source: body.source === 'facetime' ? 'facetime' : 'studio',
      createdAt: new Date().toISOString(),
    };
    studioState.activeVisual = visual;
    studioState.history = [visual, ...studioState.history].slice(0, 12);
    broadcastScreen({ type: 'visual', visual, history: studioState.history });
    res.json({ visual, history: studioState.history });
  });

  app.post('/api/screen/clear', (_req, res) => {
    studioState.activeVisual = null;
    broadcastScreen({ type: 'clear', history: studioState.history });
    res.json({ ok: true, activeVisual: null });
  });

  app.post('/api/screen/publish', (req, res) => {
    const body = req.body || {};
    if (body.type === 'clear') {
      studioState.activeVisual = null;
      broadcastScreen({ type: 'clear', source: 'facetime', history: studioState.history });
      res.json({ ok: true });
      return;
    }
    if ((body.type === 'display' || body.type === 'visual') && (body.title || body.svg)) {
      const items = Array.isArray(body.items)
        ? body.items.map((i: unknown) => String(i ?? '').trim()).filter(Boolean)
        : [];
      const visual: ScreenVisual = {
        id: crypto.randomUUID(),
        title: String(body.title || 'FaceTime Display'),
        content: String(body.content || body.caption || ''),
        items,
        kind: String(body.kind || (body.type === 'display' ? 'display' : 'illustration')),
        caption: String(body.caption || ''),
        svg: body.svg ? String(body.svg) : undefined,
        source: 'facetime',
        createdAt: new Date().toISOString(),
      };
      studioState.activeVisual = visual;
      // Avoid duplicating history entry if the same title was just upgraded with an async SVG
      const prev = studioState.history[0];
      if (prev && prev.source === 'facetime' && prev.title === visual.title && !prev.svg && visual.svg) {
        studioState.history = [visual, ...studioState.history.slice(1)].slice(0, 12);
      } else {
        studioState.history = [visual, ...studioState.history].slice(0, 12);
      }
      broadcastScreen({ type: 'visual', visual, history: studioState.history });
      res.json({ ok: true, visual });
      return;
    }
    res.status(400).json({ error: 'Invalid screen publish payload.' });
  });

  const server = createServer(app);
  const liveWss = new WebSocketServer({ noServer: true });
  const screenWss = new WebSocketServer({ noServer: true });

  screenWss.on('connection', (ws) => {
    screenClients.add(ws);
    ws.send(JSON.stringify({ type: 'init', ...studioState }));
    ws.on('close', () => screenClients.delete(ws));
  });

  liveWss.on('connection', async (clientWs) => {
    let session: Awaited<ReturnType<GoogleGenAI['live']['connect']>> | null = null;
    let closed = false;

    const sendJson = (payload: unknown) => {
      if (!closed && clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify(payload));
      }
    };

    try {
      const aiStandard = getGeminiClient();
      const aiLive = getGeminiClient('v1alpha');
      session = await aiLive.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction:
            'You are a friendly AI partner on a live FaceTime call paired with a full-screen live Display Panel. Whenever the user asks to see notes, steps, comparisons, lists, or visuals, immediately call show_on_screen(title, content, items) to update the display panel, then briefly explain what is shown in 1 to 3 concise sentences.',
          tools: [{ functionDeclarations: [SHOW_ON_SCREEN_TOOL, SHOW_VISUAL_TOOL, CLEAR_VISUAL_TOOL] }],
        },
        callbacks: {
          onmessage: async (message: LiveServerMessage) => {
            const content = message.serverContent;
            if (content?.interrupted) {
              sendJson({ type: 'interrupted' });
            }
            if (content?.inputTranscription?.text) {
              sendJson({ type: 'input_transcript', text: content.inputTranscription.text });
            }
            if (content?.outputTranscription?.text) {
              sendJson({ type: 'output_transcript', text: content.outputTranscription.text });
            }
            for (const part of content?.modelTurn?.parts ?? []) {
              if (part.inlineData?.data) {
                sendJson({ type: 'audio', data: part.inlineData.data });
              }
            }
            if (message.toolCall?.functionCalls?.length) {
              for (const call of message.toolCall.functionCalls) {
                if (call.name === 'show_on_screen') {
                  const args = (call.args || {}) as Record<string, unknown>;
                  const title = String(args.title || 'On Screen');
                  const textContent = String(args.content || '');
                  const rawItems = Array.isArray(args.items) ? args.items : [];
                  const items = rawItems.map((i) => String(i ?? '').trim()).filter(Boolean);
                  const visual: ScreenVisual = {
                    id: crypto.randomUUID(),
                    title,
                    content: textContent,
                    items,
                    kind: 'display',
                    caption: '',
                    source: 'studio',
                    createdAt: new Date().toISOString(),
                  };
                  studioState.activeVisual = visual;
                  studioState.history = [visual, ...studioState.history].slice(0, 12);
                  broadcastScreen({ type: 'visual', visual, history: studioState.history });
                  sendJson({ type: 'visual', visual, history: studioState.history });
                  session?.sendToolResponse({
                    functionResponses: [
                      {
                        id: call.id,
                        name: call.name,
                        response: {
                          status: 'displayed',
                          title: visual.title,
                          itemCount: items.length,
                          message: `Displayed "${visual.title}" on the full-screen display panel.`,
                        },
                      },
                    ],
                  });
                } else if (call.name === 'show_visual_screen') {
                  const args = (call.args || {}) as Record<string, unknown>;
                  const title = String(args.title || 'Illustration');
                  const kind = String(args.kind || 'illustration');
                  const prompt = String(args.prompt || title);
                  const caption = String(args.caption || '');
                  sendJson({ type: 'rendering', title });
                  try {
                    const rendered = await generateIllustrationSvg({ ai: aiStandard, title, kind, prompt, caption });
                    const visual: ScreenVisual = {
                      id: crypto.randomUUID(),
                      title: rendered.title,
                      content: caption || prompt,
                      items: [],
                      kind: rendered.kind,
                      caption: rendered.caption,
                      svg: rendered.svg,
                      source: 'studio',
                      createdAt: new Date().toISOString(),
                    };
                    studioState.activeVisual = visual;
                    studioState.history = [visual, ...studioState.history].slice(0, 12);
                    broadcastScreen({ type: 'visual', visual, history: studioState.history });
                    sendJson({ type: 'visual', visual, history: studioState.history });
                    session?.sendToolResponse({
                      functionResponses: [
                        {
                          id: call.id,
                          name: call.name,
                          response: {
                            status: 'displayed',
                            title: visual.title,
                            message: `Displayed "${visual.title}" on the full-screen display panel.`,
                          },
                        },
                      ],
                    });
                  } catch (err) {
                    session?.sendToolResponse({
                      functionResponses: [
                        {
                          id: call.id,
                          name: call.name,
                          response: {
                            status: 'error',
                            error: err instanceof Error ? err.message : 'Failed to render illustration',
                          },
                        },
                      ],
                    });
                  }
                } else if (call.name === 'clear_visual_screen') {
                  studioState.activeVisual = null;
                  broadcastScreen({ type: 'clear', history: studioState.history });
                  sendJson({ type: 'clear' });
                  session?.sendToolResponse({
                    functionResponses: [
                      {
                        id: call.id,
                        name: call.name,
                        response: { status: 'cleared', message: 'Returned camera screen to studio view.' },
                      },
                    ],
                  });
                }
              }
            }
          },
          onerror: (err: unknown) => {
            sendJson({
              type: 'error',
              message: err instanceof Error ? err.message : 'Gemini Live session error.',
            });
          },
          onclose: () => {
            sendJson({ type: 'closed' });
          },
        },
      });
    } catch (error) {
      sendJson({
        type: 'error',
        message: error instanceof Error ? error.message : 'Failed to connect to Gemini Live.',
      });
      clientWs.close();
      return;
    }

    clientWs.on('message', (raw) => {
      if (closed || !session) return;
      try {
        const msg = JSON.parse(raw.toString()) as { type?: string; data?: string; text?: string };
        if (msg.type === 'audio' && msg.data) {
          session.sendRealtimeInput({
            audio: { data: msg.data, mimeType: 'audio/pcm;rate=16000' },
          });
        } else if (msg.type === 'text' && msg.text) {
          session.sendClientContent({
            turns: [{ role: 'user', parts: [{ text: msg.text }] }],
            turnComplete: true,
          });
        }
      } catch {
        /* ignore malformed ws frame */
      }
    });

    sendJson({ type: 'ready' });

    clientWs.on('close', () => {
      closed = true;
      try {
        session?.close();
      } catch {
        /* ignore */
      }
    });
  });

  server.on('upgrade', (req, socket, head) => {
    const pathname = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`).pathname;
    if (pathname === '/api/live') {
      liveWss.handleUpgrade(req, socket, head, (ws) => liveWss.emit('connection', ws, req));
    } else if (pathname === '/api/screen/stream') {
      screenWss.handleUpgrade(req, socket, head, (ws) => screenWss.emit('connection', ws, req));
    } else {
      socket.destroy();
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('/{*path}', (_req, res) => {
      res.sendFile(join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[chert-visual-studio] listening on http://0.0.0.0:${PORT}`);
    // Automatically start the LiveKit Agent + Chert FaceTime Bridge using AI Studio Secrets
    void startFaceTimeProcesses();
  });

  const cleanup = () => {
    stopFaceTimeProcesses(true);
    process.exit(0);
  };
  process.on('SIGINT', cleanup);
  process.on('SIGTERM', cleanup);
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
